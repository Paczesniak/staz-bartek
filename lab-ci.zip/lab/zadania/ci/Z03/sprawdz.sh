#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

REPO="${LAB_DOM}/staz"
KATALOG_WORKFLOW="${REPO}/.github/workflows"

lab_jest_katalog "$KATALOG_WORKFLOW" "katalog .github/workflows istnieje w repozytorium"

PLIK=""
if [[ -d "$KATALOG_WORKFLOW" ]]; then
  PLIK="$(find "$KATALOG_WORKFLOW" -maxdepth 1 -type f \( -name '*.yml' -o -name '*.yaml' \) 2> /dev/null | head -n1 || true)"
fi

if [[ -n "$PLIK" ]]; then
  lab_ok "w .github/workflows leży plik workflow ($(basename -- "$PLIK"))"
else
  lab_blad "w .github/workflows leży plik workflow (.yml albo .yaml)"
  lab_wskazowka "GitHub szuka tych plików TYLKO w .github/workflows — w innym katalogu nie zauważy ich wcale."
  lab_zakoncz
fi

if grep -Eq '^[[:space:]]*(on|"on"|true)[[:space:]]*:' "$PLIK"; then
  lab_ok "workflow ma sekcję on: (kiedy się uruchamia)"
else
  lab_blad "workflow ma sekcję on: (kiedy się uruchamia)"
fi

if grep -Eq '\bpush\b' "$PLIK"; then
  lab_ok "workflow uruchamia się przy push"
else
  lab_blad "workflow uruchamia się przy push"
fi

if grep -Eq 'uses:[[:space:]]*actions/checkout' "$PLIK"; then
  lab_ok "workflow pobiera kod przez actions/checkout"
else
  lab_blad "workflow pobiera kod przez actions/checkout (bez tego maszyna nie ma twojego repozytorium)"
fi

if grep -Eq 'uses:[[:space:]]*actions/setup-python' "$PLIK"; then
  lab_ok "workflow przygotowuje Pythona przez actions/setup-python"
else
  lab_blad "workflow przygotowuje Pythona przez actions/setup-python"
fi

if grep -Eq 'requirements\.txt' "$PLIK"; then
  lab_ok "workflow instaluje zależności z requirements.txt"
else
  lab_blad "workflow instaluje zależności z requirements.txt"
fi

if grep -Eq 'sprawdz\.sh' "$PLIK"; then
  lab_ok "workflow uruchamia twój skrypt sprawdz.sh (a nie trzy osobne polecenia)"
else
  lab_blad "workflow uruchamia twój skrypt sprawdz.sh (a nie trzy osobne polecenia)"
fi

SCIEZKA_WZGLEDNA="${PLIK#"${REPO}/"}"

if git -C "$REPO" ls-files --error-unmatch -- "$SCIEZKA_WZGLEDNA" > /dev/null 2>&1; then
  lab_ok "plik workflow jest śledzony przez git"
else
  lab_blad "plik workflow jest śledzony przez git (git add .github/)"
fi

LOCAL_HEAD="$(git -C "$REPO" rev-parse HEAD 2> /dev/null || true)"
UPSTREAM_HEAD="$(git -C "$REPO" rev-parse '@{u}' 2> /dev/null || true)"

if [[ -n "$LOCAL_HEAD" && "$LOCAL_HEAD" == "$UPSTREAM_HEAD" ]]; then
  lab_ok "commit jest wypchnięty — GitHub dostał workflow i mógł go uruchomić"
else
  lab_blad "commit jest wypchnięty (bez pusha żaden przebieg się nie zaczął)"
fi

lab_wskazowka "Przebieg zobaczysz w zakładce Actions swojego repozytorium. Czerwony przy pierwszym podejściu to norma — czytaj log od góry, tak samo jak log aplikacji."
lab_zakoncz
