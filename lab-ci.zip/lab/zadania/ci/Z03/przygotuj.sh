#!/bin/bash
set -Eeuo pipefail
printf 'Z03 nie wymaga przygotowania — workflow piszesz sam i sam go wypychasz.\n'
