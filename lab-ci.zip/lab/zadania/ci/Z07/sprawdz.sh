#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

REPO="${LAB_DOM}/staz"
NOTATKI="${REPO}/notatki/ci.md"
RETRO="${REPO}/RETRO.md"

if [[ -f "$NOTATKI" ]] && grep -Eq '.{20,}' "$NOTATKI" 2> /dev/null; then
  lab_ok "notatki/ci.md istnieją i mają treść"
else
  lab_blad "notatki/ci.md istnieją i mają treść"
fi

if [[ -f "$RETRO" ]]; then
  lab_ok "RETRO.md istnieje w repozytorium"
  ZNAKI="$(wc -c < "$RETRO" 2> /dev/null || printf '0')"
  if ((ZNAKI >= 2000)); then
    lab_ok "RETRO.md jest napisane, a nie naszkicowane (${ZNAKI} znaków)"
  else
    lab_blad "RETRO.md jest napisane, a nie naszkicowane (ma ${ZNAKI} znaków — sześć pytań z treści zadania wymaga więcej)"
  fi
else
  lab_blad "RETRO.md istnieje w repozytorium"
fi

if [[ -f "${REPO}/aplikacja/.env" ]]; then
  if git -C "$REPO" check-ignore -q aplikacja/.env 2> /dev/null; then
    lab_ok "plik aplikacja/.env z hasłem nadal jest ignorowany przez git"
  else
    lab_blad "plik aplikacja/.env z hasłem nadal jest ignorowany przez git"
  fi
fi

if [[ -d "${REPO}/kopie" ]]; then
  if git -C "$REPO" check-ignore -q kopie 2> /dev/null; then
    lab_ok "katalog kopie/ nadal jest ignorowany przez git"
  else
    lab_blad "katalog kopie/ nadal jest ignorowany przez git"
  fi
fi

lab_jest_katalog "$REPO/.git" "katalog ~/staz jest repozytorium git"

if [[ -z "$(git -C "$REPO" status --porcelain 2> /dev/null)" ]]; then
  lab_ok "git status jest czysty — wszystko dodane i zacommitowane"
else
  lab_blad "git status jest czysty (są niezacommitowane albo nieśledzone zmiany)"
fi

LOCAL_HEAD="$(git -C "$REPO" rev-parse HEAD 2> /dev/null || true)"
UPSTREAM_HEAD="$(git -C "$REPO" rev-parse '@{u}' 2> /dev/null || true)"
if [[ -n "$LOCAL_HEAD" && "$LOCAL_HEAD" == "$UPSTREAM_HEAD" ]]; then
  lab_ok "lokalna gałąź jest zsynchronizowana ze zdalną (wypchnięta)"
else
  lab_blad "lokalna gałąź jest zsynchronizowana ze zdalną (commit może nie być wypchnięty)"
fi

lab_wskazowka "To był ostatni moduł stażu. Raport dnia zrobisz poleceniem 'lab koniec ci' — i to jest ostatnia rzecz do zacommitowania."
lab_zakoncz
