#!/bin/bash
set -Eeuo pipefail
printf 'Z07 nie wymaga przygotowania — piszesz retro i zamykasz repozytorium.\n'
