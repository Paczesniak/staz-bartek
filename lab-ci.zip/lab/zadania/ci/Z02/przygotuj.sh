#!/bin/bash
set -Eeuo pipefail
printf 'Z02 nie wymaga przygotowania — skrypt piszesz sam, walidator go uruchomi.\n'
