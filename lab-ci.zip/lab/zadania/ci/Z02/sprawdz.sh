#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

REPO="${LAB_DOM}/staz"
SKRYPT="${REPO}/sprawdz.sh"

lab_jest_plik "$SKRYPT" "skrypt sprawdz.sh istnieje w ~/staz"

if [[ ! -f "$SKRYPT" ]]; then
  lab_wskazowka "Skrypt ma leżeć w korzeniu repozytorium — tak samo znajdzie go GitHub Actions."
  lab_zakoncz
fi

if [[ -x "$SKRYPT" ]]; then
  lab_ok "skrypt ma prawo wykonywania"
else
  lab_blad "skrypt ma prawo wykonywania (chmod +x sprawdz.sh)"
fi

if grep -Eq '^[[:space:]]*set[[:space:]]+-[A-Za-z]*e' "$SKRYPT"; then
  lab_ok "skrypt ma włączone przerywanie na błędzie (set -e)"
else
  lab_blad "skrypt ma włączone przerywanie na błędzie (set -Eeuo pipefail)"
fi

if grep -Eq 'pipefail' "$SKRYPT"; then
  lab_ok "skrypt ma włączone pipefail"
else
  lab_blad "skrypt ma włączone pipefail (bez niego błąd w potoku przechodzi niezauważony)"
fi

for narzedzie in pytest ruff black; do
  if grep -q -- "$narzedzie" "$SKRYPT"; then
    lab_ok "skrypt uruchamia ${narzedzie}"
  else
    lab_blad "skrypt uruchamia ${narzedzie}"
  fi
done

WYJSCIE_TMP="$(mktemp)"
trap 'rm -f -- "$WYJSCIE_TMP"' EXIT

KOD=0
timeout 180 bash "$SKRYPT" > "$WYJSCIE_TMP" 2>&1 || KOD=$?

case "$KOD" in
  0)
    lab_ok "uruchomiony skrypt kończy się kodem 0 na czystym kodzie"
    ;;
  124)
    lab_blad "uruchomiony skrypt kończy się w rozsądnym czasie (przerwałem go po 3 minutach)"
    ;;
  *)
    lab_blad "uruchomiony skrypt kończy się kodem 0 na czystym kodzie (dostałem: ${KOD})"
    OSTATNIE="$(tail -n 3 "$WYJSCIE_TMP" | tr '\n' ' ' | cut -c1-200 || true)"
    [[ -n "$OSTATNIE" ]] && lab_wskazowka "Koniec wyjścia twojego skryptu: ${OSTATNIE}"
    ;;
esac

lab_wskazowka "Jeśli skrypt przechodzi u ciebie, a masz wątpliwości, czy naprawdę coś sprawdza — zepsuj na chwilę jedną linię w kodzie i uruchom go jeszcze raz. Skrypt, który nigdy nie świeci na czerwono, nie jest sprawdzeniem."
lab_zakoncz
