#!/bin/bash
set -Eeuo pipefail
printf 'Z06 nie wymaga przygotowania — drugi job dopisujesz sam.\n'
