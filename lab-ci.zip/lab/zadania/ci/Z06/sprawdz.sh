#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

REPO="${LAB_DOM}/staz"
KATALOG_WORKFLOW="${REPO}/.github/workflows"

PLIK=""
if [[ -d "$KATALOG_WORKFLOW" ]]; then
  while IFS= read -r kandydat; do
    if grep -Eq 'docker[[:space:]]+build|docker/build-push-action|docker[[:space:]]+compose[[:space:]]+build' "$kandydat"; then
      PLIK="$kandydat"
      break
    fi
  done < <(find "$KATALOG_WORKFLOW" -maxdepth 1 -type f \( -name '*.yml' -o -name '*.yaml' \) 2> /dev/null)
fi

if [[ -n "$PLIK" ]]; then
  lab_ok "workflow buduje obraz ($(basename -- "$PLIK"))"
else
  lab_blad "workflow buduje obraz z twojego Dockerfile"
  lab_wskazowka "Na maszynie ubuntu-latest Docker jest już zainstalowany — nie musisz go dokładać, wystarczy go użyć."
  lab_zakoncz
fi

LICZBA_JOBOW="$(grep -cE '^ {2}[a-zA-Z0-9_-]+:' "$PLIK" || true)"
if ((LICZBA_JOBOW >= 2)); then
  lab_ok "workflow ma co najmniej dwa joby"
else
  lab_blad "workflow ma co najmniej dwa joby (testy osobno, budowanie obrazu osobno)"
fi

if grep -Eq '^[[:space:]]*needs:' "$PLIK"; then
  lab_ok "job z obrazem czeka na poprzedni przez needs:"
else
  lab_blad "job z obrazem czeka na poprzedni przez needs: (nie ma po co budować obrazu z kodu, który nie przeszedł testów)"
fi

if grep -Eq '/health' "$PLIK"; then
  lab_ok "workflow sprawdza /health uruchomionego kontenera"
else
  lab_blad "workflow sprawdza /health uruchomionego kontenera"
fi

if grep -Eq '\b(until|while|for)\b' "$PLIK"; then
  lab_ok "workflow czeka na gotowość kontenera w pętli, a nie jednym sleepem"
else
  lab_blad "workflow czeka na gotowość kontenera w pętli, a nie jednym sleepem"
fi

if grep -Eq 'docker[[:space:]]+run|docker[[:space:]]+compose[[:space:]]+up' "$PLIK"; then
  lab_ok "workflow uruchamia zbudowany obraz"
else
  lab_blad "workflow uruchamia zbudowany obraz (samo zbudowanie nie dowodzi, że aplikacja wstaje)"
fi

LOCAL_HEAD="$(git -C "$REPO" rev-parse HEAD 2> /dev/null || true)"
UPSTREAM_HEAD="$(git -C "$REPO" rev-parse '@{u}' 2> /dev/null || true)"
if [[ -n "$LOCAL_HEAD" && "$LOCAL_HEAD" == "$UPSTREAM_HEAD" ]]; then
  lab_ok "commit jest wypchnięty — przebieg mógł się uruchomić"
else
  lab_blad "commit jest wypchnięty (bez pusha przebieg się nie zaczął)"
fi

lab_wskazowka "Kontener w CI wstaje z pustą, domyślną bazą — i tak ma być. To smoke test: sprawdza, czy aplikacja w ogóle wstaje, a nie czy ma właściwe dane."
lab_zakoncz
