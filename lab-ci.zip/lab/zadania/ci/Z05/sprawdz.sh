#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

REPO="${LAB_DOM}/staz"
SKRYPT="${REPO}/sprawdz.sh"
PLIK="${REPO}/aplikacja/api/app/validation.py"
TEST="${REPO}/aplikacja/api/tests/test_links.py"

if [[ ! -x "$SKRYPT" ]]; then
  lab_blad "skrypt sprawdz.sh istnieje i jest wykonywalny (to nim diagnozujesz to zadanie)"
  lab_zakoncz
fi

WYJSCIE_TMP="$(mktemp)"
trap 'rm -f -- "$WYJSCIE_TMP"' EXIT

KOD=0
timeout 180 bash "$SKRYPT" > "$WYJSCIE_TMP" 2>&1 || KOD=$?

case "$KOD" in
  0)
    lab_ok "uruchomiony skrypt sprawdz.sh kończy się kodem 0 — wszystkie trzy sprawdzenia przechodzą"
    ;;
  124)
    lab_blad "skrypt kończy się w rozsądnym czasie (przerwałem go po 3 minutach)"
    ;;
  *)
    lab_blad "uruchomiony skrypt sprawdz.sh kończy się kodem 0 (dostałem: ${KOD})"
    OSTATNIE="$(tail -n 5 "$WYJSCIE_TMP" | tr '\n' ' ' | cut -c1-250 || true)"
    [[ -n "$OSTATNIE" ]] && lab_wskazowka "Koniec wyjścia: ${OSTATNIE}"
    ;;
esac

if [[ -f "$PLIK" ]]; then
  if grep -Eq '#[[:space:]]*noqa' "$PLIK"; then
    lab_blad "w app/validation.py nie ma wyciszeń lintera (# noqa) — problem rozwiązuje się usunięciem przyczyny"
  else
    lab_ok "w app/validation.py nie ma wyciszeń lintera"
  fi

  DLUGOSC="$(grep -E '^GENERATED_CODE_LENGTH' "$PLIK" | head -n1 | grep -oE '[0-9]+' | head -n1 || true)"
  if [[ -n "$DLUGOSC" ]] && ((DLUGOSC >= 3)); then
    lab_ok "generowany kod linku ma sensowną długość (${DLUGOSC})"
  else
    lab_blad "generowany kod linku ma sensowną długość (jest: ${DLUGOSC:-brak stałej})"
  fi
else
  lab_blad "plik app/validation.py istnieje"
fi

if [[ -f "$TEST" ]]; then
  if grep -Eq 'len\(body\["code"\]\)[[:space:]]*>=' "$TEST"; then
    lab_ok "test sprawdzający długość kodu został nietknięty"
  else
    lab_blad "test sprawdzający długość kodu został nietknięty (kod naprawia się pod test, nie test pod kod)"
  fi
fi

PYPROJECT="${REPO}/aplikacja/api/pyproject.toml"
if [[ -f "$PYPROJECT" ]] && grep -Eq '^[[:space:]]*(exclude|extend-exclude|ignore)[[:space:]]*=' "$PYPROJECT"; then
  lab_blad "w pyproject.toml nie przybyło wykluczeń dla lintera ani formatera"
else
  lab_ok "konfiguracja narzędzi została nietknięta — naprawa poszła przez kod"
fi

lab_wskazowka "Trzy narzędzia mówią o trzech różnych rzeczach: ruff o błędach widocznych bez uruchamiania, black o zapisie, pytest o zachowaniu. Zielony jest dopiero ten build, w którym milczą wszystkie trzy."
lab_zakoncz
