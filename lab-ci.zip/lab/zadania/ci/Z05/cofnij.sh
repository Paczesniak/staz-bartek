#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

PLIK="${LAB_DOM}/staz/aplikacja/api/app/validation.py"
KOPIA="${LAB_STAN_DIR}/ci-Z05-validation.py.oryginal"

if [[ -f "$KOPIA" ]]; then
  cp -- "$KOPIA" "$PLIK"
  chown -- "${LAB_UZYTKOWNIK}:${LAB_GRUPA}" "$PLIK" 2> /dev/null || true
  rm -f -- "$KOPIA"
fi
exit 0
