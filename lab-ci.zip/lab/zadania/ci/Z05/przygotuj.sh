#!/bin/bash
set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly PLIK="${LAB_DOM}/staz/aplikacja/api/app/validation.py"
readonly KOPIA="${LAB_STAN_DIR}/ci-Z05-validation.py.oryginal"

if [[ -f "$KOPIA" ]]; then
  printf 'Z05 już przygotowane wcześniej — nie podkładam wad drugi raz.\n'
  exit 0
fi

if [[ ! -f "$PLIK" ]]; then
  lab_dziennik_mentora "Z05: nie mogę przygotować — brak ${PLIK}."
  printf 'Nie znajduję pliku aplikacji, w którym miałem coś zmienić — zgłoś to mentorowi.\n'
  exit 0
fi

cp -- "$PLIK" "$KOPIA"
chmod 644 -- "$KOPIA"

if grep -q '^GENERATED_CODE_LENGTH' "$PLIK"; then
  sed -i 's/^GENERATED_CODE_LENGTH.*/GENERATED_CODE_LENGTH = 2/' "$PLIK"
else
  lab_dziennik_mentora "Z05: nie znalazłem GENERATED_CODE_LENGTH — podłożyłem tylko dwie wady zamiast trzech."
fi

sed -i '0,/^import re$/s//import json\nimport re/' "$PLIK"

cat >> "$PLIK" << 'PYTHON'


def opis_kodu(code: str, prefiks: str="link") -> str:
    """Zwraca krótki opis kodu do logów."""
    return f"{prefiks}:{code}" if code else  f"{prefiks}:(brak)"
PYTHON

chown -- "${LAB_UZYTKOWNIK}:${LAB_GRUPA}" "$PLIK"

lab_dziennik_mentora "Z05: podłożono trzy wady w app/validation.py — (1) nieużyty 'import json' [ruff F401], (2) funkcja opis_kodu z rozjechanym formatowaniem [black], (3) GENERATED_CODE_LENGTH=2 zamiast 7 [pytest: test_links.py sprawdza len(code) >= 3]. Oryginał leży w ${KOPIA}."

printf 'Przygotowano Z05. W kodzie aplikacji coś się zmieniło — zacznij od uruchomienia\n'
printf 'swojego skryptu i przeczytania, co zgłasza.\n'
