#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="${LAB_DOM}/staz/aplikacja/api"
VENV_BIN="${API}/.venv/bin"

ci__narzedzie_dziala() {
  local nazwa="$1"

  if [[ -x "${VENV_BIN}/${nazwa}" ]]; then
    "${VENV_BIN}/${nazwa}" --version > /dev/null 2>&1 && return 0
  fi
  if [[ -x "${VENV_BIN}/python" ]]; then
    "${VENV_BIN}/python" -m "$nazwa" --version > /dev/null 2>&1 && return 0
  fi
  command -v "$nazwa" > /dev/null 2>&1 && "$nazwa" --version > /dev/null 2>&1 && return 0
  python3 -m "$nazwa" --version > /dev/null 2>&1 && return 0

  return 1
}

for narzedzie in pytest ruff black; do
  if ci__narzedzie_dziala "$narzedzie"; then
    lab_ok "${narzedzie} da się uruchomić na tej maszynie"
  else
    lab_blad "${narzedzie} da się uruchomić na tej maszynie"
  fi
done

lab_wskazowka "Jeśli któregoś brakuje: aktywuj środowisko z poniedziałku (source .venv/bin/activate) i zainstaluj zależności z requirements.txt — wszystkie trzy narzędzia są tam wypisane."
lab_zakoncz
