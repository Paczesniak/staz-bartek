#!/bin/bash
set -Eeuo pipefail
printf 'Z01 nie wymaga przygotowania — uruchamiasz narzędzia, które są już w projekcie.\n'
