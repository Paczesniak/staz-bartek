#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z07 nie wymaga przygotowania — zmieniasz jedną wartość konfiguracji sam.\n'
