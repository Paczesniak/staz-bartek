#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"

lab_port_nasluchuje 8000 dowolny "usługa na porcie 8000 faktycznie działa"
lab_port_nasluchuje 8000 0.0.0.0 "port 8000 nasłuchuje na wszystkich interfejsach, nie tylko na loopbacku"

lab_plik_zawiera "$API/.env" '^APP_HOST=0\.0\.0\.0[[:space:]]*(#.*)?$' "plik .env ma APP_HOST ustawiony na 0.0.0.0"

IP_MASZYNY="$(ip -4 -o addr show scope global 2> /dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1 || true)"

KOD_HTTP="000"
if [[ -n "$IP_MASZYNY" ]] && command -v curl > /dev/null 2>&1; then
  KOD_HTTP="$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "http://${IP_MASZYNY}:8000/health" 2> /dev/null || printf '000')"
fi

if [[ "$KOD_HTTP" == "200" ]]; then
  lab_ok "endpoint /health odpowiada 200 pod adresem innym niż loopback"
else
  lab_blad "endpoint /health nie odpowiada 200 pod adresem innym niż loopback"
fi

lab_zakoncz
