#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z11 nie zostawia artefaktów labu do posprzątania — stan „enabled" usługi linkbox jest dorobkiem stażysty i zostaje.\n'
