#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

lab_wynik_zawiera "systemctl is-enabled linkbox" '^enabled$' \
  "usługa linkbox jest włączona do automatycznego startu (enabled)"

lab_wskazowka "Enabled i active to dwie różne rzeczy — jedna mówi, co się stanie przy następnym starcie systemu, druga, co dzieje się teraz."
lab_zakoncz
