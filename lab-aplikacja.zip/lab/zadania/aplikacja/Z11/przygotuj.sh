#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z11 nie wymaga przygotowania — enable i restart maszyny wykonujesz sam, walidator sprawdzi efekt.\n'
