#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z09 nie wymaga przygotowania — naprawiasz to wyłącznie konfiguracją API.\n'
