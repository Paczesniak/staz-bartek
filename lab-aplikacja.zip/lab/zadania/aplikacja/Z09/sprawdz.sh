#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"
WEB="$LAB_DOM/staz/aplikacja/web"
STAZ_REPO="$LAB_DOM/staz"

ADRES_URL="$(grep -oE 'http://[0-9]+(\.[0-9]+){3}:8000' "$WEB/config.js" 2> /dev/null | head -n1 || true)"
ORIGIN_FRONTU=""
if [[ -n "$ADRES_URL" ]]; then
  IP_FRONTU="${ADRES_URL#http://}"
  IP_FRONTU="${IP_FRONTU%%:*}"
  ORIGIN_FRONTU="http://${IP_FRONTU}:3000"
fi

if ! command -v curl > /dev/null 2>&1; then
  lab_blad "polecenie curl nie jest dostępne — nie mogę sprawdzić nagłówków odpowiedzi API"
elif [[ -z "$ORIGIN_FRONTU" ]]; then
  lab_blad "config.js nie wskazuje API pod adresem IP — nie da się wyznaczyć oczekiwanego origin frontu"
else
  NAGLOWKI="$(curl -s -i --max-time 3 -H "Origin: ${ORIGIN_FRONTU}" "http://127.0.0.1:8000/api/links" 2> /dev/null || true)"
  WARTOSC_NAGLOWKA="$(printf '%s\n' "$NAGLOWKI" \
    | grep -i '^access-control-allow-origin:' \
    | head -n1 \
    | tr -d '\r' \
    | cut -d':' -f2- \
    | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' || true)"

  if [[ "$WARTOSC_NAGLOWKA" == "$ORIGIN_FRONTU" ]]; then
    lab_ok "API odsyła access-control-allow-origin z adresem frontu, gdy żądanie ma nagłówek Origin"
  else
    lab_blad "API nie odsyła poprawnego nagłówka access-control-allow-origin dla origin frontu"
  fi
fi

if [[ -n "$ORIGIN_FRONTU" ]]; then
  WZORZEC_ORIGIN="${ORIGIN_FRONTU//./\\.}"
  lab_plik_zawiera "$API/.env" "^CORS_ORIGINS=.*${WZORZEC_ORIGIN}" "plik .env ma CORS_ORIGINS ustawiony na adres frontu"
else
  lab_blad "plik .env — nie da się sprawdzić CORS_ORIGINS bez znanego adresu frontu z config.js"
fi

STATUS_KODU="$(git -C "$STAZ_REPO" status --porcelain -- aplikacja/api/app aplikacja/web/app.js 2> /dev/null || true)"
if [[ -z "$STATUS_KODU" ]]; then
  lab_ok "kod aplikacji (api/app, web/app.js) pozostał nietknięty"
else
  lab_blad "kod aplikacji (api/app, web/app.js) ma niezacommitowane zmiany"
fi

lab_wskazowka "CORS naprawia się konfiguracją serwera (zmienna środowiskowa), nie zmianą kodu frontu ani API."
lab_zakoncz
