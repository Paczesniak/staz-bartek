#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z10 nie wymaga przygotowania — unit linkbox.service piszesz sam, walidator sprawdzi efekt.\n'
