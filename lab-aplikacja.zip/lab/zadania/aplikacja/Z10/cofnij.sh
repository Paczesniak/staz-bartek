#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z10 nie zostawia artefaktów labu do posprzątania — linkbox.service jest dorobkiem stażysty i zostaje.\n'
