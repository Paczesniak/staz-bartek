#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox"
readonly UNIT_PLIK="/etc/systemd/system/${JEDNOSTKA}.service"

lab__port_pid() {
  local port="$1" linia lokalny port_lok proc_info
  command -v ss > /dev/null 2>&1 || return 1
  while IFS= read -r linia; do
    [[ -z "$linia" ]] && continue
    lokalny="$(awk '{print $4}' <<< "$linia")"
    port_lok="${lokalny##*:}"
    [[ "$port_lok" == "$port" ]] || continue
    proc_info="$(awk '{print $NF}' <<< "$linia")"
    if [[ "$proc_info" =~ pid=([0-9]+) ]]; then
      printf '%s' "${BASH_REMATCH[1]}"
      return 0
    fi
  done < <(ss -tlnpH 2> /dev/null || true)
  return 1
}

lab_jest_plik "$UNIT_PLIK" "istnieje /etc/systemd/system/linkbox.service"

lab_wynik_zawiera "systemctl is-active ${JEDNOSTKA}" '^active$' "usługa linkbox jest active"

UZYTKOWNIK_USLUGI="$(systemctl show -p User --value "$JEDNOSTKA" 2> /dev/null || true)"
if [[ -n "$UZYTKOWNIK_USLUGI" && "$UZYTKOWNIK_USLUGI" != "root" ]]; then
  lab_ok "usługa działa na koncie innym niż root"
else
  lab_blad "usługa nie ma ustawionego User= innego niż root"
fi

lab_wynik_zawiera "systemctl show -p ExecStart --value ${JEDNOSTKA}" '\.venv' \
  "ExecStart wskazuje Pythona ze środowiska wirtualnego (.venv)"

RESTART_USLUGI="$(systemctl show -p Restart --value "$JEDNOSTKA" 2> /dev/null || true)"
if [[ "$RESTART_USLUGI" == "on-failure" || "$RESTART_USLUGI" == "always" ]]; then
  lab_ok "usługa wstaje sama po nieoczekiwanym padzie procesu (Restart=)"
else
  lab_blad "usługa nie ma Restart= ustawionego na on-failure ani always"
fi

lab_port_nasluchuje 8000 0.0.0.0 "port 8000 nasłuchuje na 0.0.0.0, nie tylko na loopbacku"

MAINPID="$(systemctl show -p MainPID --value "$JEDNOSTKA" 2> /dev/null || true)"
SOCKET_PID="$(lab__port_pid 8000 || true)"
if [[ -n "$MAINPID" && "$MAINPID" != "0" && -n "$SOCKET_PID" && "$SOCKET_PID" == "$MAINPID" ]]; then
  lab_ok "port 8000 jest w rękach głównego procesu usługi linkbox (MainPID)"
else
  lab_blad "port 8000 NIE jest w rękach MainPID usługi linkbox — trzyma go inny proces albo usługa nie nasłuchuje"
fi

lab_wskazowka "To pięć niezależnych pytań: czy usługa wstała, na czyich prawach, jakim Pythonem, czy wraca po padzie i czy to naprawdę ona (a nie coś innego) trzyma port 8000."
lab_zakoncz
