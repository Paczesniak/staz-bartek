#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox"

lab__proc_env_wartosc() {
  local pid="$1" zmienna="$2" wpis
  [[ -n "$pid" && "$pid" != "0" && -r "/proc/${pid}/environ" ]] || return 1
  while IFS= read -r -d '' wpis; do
    if [[ "$wpis" == "${zmienna}="* ]]; then
      printf '%s' "${wpis#*=}"
      return 0
    fi
  done < "/proc/${pid}/environ"
  return 1
}

MAINPID="$(systemctl show -p MainPID --value "$JEDNOSTKA" 2> /dev/null || true)"
LOG_LEVEL_EFEKTYWNY="$(lab__proc_env_wartosc "$MAINPID" LOG_LEVEL || true)"

if [[ "$LOG_LEVEL_EFEKTYWNY" != "DEBUG" ]]; then
  lab_ok "efektywny poziom logowania usługi linkbox nie jest ustawiony na DEBUG"
else
  lab_blad "usługa linkbox nadal działa z efektywnym LOG_LEVEL=DEBUG — poziom nie wrócił do stanu sprzed eksperymentu"
fi

lab_wynik_zawiera "systemctl is-active ${JEDNOSTKA}" '^active$' "usługa linkbox jest active"

lab_wskazowka "Efektywny oznacza to, co proces NAPRAWDĘ dostał po starcie — sprawdź złożoną, obowiązującą konfigurację usługi, nie tylko plik, który edytowałeś ręcznie."
lab_zakoncz
