#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z13 nie zostawia artefaktów labu do posprzątania — usługa linkbox i jej ewentualna nakładka są dorobkiem stażysty.\n'
