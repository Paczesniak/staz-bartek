#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z13 nie wymaga przygotowania — pracujesz na własnej usłudze linkbox i jej dzienniku.\n'
