#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

WEB="$LAB_DOM/staz/aplikacja/web"

lab_port_nasluchuje 3000 dowolny "serwer statyczny frontu (port 3000) faktycznie wystartował"
lab_port_nasluchuje 3000 0.0.0.0 "port 3000 nasłuchuje na wszystkich interfejsach, nie tylko na loopbacku"

lab_plik_zawiera "$WEB/config.js" 'API_BASE_URL[^"]*"http://[^"]+:8000"' \
  "w config.js stoi pełny adres API z portem 8000"

lab_wskazowka "Adres w config.js wpisuje PRZEGLĄDARKA, nie serwer — liczy się to, co widzi maszyna z otwartą kartą. Przy sieci host-only będzie to adres z \`ip a\` na VM-ce; przy NAT z przekierowaniem portów — localhost, bo VirtualBox przekierowuje tam port."

lab_zakoncz
