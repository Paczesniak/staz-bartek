#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

WEB="$LAB_DOM/staz/aplikacja/web"

lab_port_nasluchuje 3000 dowolny "serwer statyczny frontu (port 3000) faktycznie wystartował"
lab_port_nasluchuje 3000 0.0.0.0 "port 3000 nasłuchuje na wszystkich interfejsach, nie tylko na loopbacku"

lab_plik_zawiera "$WEB/config.js" 'API_BASE_URL[^"]*"http://[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:8000"' \
  "config.js wskazuje API pod adresem IP (http://<IP>:8000)"
lab_plik_nie_zawiera "$WEB/config.js" 'API_BASE_URL[^"]*"[^"]*localhost' \
  "config.js nie wskazuje API przez localhost"
lab_plik_nie_zawiera "$WEB/config.js" 'API_BASE_URL[^"]*"[^"]*127\.0\.0\.1' \
  "config.js nie wskazuje API przez 127.0.0.1"

lab_zakoncz
