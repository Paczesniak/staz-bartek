#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

WEB="$LAB_DOM/staz/aplikacja/web"

lab_port_nasluchuje 3000 dowolny "serwer statyczny frontu (port 3000) faktycznie wystartował"
lab_port_nasluchuje 3000 0.0.0.0 "port 3000 nasłuchuje na wszystkich interfejsach, nie tylko na loopbacku"

lab_plik_zawiera "$WEB/config.js" 'API_BASE_URL[^"]*"http://[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:8000"' \
  "w config.js adres API to numer IP maszyny (nie localhost, nie 127.0.0.1)"

lab_wskazowka "Przeglądarka działa na Windowsie, więc adres w config.js musi być tym, pod którym Windows widzi twoją maszynę wirtualną. Sprawdzisz go na VM-ce poleceniem \`ip a\`."

lab_zakoncz
