#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z08 nie wymaga przygotowania — serwer frontu stawiasz sam, w aplikacja/web.\n'
