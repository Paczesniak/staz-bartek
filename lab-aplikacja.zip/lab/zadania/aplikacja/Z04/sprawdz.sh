#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"
PY="$API/.venv/bin/python"
BAZA="$API/links.db"

lab_jest_plik "$BAZA" "plik links.db istnieje w aplikacja/api"

TMP_SKRYPT="$(mktemp)"
trap 'rm -f -- "$TMP_SKRYPT"' EXIT

cat > "$TMP_SKRYPT" << 'PYEOF'
import sqlite3
import sys

con = sqlite3.connect(sys.argv[1])
cur = con.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type = ?", ("table",))
tabele = {wiersz[0] for wiersz in cur.fetchall()}
ma_wymagane_tabele = 1 if ("links" in tabele and "alembic_version" in tabele) else 0
liczba_linkow = 0
if "links" in tabele:
    cur.execute("SELECT COUNT(*) FROM links")
    liczba_linkow = cur.fetchone()[0]
con.close()
print(ma_wymagane_tabele, liczba_linkow)
PYEOF

WYNIK="0 0"
if [[ -x "$PY" && -f "$BAZA" ]]; then
  WYNIK="$("$PY" "$TMP_SKRYPT" "$BAZA" 2> /dev/null || printf '0 0')"
fi
read -r MA_TABELE LICZBA_LINKOW <<< "$WYNIK"

if [[ "$MA_TABELE" == "1" ]]; then
  lab_ok "baza ma tabele links i alembic_version (migracja wykonana)"
else
  lab_blad "w bazie brakuje tabeli links lub alembic_version"
fi

if [[ "$LICZBA_LINKOW" =~ ^[0-9]+$ ]] && ((LICZBA_LINKOW >= 1)); then
  lab_ok "w tabeli links jest co najmniej jeden zapisany link"
else
  lab_blad "w tabeli links nie ma żadnego zapisanego linku"
fi

lab_zakoncz
