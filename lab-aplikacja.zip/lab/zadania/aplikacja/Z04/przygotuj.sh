#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z04 nie wymaga przygotowania — migrację i pierwszy link robisz sam, w aplikacja/api.\n'
