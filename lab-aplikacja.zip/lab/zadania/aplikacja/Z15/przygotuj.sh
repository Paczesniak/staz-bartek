#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z15 nie wymaga przygotowania — porządkujesz własne notatki i commitujesz to, co już masz.\n'
