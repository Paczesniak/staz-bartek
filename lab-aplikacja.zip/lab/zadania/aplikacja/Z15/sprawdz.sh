#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

readonly NOTATKI="${LAB_DOM}/staz/notatki/aplikacja.md"
readonly REPO="${LAB_DOM}/staz"

if [[ -f "$NOTATKI" ]] && grep -Eq '.{20,}' "$NOTATKI" 2> /dev/null; then
  lab_ok "notatki/aplikacja.md istnieją i mają treść"
else
  lab_blad "notatki/aplikacja.md nie istnieją albo są puste"
fi

lab_jest_katalog "$REPO/.git" "katalog ~/staz jest repozytorium git"

CZYSTO=0
ZSYNCHRONIZOWANE=0

if [[ -d "$REPO/.git" ]]; then
  if [[ -z "$(git -C "$REPO" status --porcelain 2> /dev/null)" ]]; then
    CZYSTO=1
  fi
  LOCAL_HEAD="$(git -C "$REPO" rev-parse HEAD 2> /dev/null || true)"
  UPSTREAM_HEAD="$(git -C "$REPO" rev-parse '@{u}' 2> /dev/null || true)"
  if [[ -n "$LOCAL_HEAD" && "$LOCAL_HEAD" == "$UPSTREAM_HEAD" ]]; then
    ZSYNCHRONIZOWANE=1
  fi
fi

if ((CZYSTO == 1)); then
  lab_ok "git status jest czysty — wszystko dodane i zacommitowane"
else
  lab_blad "git status NIE jest czysty — są niezacommitowane albo nieśledzone zmiany"
fi

if ((ZSYNCHRONIZOWANE == 1)); then
  lab_ok "lokalna gałąź jest zsynchronizowana ze zdalną (wypchnięta)"
else
  lab_blad "lokalna gałąź nie jest zsynchronizowana ze zdalną — commit może nie być wypchnięty"
fi

lab_wskazowka "git status w ~/staz ma być całkowicie czysty, łącznie z aplikacja/web/config.js zmienionym w module cors."
lab_zakoncz
