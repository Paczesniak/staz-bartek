#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox-staging"
readonly UNIT_PLIK="/etc/systemd/system/${JEDNOSTKA}.service"

if [[ -f "$UNIT_PLIK" ]]; then
  systemctl disable --now -- "$JEDNOSTKA" > /dev/null 2>&1 || true
  rm -f -- "$UNIT_PLIK"
  systemctl daemon-reload
fi

printf 'Cofnięto Z12: usunięto usługę testową linkbox-staging. Usługa produkcyjna linkbox nie została ruszona.\n'
