#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox-staging"
readonly UNIT_PLIK="/etc/systemd/system/${JEDNOSTKA}.service"

if [[ -f "$UNIT_PLIK" ]]; then
  printf 'Z12 już przygotowane wcześniej — nie dotykam istniejącego stanu.\n'
else
  cat > "$UNIT_PLIK" << UNIT
[Unit]
Description=linkbox — środowisko testowe (staging), druga instancja
After=network.target

[Service]
User=${LAB_UZYTKOWNIK}
WorkingDirectory=/opt/linkbox
Environment=APP_PORT=8000
Environment=APP_NAME=linkbox-staging
ExecStart=/usr/bin/python3 -m app

[Install]
WantedBy=multi-user.target
UNIT

  chmod 644 -- "$UNIT_PLIK"
  chown root:root -- "$UNIT_PLIK"
  systemctl daemon-reload

  lab_dziennik_mentora "Z12: podłożono ${UNIT_PLIK} z trzema wadami: WorkingDirectory=/opt/linkbox (katalog nie istnieje), ExecStart=/usr/bin/python3 -m app (systemowy Python zamiast .venv), Environment=APP_PORT=8000 (kolizja portu z działającą usługą linkbox). Bez enable, bez próby startu — pierwsze uruchomienie należy do stażysty."
  printf 'Przygotowano Z12. Usługa czeka w /etc/systemd/system.\n'
fi
