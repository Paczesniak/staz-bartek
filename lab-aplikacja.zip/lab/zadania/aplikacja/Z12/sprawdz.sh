#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

readonly PROD="linkbox"
readonly STAGING="linkbox-staging"

lab_wynik_zawiera "systemctl is-active ${STAGING}" '^active$' "usługa linkbox-staging jest active"
lab_wynik_zawiera "systemctl is-active ${PROD}" '^active$' "usługa linkbox (produkcyjna) nadal jest active — nie została zatrzymana"

ENV_STAGING="$(systemctl show -p Environment --value "$STAGING" 2> /dev/null || true)"
PORT_STAGING="$(grep -oE 'APP_PORT=[0-9]+' <<< "$ENV_STAGING" | tail -n1 | cut -d= -f2)"
if [[ -n "$PORT_STAGING" && "$PORT_STAGING" != "8000" ]]; then
  lab_ok "linkbox-staging ma skonfigurowany port inny niż 8000 (produkcyjny)"
else
  lab_blad "linkbox-staging nadal ma APP_PORT=8000 — kolizja z portem usługi produkcyjnej"
fi

if [[ -n "$PORT_STAGING" && "$PORT_STAGING" != "8000" ]]; then
  lab_port_nasluchuje "$PORT_STAGING" dowolny "port stagingu (${PORT_STAGING}) faktycznie nasłuchuje"
else
  lab_blad "port stagingu nie nasłuchuje"
fi

if curl -fsS --max-time 2 -o /dev/null "http://127.0.0.1:8000/health" 2> /dev/null; then
  lab_ok "/health usługi produkcyjnej (port 8000) odpowiada"
else
  lab_blad "/health usługi produkcyjnej (port 8000) NIE odpowiada"
fi

if [[ -n "$PORT_STAGING" && "$PORT_STAGING" != "8000" ]] \
  && curl -fsS --max-time 2 -o /dev/null "http://127.0.0.1:${PORT_STAGING}/health" 2> /dev/null; then
  lab_ok "/health usługi stagingowej odpowiada"
else
  lab_blad "/health usługi stagingowej NIE odpowiada"
fi

lab_wynik_zawiera "systemctl show -p ExecStart --value ${STAGING}" '\.venv' \
  "ExecStart stagingu wskazuje Pythona ze środowiska wirtualnego (.venv)"

WD_STAGING="$(systemctl show -p WorkingDirectory --value "$STAGING" 2> /dev/null || true)"
if [[ -n "$WD_STAGING" && -d "$WD_STAGING" ]]; then
  lab_ok "katalog roboczy stagingu istnieje"
else
  lab_blad "katalog roboczy stagingu nie istnieje"
fi

lab_wskazowka "To trzy niezależne przyczyny. Napraw jedną, uruchom usługę ponownie i przeczytaj NOWY komunikat błędu — poprzedni zniknie, gdy pierwsza przeszkoda ustąpi."
lab_zakoncz
