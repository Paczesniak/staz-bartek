#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox"
readonly NAKLADKA_DIR="/etc/systemd/system/${JEDNOSTKA}.service.d"
readonly NAKLADKA_PLIK="${NAKLADKA_DIR}/99-lab.conf"
readonly API="${LAB_DOM}/staz/aplikacja/api"
readonly PY="${API}/.venv/bin/python"

if [[ -f "$NAKLADKA_PLIK" ]]; then
  printf 'Z14 już przygotowane wcześniej — nie dotykam istniejącego stanu.\n'
  exit 0
fi

if [[ -x "$PY" && -d "$API" ]]; then
  SEED_SKRYPT="$(mktemp)"
  trap 'rm -f -- "$SEED_SKRYPT"' EXIT
  chmod 644 -- "$SEED_SKRYPT"

  cat > "$SEED_SKRYPT" << 'PYEOF'
import sys

sys.path.insert(0, ".")
from app.db import create_db_engine
from app.repository import count_links, insert_link

engine = create_db_engine("sqlite:///links.db")
with engine.connect() as connection:
    if count_links(connection) == 0:
        insert_link(connection, "lab-seed-1", "https://przyklad.test/lab-seed-1")
        insert_link(connection, "lab-seed-2", "https://przyklad.test/lab-seed-2")
        insert_link(connection, "lab-seed-3", "https://przyklad.test/lab-seed-3")
        connection.commit()
PYEOF

  (cd "$API" && sudo -u "$LAB_UZYTKOWNIK" -H "$PY" "$SEED_SKRYPT") > /dev/null 2>&1 || true
fi

mkdir -p -- "$NAKLADKA_DIR"

cat > "$NAKLADKA_PLIK" << 'UNIT'
[Service]
Environment=APP_PORT=8080
Environment=DATABASE_URL=sqlite:////var/lib/linkbox/links.db
UNIT

chmod 755 -- "$NAKLADKA_DIR"
chown root:root -- "$NAKLADKA_DIR"
chmod 644 -- "$NAKLADKA_PLIK"
chown root:root -- "$NAKLADKA_PLIK"

systemctl daemon-reload
systemctl restart "$JEDNOSTKA"

lab_dziennik_mentora "Z14: podłożono ${NAKLADKA_PLIK} z dwiema wadami naraz: Environment=APP_PORT=8080 (front i stażysta oczekują 8000) oraz Environment=DATABASE_URL=sqlite:////var/lib/linkbox/links.db (katalog /var/lib/linkbox celowo nie istnieje). Po utworzeniu: daemon-reload + restart linkbox — zepsucie wchodzi w życie natychmiast, nie dopiero przy kolejnym restarcie."
printf 'Przygotowano Z14.\n'
