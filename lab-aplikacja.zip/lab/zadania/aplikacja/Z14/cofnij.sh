#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox"
readonly NAKLADKA_DIR="/etc/systemd/system/${JEDNOSTKA}.service.d"
readonly NAKLADKA_PLIK="${NAKLADKA_DIR}/99-lab.conf"

if [[ -f "$NAKLADKA_PLIK" ]]; then
  rm -f -- "$NAKLADKA_PLIK"
  rmdir -- "$NAKLADKA_DIR" 2> /dev/null || true
  systemctl daemon-reload
  systemctl restart "$JEDNOSTKA"
fi

printf 'Cofnięto Z14: usunięto nakładkę 99-lab.conf, usługa linkbox wróciła do Twojej własnej konfiguracji. Kod, .venv i baza danych nie zostały ruszone.\n'
