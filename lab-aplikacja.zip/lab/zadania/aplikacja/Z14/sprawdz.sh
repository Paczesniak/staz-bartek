#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

readonly JEDNOSTKA="linkbox"
readonly API="${LAB_DOM}/staz/aplikacja/api"
readonly WEB="${LAB_DOM}/staz/aplikacja/web"
readonly PY="${API}/.venv/bin/python"
readonly BAZA="${API}/links.db"

lab__port_pid() {
  local port="$1" linia lokalny port_lok proc_info
  command -v ss > /dev/null 2>&1 || return 1
  while IFS= read -r linia; do
    [[ -z "$linia" ]] && continue
    lokalny="$(awk '{print $4}' <<< "$linia")"
    port_lok="${lokalny##*:}"
    [[ "$port_lok" == "$port" ]] || continue
    proc_info="$(awk '{print $NF}' <<< "$linia")"
    if [[ "$proc_info" =~ pid=([0-9]+) ]]; then
      printf '%s' "${BASH_REMATCH[1]}"
      return 0
    fi
  done < <(ss -tlnpH 2> /dev/null || true)
  return 1
}

lab__proc_env_wartosc() {
  local pid="$1" zmienna="$2" wpis
  [[ -n "$pid" && "$pid" != "0" && -r "/proc/${pid}/environ" ]] || return 1
  while IFS= read -r -d '' wpis; do
    if [[ "$wpis" == "${zmienna}="* ]]; then
      printf '%s' "${wpis#*=}"
      return 0
    fi
  done < "/proc/${pid}/environ"
  return 1
}

lab_port_nasluchuje 8000 0.0.0.0 "port 8000 nasłuchuje na 0.0.0.0"

MAINPID="$(systemctl show -p MainPID --value "$JEDNOSTKA" 2> /dev/null || true)"
SOCKET_PID="$(lab__port_pid 8000 || true)"
if [[ -n "$MAINPID" && "$MAINPID" != "0" && -n "$SOCKET_PID" && "$SOCKET_PID" == "$MAINPID" ]]; then
  lab_ok "port 8000 jest w rękach głównego procesu usługi linkbox (MainPID)"
else
  lab_blad "port 8000 NIE jest w rękach MainPID usługi linkbox"
fi

HEALTH_BODY="$(curl -fsS --max-time 3 "http://127.0.0.1:8000/health" 2> /dev/null || true)"
if grep -Eq '"database"[[:space:]]*:[[:space:]]*"ok"' <<< "$HEALTH_BODY"; then
  lab_ok "/health odpowiada 200 z database: ok"
else
  lab_blad "/health NIE odpowiada 200 z database: ok"
fi

LINKS_TMP="$(mktemp)"
trap 'rm -f -- "$LINKS_TMP"' EXIT
HTTP_KOD="$(curl -s --max-time 3 -o "$LINKS_TMP" -w '%{http_code}' "http://127.0.0.1:8000/api/links" 2> /dev/null || true)"

if [[ "$HTTP_KOD" == "200" ]]; then
  lab_ok "/api/links odpowiada kodem 200"
else
  lab_blad "/api/links NIE odpowiada kodem 200 (dostałem: ${HTTP_KOD:-brak połączenia})"
fi

LICZBA_API=""
if [[ "$HTTP_KOD" == "200" && -x "$PY" ]]; then
  LICZBA_API="$("$PY" -c 'import json, sys

with open(sys.argv[1], encoding="utf-8") as f:
    dane = json.load(f)
print(len(dane))
' "$LINKS_TMP" 2> /dev/null || true)"
fi

LICZBA_DB=""
if [[ -f "$BAZA" && -x "$PY" ]]; then
  LICZBA_DB="$("$PY" -c 'import sqlite3, sys

polaczenie = sqlite3.connect(sys.argv[1])
try:
    print(polaczenie.execute("SELECT COUNT(*) FROM links").fetchone()[0])
except sqlite3.Error:
    print(-1)
' "$BAZA" 2> /dev/null || true)"
fi

if [[ "$LICZBA_API" =~ ^[0-9]+$ && "$LICZBA_DB" =~ ^[0-9]+$ \
  && "$LICZBA_API" == "$LICZBA_DB" && "$LICZBA_API" -gt 0 ]]; then
  lab_ok "liczba linków z /api/links zgadza się z links.db i jest większa od zera"
else
  lab_blad "liczba linków z /api/links NIE zgadza się z links.db (albo któreś jest puste/niedostępne)"
fi

APP_PORT_EFEKTYWNY="$(lab__proc_env_wartosc "$MAINPID" APP_PORT || true)"
if [[ "$APP_PORT_EFEKTYWNY" != "8080" ]]; then
  lab_ok "efektywny APP_PORT usługi nie jest ustawiony na 8080"
else
  lab_blad "usługa nadal efektywnie działa z APP_PORT=8080"
fi

DATABASE_URL_EFEKTYWNY="$(lab__proc_env_wartosc "$MAINPID" DATABASE_URL || true)"
if [[ -z "$DATABASE_URL_EFEKTYWNY" || "$DATABASE_URL_EFEKTYWNY" != *"/var/lib/linkbox"* ]]; then
  lab_ok "efektywny DATABASE_URL usługi nie wskazuje już na nieistniejący katalog /var/lib/linkbox"
else
  lab_blad "efektywny DATABASE_URL usługi nadal wskazuje na /var/lib/linkbox — nakładka labu nadal obowiązuje"
fi

lab_plik_zawiera "${WEB}/config.js" ':8000' "config.js frontu nadal wskazuje port 8000"

lab_wskazowka "systemctl cat pokazuje złożoną, obowiązującą treść usługi razem ze wszystkimi nakładkami — nie tylko plik, który sam napisałeś."
lab_zakoncz
