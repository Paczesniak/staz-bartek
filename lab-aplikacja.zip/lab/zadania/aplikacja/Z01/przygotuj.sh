#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z01 nie wymaga przygotowania — pracujesz na kodzie, który już masz w ~/staz/aplikacja.\n'
