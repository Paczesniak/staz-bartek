#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z01 nie zostawia artefaktów do posprzątania.\n'
