#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"
WEB="$LAB_DOM/staz/aplikacja/web"

lab_jest_katalog "$API" "katalog aplikacja/api istnieje"
lab_jest_plik "$API/requirements.txt" "aplikacja/api/requirements.txt istnieje"
lab_jest_katalog "$WEB" "katalog aplikacja/web istnieje"
lab_jest_plik "$WEB/config.js" "aplikacja/web/config.js istnieje"

lab_zakoncz
