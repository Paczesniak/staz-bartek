#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z02 nie wymaga przygotowania — środowisko wirtualne zakładasz sam, w aplikacja/api.\n'
