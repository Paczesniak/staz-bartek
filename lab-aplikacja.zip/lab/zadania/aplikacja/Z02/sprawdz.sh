#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"
PY="$API/.venv/bin/python"

lab_jest_katalog "$API/.venv" "katalog .venv/ istnieje w aplikacja/api"

if [[ -x "$PY" ]]; then
  lab_ok "interpreter .venv/bin/python istnieje i jest wykonywalny"
else
  lab_blad "interpreter .venv/bin/python nie istnieje albo nie jest wykonywalny"
fi

if [[ -x "$PY" ]] && "$PY" -c 'import fastapi, uvicorn, sqlalchemy, alembic' > /dev/null 2>&1; then
  lab_ok "zależności aplikacji (fastapi, uvicorn, sqlalchemy, alembic) są zainstalowane w .venv"
else
  lab_blad "zależności aplikacji nie importują się w środowisku .venv"
fi

lab_zakoncz
