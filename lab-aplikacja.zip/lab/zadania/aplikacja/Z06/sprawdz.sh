#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"
STAZ_REPO="$LAB_DOM/staz"

lab_jest_plik "$API/.env" "plik .env istnieje w aplikacja/api"
lab_plik_zawiera "$API/.env" '^[A-Za-z_][A-Za-z0-9_]*=' "plik .env zawiera co najmniej jedno przypisanie NAZWA=wartość"

if git -C "$STAZ_REPO" check-ignore -q aplikacja/api/.env 2> /dev/null; then
  lab_ok "plik .env jest zignorowany przez git"
else
  lab_blad "plik .env NIE jest zignorowany przez git"
fi

if git -C "$STAZ_REPO" ls-files --error-unmatch aplikacja/api/.env > /dev/null 2>&1; then
  lab_blad "plik .env jest śledzony przez git (trafiłby do repozytorium)"
else
  lab_ok "plik .env nie jest śledzony przez git"
fi

lab_zakoncz
