#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z06 nie wymaga przygotowania — kopię .env robisz sam, z .env.example w aplikacja/api.\n'
