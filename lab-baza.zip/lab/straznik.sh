#!/bin/bash
# ==============================================================================
# straznik.sh — reaguje, gdy ktoś zagląda do walidatorów
# ==============================================================================
#
# Nie jest to inwigilacja i nie działa po cichu: reakcja pojawia się NA EKRANIE
# stażysty w tej samej sekundzie. On wie, że został zauważony, mentor wie, że
# zaglądał — nikt nikogo nie podgląda zza pleców.
#
# Po co: czytanie walidatora, żeby znaleźć wymagane słowo kluczowe, jest
# racjonalną strategią, gdy walidator faktycznie wymaga słów. Od dnia
# „aplikacja" nie wymaga — sprawdza stan systemu. Ten skrypt jest żartem,
# który to komunikuje, a nie karą.
#
# Wymaga: inotify-tools. Bez niego kończy się cicho i nic nie psuje.
# ==============================================================================

set -Eeuo pipefail

KATALOG_ZADAN="/opt/lab/zadania"
DZIENNIK="/var/lib/lab/log/mentor.log"
ODSTEP_SEKUND=60 # nie krzyczymy częściej niż raz na minutę na ten sam plik

if ! command -v inotifywait > /dev/null 2>&1; then
  printf 'straznik: brak inotify-tools, nic nie robię\n' >&2
  exit 0
fi

[[ -d "$KATALOG_ZADAN" ]] || exit 0

# ------------------------------------------------------------------------------
# Komunikat na terminal stażysty
# ------------------------------------------------------------------------------

pokaz_komunikat() {
  local plik="$1"
  local czerwony='\033[1;31m' zolty='\033[1;33m' reset='\033[0m'

  # `wall` trafia na wszystkie zalogowane terminale — także te w innych sesjach
  # SSH, więc komunikat zobaczy niezależnie od tego, w którym oknie siedzi.
  {
    printf '\n'
    printf '%b' "${czerwony}"
    cat << 'GRAFIKA'
   ┌─────────────────────────────────────────────┐
   │                                             │
   │        M A M   C I Ę ,   G A G A T K U      │
   │                                             │
   │              ( o.o )                        │
   │               > ^ <                         │
   │                                             │
   └─────────────────────────────────────────────┘
GRAFIKA
    printf '%b' "${reset}"
    printf '\n'
    printf '%b' "${zolty}"
    printf '   Zaglądałeś do: %s\n' "${plik#"$KATALOG_ZADAN"/}"
    printf '%b' "${reset}"
    printf '\n'
    printf '   Nie ma tam odpowiedzi. Od tego dnia walidatory sprawdzają\n'
    printf '   STAN SYSTEMU — czy port nasłuchuje, czy usługa wstaje po\n'
    printf '   restarcie, czy plik zniknął. Nie ma słów kluczowych do\n'
    printf '   trafienia, więc nie ma czego wyszukać.\n'
    printf '\n'
    printf '   Czytać wolno — to twoja maszyna. Ale szybciej dojdziesz\n'
    printf '   do celu, robiąc zadanie.\n'
    printf '\n'
  } | wall 2> /dev/null || true
}

# ------------------------------------------------------------------------------
# Nasłuch
# ------------------------------------------------------------------------------

deklaruj_start() {
  printf '%s  straznik  wystartował, obserwuję %s\n' "$(date -Is)" "$KATALOG_ZADAN" \
    >> "$DZIENNIK" 2> /dev/null || true
}

deklaruj_start

declare -A ostatnio=()

# -m: nie kończ po pierwszym zdarzeniu, -r: rekurencyjnie, -e access: odczyt.
# Interesują nas wyłącznie sprawdz.sh — przygotuj.sh i cofnij.sh czyta sam lab.
inotifywait -m -r -e access --format '%w%f' "$KATALOG_ZADAN" 2> /dev/null |
  while IFS= read -r plik; do
    # Reagujemy WYŁĄCZNIE na walidatory w podkatalogach zadań (…/Z07/sprawdz.sh).
    #
    # Pliki leżące bezpośrednio w katalogu dnia — ROZWIAZANIA.md
    # i KLUCZ-ODPOWIEDZI.txt — są celowo poza zasięgiem strażnika. To jest
    # easter egg: kto tam zajrzy, dostaje palec i zdanie na serio, i tyle.
    # Ciekawość nagradzamy, szukanie gotowców w walidatorach komentujemy.
    [[ "$plik" =~ /Z[0-9]+/sprawdz\.sh$ ]] || continue

    teraz="$(date +%s)"
    poprzednio="${ostatnio[$plik]:-0}"
    ((teraz - poprzednio < ODSTEP_SEKUND)) && continue
    ostatnio["$plik"]="$teraz"

    # Lab sam czyta walidatory przy `lab grade` — wtedy nie krzyczymy.
    # Rozpoznajemy po tym, że w drzewie procesów siedzi `lab`.
    if pgrep -f '/opt/lab/bin/lab' > /dev/null 2>&1; then
      continue
    fi

    pokaz_komunikat "$plik"
    printf '%s  straznik  odczyt %s poza `lab grade`\n' "$(date -Is)" "$plik" \
      >> "$DZIENNIK" 2> /dev/null || true
  done
