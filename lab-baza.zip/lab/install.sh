#!/bin/bash
# ==============================================================================
# install.sh — instalator labu (kontrakt: lab/KONTRAKT.md)
# ==============================================================================
#
# Kopiuje bin/, lib/ i zadania/ do /opt/lab, ustawia właściciela i prawa,
# zakłada /var/lib/lab (stan zaliczeń + dziennik) i podpina /usr/local/bin/lab.
#
# Użycie:
#   sudo ./install.sh [NAZWA_KONTA_STAZYSTY]
#
# Bez argumentu zakłada konto „staz". Podana nazwa trafia do /etc/lab.conf,
# skąd odczytuje ją lib/common.sh — dzięki temu nie trzeba niczego zaszywać
# w kodzie ani pamiętać o eksportowaniu zmiennej środowiskowej przy każdym
# logowaniu.
#
# Idempotentny: dwukrotne uruchomienie nic nie psuje ani nie mnoży, a stan
# zaliczeń i dziennik z poprzedniej instalacji zostają nietknięte.
# ==============================================================================

set -Eeuo pipefail

if ((BASH_VERSINFO[0] < 4)); then
  printf 'Ten instalator wymaga Bash w wersji co najmniej 4 (jest: %s).\n' "${BASH_VERSION}" >&2
  exit 1
fi

readonly LAB_CEL="/opt/lab"
readonly LAB_KONFIG="/etc/lab.conf"
readonly LAB_SYMLINK="/usr/local/bin/lab"

# ------------------------------------------------------------------------------
# Argumenty
# ------------------------------------------------------------------------------

lab_inst__pomoc() {
  cat << POMOC
Użycie: $(basename -- "$0") [NAZWA_KONTA_STAZYSTY]

Instaluje lab w ${LAB_CEL} i podpina polecenie „lab" w /usr/local/bin.
Bez argumentu zakłada konto o nazwie „staz".

Przykład:
  sudo $(basename -- "$0")            # domyślne konto: staz
  sudo $(basename -- "$0") bartek     # konto stażysty: bartek
POMOC
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  lab_inst__pomoc
  exit 0
fi

if (($# > 1)); then
  printf 'Za dużo argumentów.\n\n' >&2
  lab_inst__pomoc >&2
  exit 2
fi

readonly UZYTKOWNIK_STAZU="${1:-staz}"
if [[ ! "$UZYTKOWNIK_STAZU" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
  printf 'Nieprawidłowa nazwa konta: %s\n' "$UZYTKOWNIK_STAZU" >&2
  exit 2
fi

# ------------------------------------------------------------------------------
# Uprawnienia i lokalizacja źródła
# ------------------------------------------------------------------------------

if ((EUID != 0)); then
  if ! command -v sudo > /dev/null 2>&1; then
    printf 'Instalator wymaga roota, a sudo nie jest dostępne. Uruchom jako root.\n' >&2
    exit 1
  fi
  # Ścieżka bezwzględna i jawne `bash`, nie samo "$0":
  #   - przy wywołaniu „lab/install.sh" sudo szukałoby tego w PATH,
  #   - a po rozpakowaniu archiwum plik bywa bez bitu wykonywalności,
  # więc jedno i drugie kończyło się „command not found".
  exec sudo -- bash "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)/$(basename -- "${BASH_SOURCE[0]}")" "$@"
fi

LAB_ZRODLO="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
readonly LAB_ZRODLO

for wymagany in bin lib zadania; do
  if [[ ! -d "${LAB_ZRODLO}/${wymagany}" ]]; then
    printf 'Brak katalogu %s/%s — uruchamiasz install.sh z niekompletnego źródła?\n' \
      "$LAB_ZRODLO" "$wymagany" >&2
    exit 1
  fi
done

printf '\n%s\n' "== Instalacja labu =="
printf 'Źródło:            %s\n' "$LAB_ZRODLO"
printf 'Cel:               %s\n' "$LAB_CEL"
printf 'Konto stażysty:    %s\n\n' "$UZYTKOWNIK_STAZU"

# ------------------------------------------------------------------------------
# moduly.conf — jedyny plik, który NARASTA z dnia na dzień
# ------------------------------------------------------------------------------
#
# Każda paczka niesie własną kopię tego pliku, a instalacja podmienia całe
# lib/. Przy instalowaniu dni po kolei to bez znaczenia — nowsza paczka zna
# wszystkie wcześniejsze dni. Ale ponowna instalacja STARSZEJ paczki wycięłaby
# z konfiguracji dni już zainstalowane: katalogi zadania/<DZIEŃ>/ zostałyby na
# dysku, a „lab dzien <DZIEŃ>" przestałby je widzieć. Cicho i myląco — dokładnie
# ten rodzaj usterki, na który stażysta traci godzinę, zanim zapyta. Dlatego
# przed podmianą zapamiętujemy stary plik, a po niej dokładamy z niego dni,
# o których nowy nie wie.

lab_inst__scal_moduly() {
  local stary="$1" nowy="$2"
  local -a brakujace=()
  local dzien znane

  znane="$(awk '!/^[[:space:]]*(#|$)/ { print $1 }' "$nowy" | sort -u)"
  while read -r dzien; do
    [[ -n "$dzien" ]] || continue
    grep -qxF -- "$dzien" <<< "$znane" || brakujace+=("$dzien")
  done < <(awk '!/^[[:space:]]*(#|$)/ { print $1 }' "$stary" | sort -u)

  ((${#brakujace[@]} > 0)) || return 0

  printf '  → dokładam do moduly.conf dni z poprzedniej instalacji: %s\n' "${brakujace[*]}"
  {
    printf '\n# Dni z wcześniejszej instalacji, których ta paczka nie zawiera.\n'
    for dzien in "${brakujace[@]}"; do
      awk -v d="$dzien" '!/^[[:space:]]*(#|$)/ && $1 == d' "$stary"
    done
  } >> "$nowy"
}

# ------------------------------------------------------------------------------
# Kopiowanie
# ------------------------------------------------------------------------------

mkdir -p -- "$LAB_CEL"

STARE_MODULY=""
if [[ -f "${LAB_CEL}/lib/moduly.conf" ]]; then
  STARE_MODULY="$(mktemp)"
  cp -- "${LAB_CEL}/lib/moduly.conf" "$STARE_MODULY"
fi

# Lab bywa uruchamiany prosto z katalogu docelowego (ktoś skopiował całość do
# /opt/lab i odpalił instalator stamtąd). Kopiowanie katalogu na samego siebie
# kończy się błędem `cp`, więc ten przypadek pomijamy — pliki są już na miejscu,
# zostaje im tylko nadać prawa w dalszej części skryptu.
if [[ "$LAB_ZRODLO" == "$LAB_CEL" ]]; then
  printf '  → źródło jest katalogiem docelowym, pomijam kopiowanie\n'
else
  for element in bin lib zadania; do
    printf '  → kopiuję %s/\n' "$element"
    cp -a -- "${LAB_ZRODLO}/${element}" "$LAB_CEL/"
  done

  if [[ -f "${LAB_ZRODLO}/README.md" ]]; then
    cp -a -- "${LAB_ZRODLO}/README.md" "$LAB_CEL/README.md"
  fi
fi

if [[ -n "$STARE_MODULY" ]]; then
  if [[ -f "${LAB_CEL}/lib/moduly.conf" ]]; then
    lab_inst__scal_moduly "$STARE_MODULY" "${LAB_CEL}/lib/moduly.conf"
  fi
  rm -f -- "$STARE_MODULY"
fi

# ------------------------------------------------------------------------------
# Właściciel i prawa — dokładnie wg tabeli w KONTRAKT.md
# ------------------------------------------------------------------------------

printf '  → ustawiam właściciela i prawa\n'

chown -R root:root -- "$LAB_CEL"
find "$LAB_CEL" -type d -exec chmod 755 {} +
find "$LAB_CEL" -type f -exec chmod 644 {} +
find "$LAB_CEL" -type f -name '*.sh' -exec chmod 755 {} +
chmod 755 -- "${LAB_CEL}/bin/lab" "${LAB_CEL}/bin/lab-raport"

# ------------------------------------------------------------------------------
# /var/lib/lab — stan zaliczeń i dziennik (nie kasujemy istniejącej treści)
# ------------------------------------------------------------------------------

printf '  → przygotowuję /var/lib/lab\n'

install -d -m 755 -o root -g root -- /var/lib/lab
install -d -m 777 -o root -g root -- /var/lib/lab/stan
install -d -m 755 -o root -g root -- /var/lib/lab/log

if [[ ! -f /var/lib/lab/log/lab.log ]]; then
  : > /var/lib/lab/log/lab.log
fi
chown root:root -- /var/lib/lab/log/lab.log
chmod 666 -- /var/lib/lab/log/lab.log

# /var/lib/lab/biezacy-dzien — który dzień jest „bieżący" (lab dzien).
# Lekkie polecenie, celowo bez sudo, więc plik musi już istnieć i być
# zapisywalny przez każdego — inaczej pierwsze `lab dzien` na świeżej
# instalacji nie mogłoby go utworzyć (katalog /var/lib/lab/ jest 755).
if [[ ! -f /var/lib/lab/biezacy-dzien ]]; then
  : > /var/lib/lab/biezacy-dzien
fi
chown root:root -- /var/lib/lab/biezacy-dzien
chmod 666 -- /var/lib/lab/biezacy-dzien

# ------------------------------------------------------------------------------
# /etc/lab.conf — nazwa konta stażysty, czyta ją lib/common.sh
# ------------------------------------------------------------------------------

printf '  → zapisuję %s\n' "$LAB_KONFIG"
printf 'LAB_UZYTKOWNIK=%s\n' "$UZYTKOWNIK_STAZU" > "$LAB_KONFIG"
chown root:root -- "$LAB_KONFIG"
chmod 644 -- "$LAB_KONFIG"

# ------------------------------------------------------------------------------
# Strażnik — reaguje, gdy ktoś zagląda do walidatorów poza `lab grade`
# ------------------------------------------------------------------------------
#
# Nie działa po cichu: komunikat pojawia się na terminalu stażysty w tej samej
# sekundzie. Wymaga inotify-tools i systemd — bez któregokolwiek po prostu
# pomijamy, bo to dodatek, a nie warunek działania labu.

if [[ -f "${LAB_ZRODLO}/straznik.sh" ]]; then
  cp -a -- "${LAB_ZRODLO}/straznik.sh" "${LAB_CEL}/straznik.sh"
  chmod 755 -- "${LAB_CEL}/straznik.sh"

  if [[ -f "${LAB_ZRODLO}/lab-straznik.service" ]] && command -v systemctl > /dev/null 2>&1; then

    # Strażnik potrzebuje inotify-tools, którego Ubuntu Server nie ma domyślnie.
    # Doinstalowujemy sami — instalator i tak działa jako root. Próbujemy
    # apt-get, a gdy go nie ma, apt; przy niepowodzeniu odświeżamy indeks
    # i ponawiamy. Instalacji NIE pomijamy po cichu — gdy się nie uda,
    # mówimy o tym wyraźnie, bo bez tego pakietu strażnik nie wystartuje.
    if ! command -v inotifywait > /dev/null 2>&1; then
      MENEDZER=""
      for kandydat in apt-get apt; do
        if command -v "$kandydat" > /dev/null 2>&1; then
          MENEDZER="$kandydat"
          break
        fi
      done

      if [[ -n "$MENEDZER" ]]; then
        printf '  → doinstalowuję inotify-tools przez %s (potrzebny strażnikowi)
' "$MENEDZER"
        if ! DEBIAN_FRONTEND=noninteractive "$MENEDZER" install -y -qq inotify-tools > /dev/null 2>&1; then
          # Pakietu może nie być w lokalnym indeksie — odśwież i spróbuj raz jeszcze.
          DEBIAN_FRONTEND=noninteractive "$MENEDZER" update -qq > /dev/null 2>&1 || true
          DEBIAN_FRONTEND=noninteractive "$MENEDZER" install -y -qq inotify-tools > /dev/null 2>&1 || true
        fi
      else
        printf '  → nie znalazłem apt-get ani apt — inotify-tools trzeba zainstalować ręcznie
' >&2
      fi
    fi

    if command -v inotifywait > /dev/null 2>&1; then
      printf '  → uruchamiam strażnika walidatorów
'
      cp -a -- "${LAB_ZRODLO}/lab-straznik.service" /etc/systemd/system/lab-straznik.service
      systemctl daemon-reload > /dev/null 2>&1 || true
      systemctl enable --now lab-straznik.service > /dev/null 2>&1 || true
    else
      printf '
  UWAGA: strażnik NIE działa — nie udało się zainstalować inotify-tools.
' >&2
      printf '  Zainstaluj go ręcznie i uruchom instalator ponownie:
' >&2
      printf '    sudo apt install inotify-tools

' >&2
    fi
  fi
fi

# ------------------------------------------------------------------------------
# Dowiązanie w /usr/local/bin
# ------------------------------------------------------------------------------

printf '  → podpinam %s\n' "$LAB_SYMLINK"
ln -sf -- "${LAB_CEL}/bin/lab" "$LAB_SYMLINK"

# ------------------------------------------------------------------------------
# Weryfikacja
# ------------------------------------------------------------------------------

if [[ ! -x "${LAB_CEL}/bin/lab" ]]; then
  printf '\nInstalacja niekompletna: %s/bin/lab nie jest wykonywalny.\n' "$LAB_CEL" >&2
  exit 1
fi

if ! command -v lab > /dev/null 2>&1; then
  printf '\nUwaga: %s nie jest jeszcze na PATH w tej sesji powłoki.\n' "$LAB_SYMLINK" >&2
  printf 'Nowe logowania będą je widzieć automatycznie (PATH zwykle zawiera /usr/local/bin).\n' >&2
fi

# ------------------------------------------------------------------------------
# Sprzątanie po instalacji
# ------------------------------------------------------------------------------
#
# Lab żyje już w /opt/lab. Rozpakowany katalog w katalogu domowym jest od tej
# chwili zbędną kopią — a kopia poza /opt to kopia, w której można grzebać bez
# sudo. Usuwamy go.
#
# Archiwum .zip zostawiamy CELOWO. Przychodzi do stażysty przez repozytorium,
# więc git je śledzi — skasowanie zrobiłoby „deleted:" w `git status`, a przy
# najbliższym commicie wypadłoby z repozytorium. Waży kilkadziesiąt kilobajtów
# i jest zapisem tego, którą wersję labu dostał danego dnia.
DOM_STAZYSTY="$(getent passwd "$UZYTKOWNIK_STAZU" | cut -d: -f6)"

if [[ "$LAB_ZRODLO" != "$LAB_CEL" && -n "$DOM_STAZYSTY" && "$LAB_ZRODLO" == "$DOM_STAZYSTY"/* ]]; then
  # Nie ruszamy katalogu, który jest częścią repozytorium — usunięcie
  # śledzonych plików zaśmieciłoby stażyście `git status`.
  if git -C "$LAB_ZRODLO" rev-parse --is-inside-work-tree > /dev/null 2>&1; then
    printf '  → źródło leży w repozytorium, zostawiam je nietknięte\n'

    # Rozpakowany katalog zostaje na dysku, ale nie ma czego szukać w historii —
    # to kopia tego, co i tak przyszło w archiwum. Bez wpisu w .gitignore
    # wisiałby w `git status` jako nieśledzony i zaśmiecał stażyście widok
    # przed każdym commitem.
    KORZEN_REPO="$(git -C "$LAB_ZRODLO" rev-parse --show-toplevel 2> /dev/null || true)"
    NAZWA_KATALOGU="$(basename -- "$LAB_ZRODLO")"
    if [[ -n "$KORZEN_REPO" ]] \
      && ! grep -qxF "${NAZWA_KATALOGU}/" "${KORZEN_REPO}/.gitignore" 2> /dev/null; then
      printf '%s/\n' "$NAZWA_KATALOGU" >> "${KORZEN_REPO}/.gitignore"
      chown "${UZYTKOWNIK_STAZU}:$(id -gn "$UZYTKOWNIK_STAZU")" "${KORZEN_REPO}/.gitignore" 2> /dev/null || true
      printf '  → dopisałem „%s/" do .gitignore repozytorium\n' "$NAZWA_KATALOGU"
    fi
  else
    printf '  → sprzątam rozpakowaną kopię w katalogu domowym\n'
    rm -rf -- "$LAB_ZRODLO"
  fi
fi

printf '\n%s\n' "== Gotowe =="
printf 'lab jest zainstalowany w %s, dowiązany jako %s.\n' "$LAB_CEL" "$LAB_SYMLINK"
printf 'Konto stażysty: %s (katalog domowy ustala lib/common.sh przez getent).\n' "$UZYTKOWNIK_STAZU"
printf 'Uruchom „lab pomoc", żeby zobaczyć dostępne polecenia.\n\n'
