#!/bin/bash
# ==============================================================================
# lib/common.sh — wspólne API labu (kontrakt: lab/KONTRAKT.md)
# ==============================================================================
#
# Kto tego używa:
#   - każdy sprawdz.sh zaczyna się od `source /opt/lab/lib/common.sh`
#     i kończy wywołaniem `lab_zakoncz`,
#   - `bin/lab` i `bin/lab-raport` też to sourcują — po wspólne stałe,
#     kolory i logowanie.
#
# Co tu jest:
#   1. Tryb pracy powłoki (strict mode) i pułapka na nieoczekiwane błędy
#   2. Lokalizacje: LAB_BAZA, LAB_STAN_DIR, LAB_LOG, LAB_BIEZACY_DZIEN_PLIK
#   3. Tożsamość stażysty: LAB_UZYTKOWNIK, LAB_DOM, LAB_GRUPA — ustalane
#      niezależnie od tego, kto uruchomił skrypt (root, sudo, sam stażysta)
#   4. Kolory przez tput, z wykrywaniem terminala
#   5. Funkcje wewnętrzne (prefiks lab__) — nie są częścią kontraktu,
#      wolno je zmieniać bez porozumienia z innymi agentami
#   6. Publiczne API walidatorów (prefiks lab_) — DOKŁADNIE wg KONTRAKT.md,
#      nazw i sygnatur tych funkcji nie wolno zmieniać
#
# ==============================================================================
#
# Plik jest biblioteką: część stałych i kolorów jest używana wyłącznie przez
# skrypty, które go sourcują (bin/lab, bin/lab-raport, zadania/*/sprawdz.sh),
# nie przez sam common.sh — stąd wyłączenie SC2034 dla całego pliku poniżej.
# shellcheck disable=SC2034

# Zabezpieczenie przed dwukrotnym załadowaniem w tym samym procesie —
# ponowne `source` nie wywali się na próbie nadpisania zmiennych `readonly`.
if [[ -n "${LAB__COMMON_ZALADOWANY:-}" ]]; then
  # exit to celowy fallback na wypadek, gdyby return się nie udał (plik
  # uruchomiony bezpośrednio, a nie sourcowany).
  # shellcheck disable=SC2317
  return 0 2> /dev/null || exit 0
fi
LAB__COMMON_ZALADOWANY=1

set -Eeuo pipefail
# inherit_errexit istnieje od Bash 4.4 — Ubuntu 24.04 ma Bash 5.2, więc jest bezpiecznie.
shopt -s inherit_errexit 2> /dev/null || true

# Jeśli system ma lokalizację C.UTF-8, a wywołujący nic nie ustawił — użyj jej.
# Symbole ✓ ✗ ℹ → muszą być liczone jako pojedyncze znaki przy wyrównywaniu tabel;
# bez lokalizacji UTF-8 wyrównanie w `lab status` mogłoby się rozjechać.
if [[ -z "${LC_ALL:-}" ]] && command -v locale > /dev/null 2>&1 \
  && locale -a 2> /dev/null | grep -qix 'C.utf8\|C.UTF-8'; then
  export LC_ALL=C.UTF-8
fi

# ------------------------------------------------------------------------------
# 2. Lokalizacje (stałe kontraktu)
# ------------------------------------------------------------------------------

readonly LAB_BAZA="/opt/lab"
readonly LAB_STAN_DIR="/var/lib/lab/stan"
readonly LAB_LOG_DIR="/var/lib/lab/log"
readonly LAB_LOG="${LAB_LOG_DIR}/lab.log"
readonly LAB_KONFIG="/etc/lab.conf"
readonly LAB_MODULY_CONF="${LAB_BAZA}/lib/moduly.conf"

# Numery zadań powtarzają się między dniami (F1 i F2 obie mają np. Z07) —
# `lab dzien <DZIEN>` zapisuje tu, który dzień jest „bieżący" (a `lab start
# DZIEN/MODUŁ` robi to samo przy okazji, gdy dzień podano wprost), żeby
# `lab sprawdz Z07`/`lab reset Z07` (bez jawnego dnia) wiedziały, do którego
# katalogu sięgnąć. Poza /var/lib/lab/stan/ celowo — to nie jest znacznik
# zaliczenia konkretnego zadania, tylko globalny wskaźnik sesji.
readonly LAB_BIEZACY_DZIEN_PLIK="/var/lib/lab/biezacy-dzien"

# ------------------------------------------------------------------------------
# 3. Tożsamość stażysty
# ------------------------------------------------------------------------------
#
# Zasada z kontraktu: LAB_DOM i LAB_UZYTKOWNIK ustalamy niezależnie od tego,
# kto uruchomił skrypt. Pod sudo $HOME wskazuje na /root — dlatego katalogu
# domowego NIE liczymy z $HOME, tylko z realnego wpisu w /etc/passwd konta
# LAB_UZYTKOWNIK.
#
# Kolejność pierwszeństwa dla LAB_UZYTKOWNIK:
#   1. już ustawiona zmienna środowiskowa (np. LAB_UZYTKOWNIK=bartek lab ...)
#   2. wpis LAB_UZYTKOWNIK=... w /etc/lab.conf (zapisywany przez install.sh)
#   3. domyślne „staz"

if [[ -z "${LAB_UZYTKOWNIK:-}" && -r "$LAB_KONFIG" ]]; then
  LAB_UZYTKOWNIK="$(grep -E '^LAB_UZYTKOWNIK=' "$LAB_KONFIG" 2> /dev/null | tail -n1 | cut -d= -f2-)"
fi
: "${LAB_UZYTKOWNIK:=staz}"
readonly LAB_UZYTKOWNIK

# Katalog domowy konta LAB_UZYTKOWNIK, niezależnie od wywołującego.
if LAB_DOM="$(getent passwd "$LAB_UZYTKOWNIK" 2> /dev/null | cut -d: -f6)" && [[ -n "$LAB_DOM" ]]; then
  :
else
  # getent zawiedzie, gdy konto jeszcze nie istnieje (np. w trakcie instalacji) —
  # spadamy na konwencjonalną ścieżkę zamiast przerywać działanie.
  LAB_DOM="/home/${LAB_UZYTKOWNIK}"
fi
readonly LAB_DOM

# Grupa podstawowa konta LAB_UZYTKOWNIK — przydatne w przygotuj.sh/cofnij.sh
# do `chown`, żeby nie zakładać na sztywno, że grupa nazywa się tak samo jak
# użytkownik (zwykle tak jest na Ubuntu, ale nie ma takiej gwarancji).
if LAB_GRUPA="$(id -gn "$LAB_UZYTKOWNIK" 2> /dev/null)" && [[ -n "$LAB_GRUPA" ]]; then
  :
else
  LAB_GRUPA="$LAB_UZYTKOWNIK"
fi
readonly LAB_GRUPA

# ------------------------------------------------------------------------------
# 4. Kolory — tylko gdy stdout jest terminalem; w potoku i w logu czysty tekst
# ------------------------------------------------------------------------------

lab__probuj_tput() {
  tput "$@" 2> /dev/null || printf ''
}

if [[ -t 1 ]] && command -v tput > /dev/null 2>&1; then
  LAB_K_ZIELONY="$(lab__probuj_tput setaf 2)"
  LAB_K_CZERWONY="$(lab__probuj_tput setaf 1)"
  LAB_K_ZOLTY="$(lab__probuj_tput setaf 3)"
  LAB_K_NIEBIESKI="$(lab__probuj_tput setaf 4)"
  LAB_K_SZARY="$(lab__probuj_tput dim)"
  LAB_K_POGRUBIONY="$(lab__probuj_tput bold)"
  LAB_K_RESET="$(lab__probuj_tput sgr0)"
else
  LAB_K_ZIELONY=""
  LAB_K_CZERWONY=""
  LAB_K_ZOLTY=""
  LAB_K_NIEBIESKI=""
  LAB_K_SZARY=""
  LAB_K_POGRUBIONY=""
  LAB_K_RESET=""
fi
readonly LAB_K_ZIELONY LAB_K_CZERWONY LAB_K_ZOLTY LAB_K_NIEBIESKI LAB_K_SZARY LAB_K_POGRUBIONY LAB_K_RESET

# ------------------------------------------------------------------------------
# 5. Funkcje wewnętrzne (lab__*) — poza kontraktem, wolno je zmieniać swobodnie
# ------------------------------------------------------------------------------

# lab__biezacy_uzytkownik — kto NAPRAWDĘ wywołał polecenie, nawet po sudo.
lab__biezacy_uzytkownik() {
  if [[ -n "${SUDO_USER:-}" ]]; then
    printf '%s' "$SUDO_USER"
  else
    id -un 2> /dev/null || printf 'nieznany'
  fi
}

# lab__wyrownaj <tekst> <szerokosc> — dopełnia tekst spacjami z prawej do
# zadanej szerokości liczonej w ZNAKACH (nie bajtach), bezpieczne dla symboli
# ✓ ✗ ℹ → — printf "%-Ns" potrafi się pomylić przy wielobajtowym UTF-8
# w lokalizacjach innych niż UTF-8.
lab__wyrownaj() {
  local tekst="$1" szerokosc="$2" brakujace
  brakujace=$((szerokosc - ${#tekst}))
  if ((brakujace > 0)); then
    printf '%s%*s' "$tekst" "$brakujace" ''
  else
    printf '%s' "$tekst"
  fi
}

# lab__linia <szerokosc> — pozioma linia z myślników do oddzielenia nagłówka
# tabeli. Budowana podstawieniem spacji, bez `tr` — unikamy niepewności co do
# wielobajtowej obsługi `tr` w różnych lokalizacjach.
lab__linia() {
  local szerokosc="$1" linia
  printf -v linia '%*s' "$szerokosc" ''
  printf '%s' "${linia// /-}"
}

# lab__sciezka_znacznika <dzien> <zadanie> — ścieżka pliku-znacznika zaliczenia.
# Sama obecność pliku = zadanie zaliczone; treść = czas zaliczenia. Zaliczenie
# jest TRWAŁE do jawnego `lab reset` — kolejne nieudane `sprawdz` NIE kasują
# tego pliku (patrz lab__sciezka_regresji niżej).
lab__sciezka_znacznika() {
  printf '%s/%s%s.zaliczono' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__sciezka_regresji <dzien> <zadanie> — ścieżka flagi „ostatnie sprawdz
# nie przeszło, mimo że zadanie jest (i zostaje) zaliczone". Późniejsze
# zadania potrafią naruszyć stan, na którym opierał się wcześniejszy
# walidator — zaliczenie mimo to zostaje, ale `lab status`/`lab-raport`
# dyskretnie to sygnalizują. Obecność pliku = flaga ustawiona; treść = kiedy
# wykryto rozjazd. Znika, gdy walidator znów przejdzie czysto albo po
# `lab reset`.
lab__sciezka_regresji() {
  printf '%s/%s%s.regresja' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__sciezka_warunkow <dzien> <zadanie> — ścieżka pliku z liczbą warunków
# spełnionych/wszystkich z OSTATNIEGO uruchomienia sprawdz.sh (dwie liczby,
# rozdzielone spacją). Pisany przez lab_zakoncz przy KAŻDYM zakończeniu
# walidatora, niezależnie od wyniku — `lab grade` czyta to, żeby zbudować
# wynik liczbowy modułu bez parsowania kolorowanego stdout.
lab__sciezka_warunkow() {
  printf '%s/%s%s.warunki' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__sciezka_opisow_bledow <dzien> <zadanie> — opisy (trzeci argument
# lab_blad) z OSTATNIEGO uruchomienia sprawdz.sh, jeden na linię. Pisany
# przez lab_zakoncz przy każdym zakończeniu z co najmniej jednym
# niespełnionym warunkiem (usuwany, gdy warunków zero) — `lab grade`
# dolicza je do trwałego licznika modułu, patrz lab__doliczenie_bledow_modulu.
lab__sciezka_opisow_bledow() {
  printf '%s/%s%s.opisy-bledow' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__sciezka_czestych_bledow_modulu <dzien> <modul> — trwały akumulator
# „LICZBA<TAB>OPIS" (jedna linia na unikalny opis warunku) — ile razy dany
# warunek nie przeszedł w NIEUDANYCH `lab grade` tego modułu, sumowane od
# zawsze (albo od ostatniego `lab reset` zadania z tego modułu — patrz
# cmd_reset). Osobny plik od .opisy-bledow, bo tamten jest per-zadaniowy i
# ulotny (tylko ostatni przebieg), a ten jest per-modułowy i narastający.
lab__sciezka_czestych_bledow_modulu() {
  printf '%s/%s%s.czeste-bledy' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__doliczenie_bledow_modulu <dzien> <modul> <zadania-rozdzielone-spacją>
# — czyta BIEŻĄCE (dopiero co napisane przez sprawdz.sh) opisy błędów
# każdego z podanych zadań, dolicza je do trwałego akumulatora modułu i
# zapisuje z powrotem. Wołaj TYLKO gdy cały przebieg `lab grade` był
# NIEUDANY — przy udanych z definicji nic nie padło, więc nie ma czego liczyć.
lab__doliczenie_bledow_modulu() {
  local dzien="${1:?}" modul="${2:?}" zadania="${3:-}"
  local -A akumulator=()
  local plik_akumulatora
  plik_akumulatora="$(lab__sciezka_czestych_bledow_modulu "$dzien" "$modul")"

  if [[ -f "$plik_akumulatora" ]]; then
    local licz opis_akum
    while IFS=$'\t' read -r licz opis_akum; do
      [[ -z "$opis_akum" ]] && continue
      akumulator["$opis_akum"]="$licz"
    done < "$plik_akumulatora"
  fi

  local zadanie plik_opisow opis
  for zadanie in $zadania; do
    plik_opisow="$(lab__sciezka_opisow_bledow "$dzien" "$zadanie")"
    [[ -f "$plik_opisow" ]] || continue
    while IFS= read -r opis; do
      [[ -z "$opis" ]] && continue
      akumulator["$opis"]=$((${akumulator["$opis"]:-0} + 1))
    done < "$plik_opisow"
  done

  local k
  {
    for k in "${!akumulator[@]}"; do
      printf '%d\t%s\n' "${akumulator[$k]}" "$k"
    done
  } > "$plik_akumulatora"
}

# lab__czeste_bledy_modulu <dzien> <modul> — linie „LICZBA<TAB>OPIS" z
# akumulatora modułu, posortowane malejąco po liczbie, TYLKO dla opisów z
# licznikiem > 1 (pojedyncze niepowodzenie to szum, nie sygnał). Pusto (kod
# 0, bez wyjścia), gdy akumulatora jeszcze nie ma — moduł nigdy nie miał
# nieudanego `lab grade`, to nie błąd.
lab__czeste_bledy_modulu() {
  local plik
  plik="$(lab__sciezka_czestych_bledow_modulu "$1" "$2")"
  [[ -f "$plik" ]] || return 0
  awk -F'\t' '$1 > 1' "$plik" | sort -t "$(printf '\t')" -k1,1 -rn
}

# lab__zapewnij_katalog_staz — upewnia się, że $LAB_DOM/staz istnieje i
# należy do stażysty. Wywołuj PRZED uruchomieniem jakiegokolwiek przygotuj.sh
# (start/reset działają jako root): pojedyncze zadanie potrafi ochronić
# przez `chown` to, co samo stworzyło, ale nie odpowiada za współdzielone
# katalogi nadrzędne ~/staz/ i ~/praca/ (oba używane przez wiele różnych
# zadań, a od modułów też przez `lab koniec <DZIEN>` — patrz ~/praca/wyniki/)
# — bez tej funkcji pierwsze `mkdir -p` wykonane jako root zostawiłoby SAM
# katalog nadrzędny na własności roota, a stażysta nie mógłby w nim założyć
# nawet kolejnego podkatalogu bez sudo. W realnym wdrożeniu ~/staz/ zwykle
# już istnieje (to katalog repozytorium z Dnia 1), więc `mkdir -p` jest tu
# w większości przypadków no-opem — ale nie zawsze (np. świeże konto
# testowe, albo ~/praca/ zanim ktokolwiek go dotknął), więc zabezpieczamy
# oba warianty.
lab__zapewnij_katalog_staz() {
  local katalog
  for katalog in "${LAB_DOM}/staz" "${LAB_DOM}/praca"; do
    mkdir -p -- "$katalog"
    chown -- "${LAB_UZYTKOWNIK}:${LAB_GRUPA}" "$katalog"
  done
}

# lab__znormalizuj_zadanie <surowe> — Z7, z7, Z07, 7 -> Z07 na stdout.
# Zdejmuje opcjonalny prefiks Z/z, wymaga samych cyfr pod spodem, dopełnia
# do dwóch cyfr. Zwraca 1 (bez nic na stdout), gdy wejście nie jest liczbą —
# stażysta przepisuje numer wprost z treści zadania (tam widnieje np. „Z7"),
# więc wiodące zero nie może być pułapką.
lab__znormalizuj_zadanie() {
  local surowe="${1:-}" cyfry
  cyfry="${surowe#[Zz]}"
  [[ "$cyfry" =~ ^[0-9]+$ ]] || return 1
  printf 'Z%02d' "$((10#$cyfry))"
}

# lab__dostepne_dni — unikalne nazwy DZIEN z lib/moduly.conf, jedna na
# linię, w kolejności pierwszego wystąpienia w pliku. Ciche puste wyjście
# (bez błędu), gdy pliku nie da się odczytać — wołający ma sobie z tym
# poradzić (np. po prostu nie dopisać listy dni do komunikatu).
lab__dostepne_dni() {
  [[ -r "$LAB_MODULY_CONF" ]] || return 0
  awk '
    /^[[:space:]]*#/ { next }
    NF == 0 { next }
    !widziane[$1]++ { print $1 }
  ' "$LAB_MODULY_CONF"
}

# lab__blad_brak_dnia — komunikat na stderr, gdy nie da się ustalić
# bieżącego dnia: podaje GOTOWE polecenie (`lab dzien <DZIEN>`) razem z listą
# dni dostępnych w moduly.conf, żeby stażysta nie zgadywał ani nie trafiał
# na nazwę polecenia z wcześniejszej (przed modułami) wersji labu.
lab__blad_brak_dnia() {
  printf 'Nie wiadomo, który dzień jest bieżący — najpierw uruchom: lab dzien <DZIEN> (albo podaj dzień wprost, np. F1/pliki).\n' >&2

  local -a dni=()
  while IFS= read -r d; do
    dni+=("$d")
  done < <(lab__dostepne_dni)

  if ((${#dni[@]} > 0)); then
    local lista="" d
    for d in "${dni[@]}"; do
      lista+="${lista:+, }${d}"
    done
    printf 'Dostępne dni: %s.\n' "$lista" >&2
  fi
}

# lab__ustal_dzien [<jawny-dzien>] — dzień podany wprost ma pierwszeństwo;
# bez niego sięga po ostatni zapisany przez `lab dzien` (albo automatycznie
# przez `lab start DZIEN/MODUŁ`) w LAB_BIEZACY_DZIEN_PLIK. Czytelny błąd na
# stderr (patrz lab__blad_brak_dnia) i kod 1, gdy nie da się ustalić żadnego
# (jeszcze nie było `lab dzien`, albo plik jest pusty).
lab__ustal_dzien() {
  local jawny="${1:-}"
  if [[ -n "$jawny" ]]; then
    printf '%s' "$jawny"
    return 0
  fi
  if [[ ! -f "$LAB_BIEZACY_DZIEN_PLIK" ]]; then
    lab__blad_brak_dnia
    return 1
  fi
  local tresc
  tresc="$(< "$LAB_BIEZACY_DZIEN_PLIK")"
  if [[ -z "$tresc" ]]; then
    lab__blad_brak_dnia
    return 1
  fi
  printf '%s' "$tresc"
}

# lab__waliduj_identyfikator <wartość> — dopuszcza tylko litery, cyfry, „_"
# i „-". DZIEN i nazwy modułów trafiają bezpośrednio do ścieżek plikowych,
# więc odrzucamy wszystko inne (np. „/", „..") zanim to się stanie.
lab__waliduj_identyfikator() {
  local wartosc="${1:-}"
  [[ "$wartosc" =~ ^[A-Za-z0-9_-]+$ ]]
}

# ------------------------------------------------------------------------------
# Moduły (patrz MODULY.md) — grupy zadań tematyczne, jeden dzień naraz.
# Mapowanie DZIEN -> MODUŁ -> ZADANIA leży w lib/moduly.conf, nie w kodzie —
# katalogów zadania/<DZIEN>/Z*/ to grupowanie w żaden sposób nie rusza.
# ------------------------------------------------------------------------------

# lab__linie_modulow_dnia <dzien> — surowe linie „MODUŁ ZAD1 ZAD2…" z
# moduly.conf dla jednego dnia, w kolejności pliku (czyli w kolejności
# wykonania). Pomija komentarze i puste linie.
lab__linie_modulow_dnia() {
  local dzien="${1:?}"
  [[ -r "$LAB_MODULY_CONF" ]] || return 1
  awk -v d="$dzien" '
    /^[[:space:]]*#/ { next }
    NF == 0 { next }
    $1 == d { $1 = ""; sub(/^ /, ""); print }
  ' "$LAB_MODULY_CONF"
}

# lab__moduly_dnia <dzien> — same nazwy modułów, jedna na linię, w kolejności
# wykonania.
lab__moduly_dnia() {
  lab__linie_modulow_dnia "${1:?}" | awk '{print $1}'
}

# lab__zadania_modulu <dzien> <modul> — lista zadań modułu (rozdzielona
# spacją) na stdout; zwraca 1, gdy taki moduł nie istnieje dla tego dnia.
lab__zadania_modulu() {
  local dzien="${1:?}" modul="${2:?}" linia
  while IFS= read -r linia; do
    if [[ "${linia%% *}" == "$modul" ]]; then
      printf '%s\n' "${linia#* }"
      return 0
    fi
  done < <(lab__linie_modulow_dnia "$dzien")
  return 1
}

# lab__modul_zadania <dzien> <zadanie> — odwrotność lab__zadania_modulu:
# nazwa modułu, do którego to zadanie należy danego dnia. Zwraca 1, gdy
# zadanie nie jest przypisane do żadnego modułu.
lab__modul_zadania() {
  local dzien="${1:?}" zadanie="${2:?}" linia modul reszta z
  while IFS= read -r linia; do
    modul="${linia%% *}"
    reszta="${linia#* }"
    for z in $reszta; do
      if [[ "$z" == "$zadanie" ]]; then
        printf '%s' "$modul"
        return 0
      fi
    done
  done < <(lab__linie_modulow_dnia "$dzien")
  return 1
}

# lab__modul_zaliczony <dzien> <modul> — stan modułu, zwrócony jako kod
# wyjścia:
#   0 — zaliczony: WSZYSTKIE istniejące na dysku zadania modułu mają
#       znacznik zaliczenia (trwały — patrz lab__sciezka_znacznika)
#   1 — niezaliczony: co najmniej jedno istniejące zadanie modułu jeszcze
#       nie ma znacznika
#   2 — moduł BEZ ani jednego istniejącego na dysku zadania, czyli bez ani
#       jednego automatycznego walidatora (np. F2/procesy, F2/zmienne —
#       same zadania, które świadomie nie zostawiają śladu w systemie).
#       Taki moduł nie da się ani zaliczyć, ani niezaliczyć automatycznie —
#       to trzeci, osobny stan, nie porażka. Wołający ma go obsłużyć osobno
#       (patrz KONTRAKT.md, sekcja „bin/lab — interfejs stażysty").
#
# Moduł, w którym TYLKO CZĘŚĆ zadań ma katalog (a więc walidator), liczy się
# po dotychczasowemu — wyłącznie po istniejących zadaniach; brakujące
# zadania nie blokują zaliczenia modułu i nie wpływają na wynik 0/1.
lab__modul_zaliczony() {
  local dzien="${1:?}" modul="${2:?}" zadania zad sciezka_zad istnieja=0
  zadania="$(lab__zadania_modulu "$dzien" "$modul")" || return 1
  for zad in $zadania; do
    sciezka_zad="${LAB_BAZA}/zadania/${dzien}/${zad}"
    [[ -d "$sciezka_zad" ]] || continue
    istnieja=1
    [[ -f "$(lab__sciezka_znacznika "$dzien" "$zad")" ]] || return 1
  done
  ((istnieja == 1)) && return 0
  return 2
}

# lab__sciezka_wyniku_modulu <dzien> <modul> — plik z wynikiem ostatniego
# `lab grade`: cztery linie — znacznik czasu; „ZAD_OK ZAD_WSZYSTKIE";
# „WAR_OK WAR_WSZYSTKIE"; „UDANE NIEUDANE" (dwa liczniki — patrz cmd_grade
# i lab__wczytaj_wynik_modulu niżej w sprawie starego formatu).
lab__sciezka_wyniku_modulu() {
  printf '%s/%s%s.wynik' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__wczytaj_wynik_modulu <dzien> <modul> — jeśli plik wyników istnieje,
# ustawia w zasięgu wołającego: WYNIK_CZAS, WYNIK_ZAD_OK, WYNIK_ZAD_ALL,
# WYNIK_WAR_OK, WYNIK_WAR_ALL, WYNIK_UDANE, WYNIK_NIEUDANE, WYNIK_PODEJSCIA
# (suma udane+nieudane — wygodna, gdy komuś wystarczy sama liczba),
# WYNIK_STARY_FORMAT (1/0). Zwraca 1, gdy pliku nie ma (moduł nigdy nie był
# oceniany przez `lab grade`).
#
# Zgodność wstecz: przed tą zmianą czwarta linia pliku była JEDNĄ liczbą
# („dotychczasowe podejścia", bez rozbicia na udane/nieudane). Nowy format
# ma tam DWIE liczby („UDANE NIEUDANE"). Rozpoznajemy po liczbie pól w
# czwartej linii — bez migracji plików na dysku, bez wywracania się na
# stanie stażysty sprzed tej zmiany. Stary licznik trafia w całości do
# NIEUDANE (0 udanych) — to najbliższe prawdy: ostatnie podejście i tak
# zwykle było udane, a jeden błąd w historycznych danych nikt nie zauważy.
lab__wczytaj_wynik_modulu() {
  local plik linia4
  plik="$(lab__sciezka_wyniku_modulu "$1" "$2")"
  [[ -f "$plik" ]] || return 1
  {
    read -r WYNIK_CZAS
    read -r WYNIK_ZAD_OK WYNIK_ZAD_ALL
    read -r WYNIK_WAR_OK WYNIK_WAR_ALL
    read -r linia4
  } < "$plik"

  if [[ "$linia4" == *' '* ]]; then
    WYNIK_STARY_FORMAT=0
    read -r WYNIK_UDANE WYNIK_NIEUDANE <<< "$linia4"
  else
    WYNIK_STARY_FORMAT=1
    WYNIK_UDANE=0
    WYNIK_NIEUDANE="$linia4"
  fi
  : "${WYNIK_UDANE:=0}"
  : "${WYNIK_NIEUDANE:=0}"
  WYNIK_PODEJSCIA=$((WYNIK_UDANE + WYNIK_NIEUDANE))
}

# lab__sciezka_rozpoczecia_modulu <dzien> <modul> — flaga „lab start tego
# modułu wywołano po raz pierwszy" (treść: znacznik czasu). Pisana raz —
# powtórne `lab start` tego samego modułu jej nie nadpisuje, bo ma mierzyć,
# ile moduł realnie zajął OD PIERWSZEGO podejścia.
lab__sciezka_rozpoczecia_modulu() {
  printf '%s/%s%s.rozpoczety' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__sciezka_pierwszego_zaliczenia_modulu <dzien> <modul> — flaga „moduł
# zaliczony (komplet zadań) po raz pierwszy" (treść: znacznik czasu). Też
# pisana tylko raz.
lab__sciezka_pierwszego_zaliczenia_modulu() {
  printf '%s/%s%s.pierwsze-zaliczenie' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__czas_trwania <znacznik1> <znacznik2> — czytelny odstęp między dwoma
# znacznikami czasu w formacie „%Y-%m-%d %H:%M:%S" (np. „2godz. 15min."),
# albo puste, gdy któregoś brakuje lub `date -d` nie potrafi go sparsować.
lab__czas_trwania() {
  local pierwszy="${1:-}" drugi="${2:-}"
  [[ -n "$pierwszy" && -n "$drugi" && "$pierwszy" != "—" && "$drugi" != "—" ]] || return 0
  local sek_p sek_d
  sek_p="$(date -d "$pierwszy" +%s 2> /dev/null || true)"
  sek_d="$(date -d "$drugi" +%s 2> /dev/null || true)"
  [[ -n "$sek_p" && -n "$sek_d" ]] || return 0
  local delta=$((sek_d - sek_p))
  ((delta < 0)) && delta=0
  printf '%dgodz. %dmin.' "$((delta / 3600))" "$(((delta % 3600) / 60))"
}

# lab__sciezka_zamkniecia_modulu <dzien> <modul> — flaga „moduł zamknięty
# przez lab koniec" (treść: znacznik czasu zamknięcia).
lab__sciezka_zamkniecia_modulu() {
  printf '%s/%s%s.zamkniety' "$LAB_STAN_DIR" "$1" "$2"
}

# lab__zapisz_log <polecenie> <wynik> — dopisuje jedną linię do dziennika.
# Format: ZNACZNIK_CZASU | UŻYTKOWNIK | POLECENIE | WYNIK
# Awaria zapisu (np. brak uprawnień) nie może wywalić całego `lab` —
# logowanie jest najlepszego wysiłku (best-effort).
lab__zapisz_log() {
  local polecenie="${1:-}" wynik="${2:-}" znacznik uzytkownik
  znacznik="$(date '+%Y-%m-%dT%H:%M:%S%z' 2> /dev/null || printf 'nieznany-czas')"
  uzytkownik="$(lab__biezacy_uzytkownik)"
  printf '%s | %s | %s | %s\n' "$znacznik" "$uzytkownik" "$polecenie" "$wynik" >> "$LAB_LOG" 2> /dev/null || true
}

# ------------------------------------------------------------------------------
# 6. Publiczne API walidatorów — DOKŁADNIE wg KONTRAKT.md, nie zmieniać nazw
#    ani sygnatur bez zgody. Wszystkie funkcje działają w bieżącym procesie
#    sprawdz.sh, więc liczniki poniżej startują od zera przy każdym uruchomieniu.
# ------------------------------------------------------------------------------

LAB__LICZBA_BLEDOW=0
LAB__LICZBA_OK=0
LAB__WSKAZOWKI=()
LAB__OPISY_BLEDOW=()

# --- komunikaty ---------------------------------------------------------------

# lab_ok "tekst" — ✓ zielony, komunikat sukcesu
lab_ok() {
  local tekst="${1:?lab_ok: brak treści komunikatu}"
  printf '  %s✓ %s%s\n' "${LAB_K_ZIELONY}" "$tekst" "${LAB_K_RESET}"
  LAB__LICZBA_OK=$((LAB__LICZBA_OK + 1))
}

# lab_blad "tekst" — ✗ czerwony, ustawia kod błędu. Treść zapamiętujemy też
# w LAB__OPISY_BLEDOW — lab_zakoncz ją zapisze, żeby `lab grade` mógł
# doliczyć, KTÓRY warunek nie przeszedł, do trwałego licznika modułu
# (patrz lab__doliczenie_bledow_modulu). Sama treść nie zmienia się przez
# to w żaden sposób — dalej obowiązuje zasada „co, nie jak naprawić".
lab_blad() {
  local tekst="${1:?lab_blad: brak treści komunikatu}"
  printf '  %s✗ %s%s\n' "${LAB_K_CZERWONY}" "$tekst" "${LAB_K_RESET}"
  LAB__LICZBA_BLEDOW=$((LAB__LICZBA_BLEDOW + 1))
  LAB__OPISY_BLEDOW+=("$tekst")
}

# lab_info "tekst" — ℹ szary, informacja neutralna
lab_info() {
  local tekst="${1:?lab_info: brak treści komunikatu}"
  printf '  %sℹ %s%s\n' "${LAB_K_SZARY}" "$tekst" "${LAB_K_RESET}"
}

# lab_dziennik_mentora "tekst" — zapisuje szczegół podłożonego stanu do
# dziennika mentora, NIE wypisując go na ekran.
#
# `przygotuj.sh` uruchamia stażysta poleceniem `lab start <moduł>`, więc
# wszystko, co trafi na stdout, zobaczy przed rozpoczęciem zadania. Ścieżki
# podłożonych plików, liczba i rodzaj wad, wartości tokenów — to treść
# zagadki, a nie informacja dla niego. Mentor odczyta ją stąd albo przez
# lab-raport.
#
# Plik ma prawa 640 root:root — stażysta nie przeczyta go bez sudo. To bariera
# świadomej decyzji, nie zabezpieczenie kryptograficzne; patrz „Jawność wobec
# stażysty" w KONTRAKT.md.
lab_dziennik_mentora() {
  local tekst="${1:?lab_dziennik_mentora: brak treści wpisu}"
  local plik="${LAB_LOG_DIR}/mentor.log"

  # Bez uprawnień do zapisu po prostu odpuszczamy — brak wpisu w dzienniku
  # mentora nie może wywrócić przygotowania zadania stażyście.
  [[ -w "$LAB_LOG_DIR" || -w "$plik" ]] || return 0

  if [[ ! -f "$plik" ]]; then
    : > "$plik" 2> /dev/null || return 0
    chmod 640 "$plik" 2> /dev/null || true
    chown root:root "$plik" 2> /dev/null || true
  fi

  printf '%s  %s  %s\n' "$(date -Is)" "${LAB_DZIEN_ZADANIE:-?}" "$tekst" >> "$plik" 2> /dev/null || true
}

# lab_wskazowka "tekst" — → żółty, pokazywany TYLKO gdy zadanie niezaliczone.
# Zbieramy do bufora i wypisujemy dopiero w lab_zakoncz, gdy już wiadomo,
# czy było choć jedno niespełnione ostrzeżenie — niezależnie od tego, w którym
# miejscu sprawdz.sh wywołano lab_wskazowka.
lab_wskazowka() {
  local tekst="${1:?lab_wskazowka: brak treści komunikatu}"
  LAB__WSKAZOWKI+=("$tekst")
}

# --- asercje na plikach i katalogach -------------------------------------------

# lab_jest_plik <ścieżka> "opis" — zwykły plik istnieje
lab_jest_plik() {
  local sciezka="${1:?lab_jest_plik: brak ścieżki}"
  local opis="${2:?lab_jest_plik: brak opisu}"
  if [[ -f "$sciezka" ]]; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_jest_katalog <ścieżka> "opis" — katalog istnieje
lab_jest_katalog() {
  local sciezka="${1:?lab_jest_katalog: brak ścieżki}"
  local opis="${2:?lab_jest_katalog: brak opisu}"
  if [[ -d "$sciezka" ]]; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_nie_ma <ścieżka> "opis" — ścieżka NIE istnieje (liczy się też
# dowiązanie symboliczne wskazujące donikąd — takie -e nie wykryje).
lab_nie_ma() {
  local sciezka="${1:?lab_nie_ma: brak ścieżki}"
  local opis="${2:?lab_nie_ma: brak opisu}"
  if [[ -e "$sciezka" || -L "$sciezka" ]]; then
    lab_blad "$opis"
  else
    lab_ok "$opis"
  fi
}

# lab_plik_zawiera <plik> <wzorzec-ere> "opis"
lab_plik_zawiera() {
  local plik="${1:?lab_plik_zawiera: brak ścieżki pliku}"
  local wzorzec="${2:?lab_plik_zawiera: brak wzorca}"
  local opis="${3:?lab_plik_zawiera: brak opisu}"
  # -i celowo: wzorce szukają najczęściej słów w notatkach pisanych ręcznie,
  # a stażysta równie dobrze zacznie zdanie wielką literą („Spacja w nazwie…").
  # Walidator ma sprawdzać, czy zrozumiał, a nie czy trafił w wielkość liter.
  if [[ -f "$plik" ]] && grep -Eiq -- "$wzorzec" "$plik" 2> /dev/null; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_plik_nie_zawiera <plik> <wzorzec-ere> "opis"
# Uwaga: nieistniejący plik trywialnie „nie zawiera" wzorca — to przechodzi.
# Jeśli walidator ma sprawdzić i istnienie, i brak treści, dodaj osobno
# lab_jest_plik.
lab_plik_nie_zawiera() {
  local plik="${1:?lab_plik_nie_zawiera: brak ścieżki pliku}"
  local wzorzec="${2:?lab_plik_nie_zawiera: brak wzorca}"
  local opis="${3:?lab_plik_nie_zawiera: brak opisu}"
  # -i spójnie z lab_plik_zawiera — inaczej ta sama treść zapisana wielką
  # literą raz by przechodziła, a raz nie, zależnie od użytej funkcji.
  if [[ -f "$plik" ]] && grep -Eiq -- "$wzorzec" "$plik" 2> /dev/null; then
    lab_blad "$opis"
  else
    lab_ok "$opis"
  fi
}

# --- asercje na poleceniach i procesach ----------------------------------------

# lab_polecenie_dziala <polecenie> "opis" — kod wyjścia 0
lab_polecenie_dziala() {
  local polecenie="${1:?lab_polecenie_dziala: brak polecenia}"
  local opis="${2:?lab_polecenie_dziala: brak opisu}"
  if bash -c "$polecenie" > /dev/null 2>&1; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_wynik_zawiera <polecenie> <wzorzec-ere> "opis"
lab_wynik_zawiera() {
  local polecenie="${1:?lab_wynik_zawiera: brak polecenia}"
  local wzorzec="${2:?lab_wynik_zawiera: brak wzorca}"
  local opis="${3:?lab_wynik_zawiera: brak opisu}"
  local wynik
  wynik="$(bash -c "$polecenie" 2>&1 || true)"
  if grep -Eq -- "$wzorzec" <<< "$wynik"; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_port_nasluchuje <port> <adres> "opis" — adres: 0.0.0.0 | 127.0.0.1 | dowolny
lab_port_nasluchuje() {
  local port="${1:?lab_port_nasluchuje: brak numeru portu}"
  local adres="${2:?lab_port_nasluchuje: brak adresu}"
  local opis="${3:?lab_port_nasluchuje: brak opisu}"

  if ! command -v ss > /dev/null 2>&1; then
    lab_blad "$opis"
    return
  fi

  local pasuje=0 linia lokalny adres_lok port_lok
  while IFS= read -r linia; do
    [[ -z "$linia" ]] && continue
    lokalny="$(awk '{print $4}' <<< "$linia")"
    [[ -z "$lokalny" ]] && continue
    port_lok="${lokalny##*:}"
    adres_lok="${lokalny%:*}"
    [[ "$port_lok" == "$port" ]] || continue
    case "$adres" in
      dowolny)
        pasuje=1
        ;;
      0.0.0.0)
        [[ "$adres_lok" == "0.0.0.0" || "$adres_lok" == "*" || "$adres_lok" == "[::]" ]] && pasuje=1
        ;;
      127.0.0.1)
        [[ "$adres_lok" == "127.0.0.1" || "$adres_lok" == "[::1]" ]] && pasuje=1
        ;;
      *)
        [[ "$adres_lok" == "$adres" ]] && pasuje=1
        ;;
    esac
    ((pasuje == 1)) && break
  done < <(ss -tlnH 2> /dev/null || true)

  if ((pasuje == 1)); then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_prawa <ścieżka> <tryb> "opis" — np. 755; porównuje stat -c %a
lab_prawa() {
  local sciezka="${1:?lab_prawa: brak ścieżki}"
  local tryb="${2:?lab_prawa: brak trybu}"
  local opis="${3:?lab_prawa: brak opisu}"
  local aktualny
  if [[ -e "$sciezka" ]] && aktualny="$(stat -c '%a' -- "$sciezka" 2> /dev/null)" && [[ "$aktualny" == "$tryb" ]]; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# lab_proces_dziala <wzorzec> "opis"
lab_proces_dziala() {
  local wzorzec="${1:?lab_proces_dziala: brak wzorca}"
  local opis="${2:?lab_proces_dziala: brak opisu}"
  if command -v pgrep > /dev/null 2>&1 && pgrep -f -- "$wzorzec" > /dev/null 2>&1; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# --- tokeny ---------------------------------------------------------------------

# lab_token_w_notatkach <token> "opis" — szuka w ~/staz/notatki/,
# rekurencyjnie, w dowolnym pliku.
lab_token_w_notatkach() {
  local token="${1:?lab_token_w_notatkach: brak tokenu}"
  local opis="${2:?lab_token_w_notatkach: brak opisu}"
  local katalog="${LAB_DOM}/staz/notatki"
  if [[ -d "$katalog" ]] && grep -Fqr -- "$token" "$katalog" 2> /dev/null; then
    lab_ok "$opis"
  else
    lab_blad "$opis"
  fi
}

# --- zakończenie walidatora ------------------------------------------------------

# lab_zakoncz — kończy z kodem 0 (zaliczone) lub 1 (niezaliczone).
# Nazwę zadania (i dnia) ustala z własnej ścieżki sprawdz.sh
# (zadania/<DZIEN>/<ZADANIE>/sprawdz.sh) — działa niezależnie od tego, czy
# skrypt wywołano ścieżką bezwzględną, względną, czy przez ./sprawdz.sh.
#
# Przy okazji zapisuje do LAB_STAN_DIR liczbę spełnionych/wszystkich
# warunków (patrz lab__sciezka_warunkow) i — gdy coś nie przeszło — treść
# każdego niespełnionego warunku (patrz lab__sciezka_opisow_bledow) —
# `lab grade` czyta oba, żeby zbudować wynik liczbowy modułu i doliczyć
# najczęściej padające warunki, bez parsowania kolorowanego stdout. To
# działanie poboczne, niewidoczne dla zwykłego `lab sprawdz` i nieopisane w
# kontrakcie jako osobna funkcja — nie zmienia zachowania ani sygnatury
# lab_zakoncz.
lab_zakoncz() {
  local zrodlo katalog_zadania zadanie dzien=""
  zrodlo="${BASH_SOURCE[1]:-$0}"
  katalog_zadania="$(cd -- "$(dirname -- "$zrodlo")" 2> /dev/null && pwd -P)" || katalog_zadania=""
  if [[ -n "$katalog_zadania" ]]; then
    zadanie="$(basename -- "$katalog_zadania")"
    dzien="$(basename -- "$(dirname -- "$katalog_zadania")")"
  else
    zadanie="ZADANIE"
  fi

  if [[ -n "$dzien" ]]; then
    printf '%d %d\n' "$LAB__LICZBA_OK" "$((LAB__LICZBA_OK + LAB__LICZBA_BLEDOW))" \
      > "$(lab__sciezka_warunkow "$dzien" "$zadanie")" 2> /dev/null || true
    if ((${#LAB__OPISY_BLEDOW[@]} > 0)); then
      printf '%s\n' "${LAB__OPISY_BLEDOW[@]}" \
        > "$(lab__sciezka_opisow_bledow "$dzien" "$zadanie")" 2> /dev/null || true
    else
      rm -f "$(lab__sciezka_opisow_bledow "$dzien" "$zadanie")" 2> /dev/null || true
    fi
  fi

  printf '\n'

  if ((LAB__LICZBA_BLEDOW == 0)); then
    printf '%s%sZALICZONE: %s%s\n\n' "${LAB_K_POGRUBIONY}" "${LAB_K_ZIELONY}" "$zadanie" "${LAB_K_RESET}"
    exit 0
  fi

  if ((${#LAB__WSKAZOWKI[@]} > 0)); then
    local w
    for w in "${LAB__WSKAZOWKI[@]}"; do
      printf '  %s→ %s%s\n' "${LAB_K_ZOLTY}" "$w" "${LAB_K_RESET}"
    done
    printf '\n'
  fi

  printf '%s%sNIEZALICZONE: %s (%d niespełnionych warunków)%s\n\n' \
    "${LAB_K_POGRUBIONY}" "${LAB_K_CZERWONY}" "$zadanie" "$LAB__LICZBA_BLEDOW" "${LAB_K_RESET}"
  exit 1
}
