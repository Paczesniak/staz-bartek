#!/bin/bash
set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly APKA="${LAB_DOM}/staz/aplikacja"
readonly NAKLADKA="${APKA}/compose.override.yaml"
readonly ZAPASOWA="${APKA}/.compose.override.yaml.sprzed-labu"
readonly STAN_PRZED="${LAB_STAN_DIR}/baza-Z11-linki-przed"

if [[ -f "$STAN_PRZED" ]]; then
  printf 'Z11 już przygotowane wcześniej — nie dotykam istniejącego stanu.\n'
  exit 0
fi

if [[ ! -f "${APKA}/compose.yaml" ]]; then
  lab_dziennik_mentora "Z11: nie mogę przygotować — brak ${APKA}/compose.yaml."
  printf 'Nie mam jeszcze czego zepsuć: w ~/staz/aplikacja nie ma pliku compose.yaml.\n'
  exit 0
fi

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"

if [[ -z "$ADRES_BAZY" ]]; then
  lab_dziennik_mentora "Z11: nie mogę przygotować — DATABASE_URL usługi api nie wskazuje Postgresa (moduł sterownik jeszcze niezaliczony?)."
  printf 'Nie zaczynam tego zadania: twoja aplikacja nie jest jeszcze przełączona na Postgresa.\n'
  printf 'Zrób najpierw moduły postgres i sterownik, a potem wróć: lab start awaria\n'
  exit 0
fi

SCHEMAT="${ADRES_BAZY%%://*}"
BEZ_SCHEMATU="${ADRES_BAZY#*://}"
POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
PO_MALPIE="${BEZ_SCHEMATU#*@}"
PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
HOSTPORT="${PO_MALPIE%%/*}"
PG_PORT="5432"
[[ "$HOSTPORT" == *:* ]] && PG_PORT="${HOSTPORT##*:}"
PG_BAZA="${PO_MALPIE#*/}"
PG_BAZA="${PG_BAZA%%\?*}"

ADRES_ZEPSUTY="${SCHEMAT}://${PG_UZYTKOWNIK}:nieaktualne-haslo@localhost:${PG_PORT}/${PG_BAZA}"

DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

PRZED=0
if [[ -n "$DB_KONTENER" ]]; then
  ODCZYT="$(docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" \
    -tAc "SELECT count(*) FROM links;" 2> /dev/null | tr -d '\r' | head -n1 || true)"
  [[ "$ODCZYT" =~ ^[0-9]+$ ]] && PRZED="$ODCZYT"
fi

printf '%s\n' "$PRZED" > "$STAN_PRZED"
chmod 644 -- "$STAN_PRZED"

if [[ -f "$NAKLADKA" && ! -f "$ZAPASOWA" ]]; then
  mv -- "$NAKLADKA" "$ZAPASOWA"
  lab_dziennik_mentora "Z11: zastałem starą nakładkę compose.override.yaml — odłożyłem ją na ${ZAPASOWA}."
fi

cat > "$NAKLADKA" << YAML
services:
  api:
    environment:
      DATABASE_URL: "${ADRES_ZEPSUTY}"
YAML

chown -- "${LAB_UZYTKOWNIK}:${LAB_GRUPA}" "$NAKLADKA"
chmod 644 -- "$NAKLADKA"

if ! docker compose --project-directory "$APKA" up -d > /dev/null 2>&1; then
  lab_dziennik_mentora "Z11: 'docker compose up -d' po podłożeniu nakładki zwróciło błąd — to bywa normalne, gdy api nie wstaje, ale sprawdź stan stosu, jeśli coś się nie zgadza."
fi

lab_dziennik_mentora "Z11: podłożono ${NAKLADKA} z DATABASE_URL=${ADRES_ZEPSUTY} — dwie wady naraz: host localhost (kontener api sam ze sobą, 'connection refused') oraz nieprawidłowe hasło (ujawnia się dopiero po naprawie hosta jako 'password authentication failed'). W bazie przed awarią było ${PRZED} linków. Dane, wolumen i migracje nietknięte."

printf 'Przygotowano Z11. Twój stos stoi w ~/staz/aplikacja — zobacz, w jakim stanie.\n'
