#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"
NAKLADKA="${APKA}/compose.override.yaml"
STAN_PRZED="${LAB_STAN_DIR}/baza-Z11-linki-przed"

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"

if [[ -f "$NAKLADKA" ]] && grep -q 'nieaktualne-haslo' "$NAKLADKA" 2> /dev/null; then
  lab_blad "nakładka compose.override.yaml z podłożonymi wadami już nie obowiązuje pod tą nazwą"
else
  lab_ok "nakładka z podłożonymi wadami już nie obowiązuje"
fi

if [[ -n "$ADRES_BAZY" ]]; then
  BEZ_SCHEMATU="${ADRES_BAZY#*://}"
  POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
  PO_MALPIE="${BEZ_SCHEMATU#*@}"
  PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
  HOSTPORT="${PO_MALPIE%%/*}"
  HOST_BAZY="${HOSTPORT%%:*}"
  PG_BAZA="${PO_MALPIE#*/}"
  PG_BAZA="${PG_BAZA%%\?*}"

  case "$HOST_BAZY" in
    localhost | 127.0.0.1 | ::1)
      lab_blad "host bazy w złożonej konfiguracji to nazwa usługi bazy (jest: ${HOST_BAZY})"
      ;;
    *)
      lab_ok "host bazy w złożonej konfiguracji (${HOST_BAZY}) znów wskazuje bazę, a nie sam kontener api"
      ;;
  esac
else
  lab_blad "DATABASE_URL usługi api wskazuje bazę PostgreSQL"
  lab_zakoncz
fi

ZDROWIE="$(curl -s --max-time 3 http://127.0.0.1:8000/health 2> /dev/null || true)"
if grep -q '"database"[[:space:]]*:[[:space:]]*"ok"' <<< "$ZDROWIE"; then
  lab_ok "/health odpowiada database: ok — aplikacja znów rozmawia z bazą"
else
  lab_blad "/health odpowiada database: ok (dostałem: ${ZDROWIE:-brak odpowiedzi})"
fi

DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

PRZED="$(cat "$STAN_PRZED" 2> /dev/null || printf '0')"
[[ "$PRZED" =~ ^[0-9]+$ ]] || PRZED=0

if [[ -n "$DB_KONTENER" ]]; then
  TERAZ="$(docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" \
    -tAc "SELECT count(*) FROM links;" 2> /dev/null | tr -d '\r' | head -n1 || true)"
  [[ "$TERAZ" =~ ^[0-9]+$ ]] || TERAZ=0

  if ((PRZED > 0)); then
    if ((TERAZ >= PRZED)); then
      lab_ok "dane przetrwały awarię w komplecie (${TERAZ} z ${PRZED} sprzed awarii)"
    else
      lab_blad "dane przetrwały awarię w komplecie (jest ${TERAZ} z ${PRZED} sprzed awarii — naprawa nie mogła polegać na postawieniu bazy od zera)"
    fi
  elif ((TERAZ > 0)); then
    lab_ok "w bazie są dane (${TERAZ})"
  else
    lab_blad "w bazie są dane (tabela links jest pusta)"
  fi
else
  lab_blad "kontener usługi db działa"
fi

lab_wskazowka "Awarię, w której jeden błąd zasłania drugi, rozpoznaje się po tym, że komunikat ZMIENIA się po naprawie — to znak, że pierwsza warstwa ustąpiła i widać kolejną."
lab_zakoncz
