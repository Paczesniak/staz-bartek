#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="${LAB_DOM}/staz/aplikacja"
NAKLADKA="${APKA}/compose.override.yaml"
ZAPASOWA="${APKA}/.compose.override.yaml.sprzed-labu"

if [[ -f "$NAKLADKA" ]] && grep -q 'nieaktualne-haslo' "$NAKLADKA" 2> /dev/null; then
  rm -f -- "$NAKLADKA"
fi

if [[ -f "$ZAPASOWA" && ! -f "$NAKLADKA" ]]; then
  mv -- "$ZAPASOWA" "$NAKLADKA"
  chown -- "${LAB_UZYTKOWNIK}:${LAB_GRUPA}" "$NAKLADKA" 2> /dev/null || true
fi

rm -f -- "${LAB_STAN_DIR}/baza-Z11-linki-przed"

docker compose --project-directory "$APKA" up -d > /dev/null 2>&1 || true
exit 0
