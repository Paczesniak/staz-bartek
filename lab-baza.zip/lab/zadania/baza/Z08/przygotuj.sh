#!/bin/bash
set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly STAN_STARE="${LAB_STAN_DIR}/baza-Z08-stare-linki"

if [[ -f "$STAN_STARE" ]]; then
  printf 'Z08 już przygotowane wcześniej — nie liczę starej bazy drugi raz.\n'
  exit 0
fi

if ! command -v python3 > /dev/null 2>&1; then
  lab_dziennik_mentora "Z08: brak python3 na maszynie — nie policzyłem starej bazy SQLite."
  printf 'Nie mogę odczytać wczorajszej bazy (brak python3) — zgłoś to mentorowi.\n'
  exit 0
fi

lab__policz_linki() {
  python3 - "$1" << 'PYTHON' 2> /dev/null || true
import sqlite3
import sys

try:
    polaczenie = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True)
    (liczba,) = polaczenie.execute("SELECT count(*) FROM links").fetchone()
    print(liczba)
except Exception:
    pass
PYTHON
}

NAJWIEKSZA=""
ZRODLO=""

while IFS= read -r wolumen; do
  [[ -n "$wolumen" ]] || continue
  MOUNTPOINT="$(docker volume inspect --format '{{.Mountpoint}}' -- "$wolumen" 2> /dev/null || true)"
  [[ -n "$MOUNTPOINT" && -d "$MOUNTPOINT" ]] || continue

  while IFS= read -r plik; do
    LICZBA="$(lab__policz_linki "$plik")"
    [[ "$LICZBA" =~ ^[0-9]+$ ]] || continue
    if [[ -z "$NAJWIEKSZA" ]] || ((LICZBA > NAJWIEKSZA)); then
      NAJWIEKSZA="$LICZBA"
      ZRODLO="$plik"
    fi
  done < <(find "$MOUNTPOINT" -maxdepth 3 -type f -name '*.db' 2> /dev/null)
done < <(docker volume ls -q 2> /dev/null || true)

if [[ -z "$NAJWIEKSZA" ]]; then
  printf '0\n' > "$STAN_STARE"
  lab_dziennik_mentora "Z08: nie znalazłem wczorajszej bazy SQLite w żadnym wolumenie — walidator sprawdzi tylko, czy w Postgresie w ogóle są dane."
else
  printf '%s\n' "$NAJWIEKSZA" > "$STAN_STARE"
  lab_dziennik_mentora "Z08: stara baza ${ZRODLO} zawiera ${NAJWIEKSZA} linków — tyle ma być w Postgresie po przeprowadzce."
fi

chmod 644 -- "$STAN_STARE"
printf 'Przygotowano Z08. Wczorajsza baza została zmierzona — nic w niej nie zmieniałem.\n'
