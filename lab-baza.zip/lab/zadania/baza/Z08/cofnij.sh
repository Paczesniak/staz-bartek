#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh
rm -f -- "${LAB_STAN_DIR}/baza-Z08-stare-linki"
exit 0
