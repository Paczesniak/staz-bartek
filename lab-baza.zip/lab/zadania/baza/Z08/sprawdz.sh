#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"
STAN_STARE="${LAB_STAN_DIR}/baza-Z08-stare-linki"

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"
DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -z "$ADRES_BAZY" || -z "$DB_KONTENER" ]]; then
  lab_blad "działający kontener db i DATABASE_URL wskazujący Postgresa (bez tego nie zajrzę do bazy)"
  lab_zakoncz
fi

BEZ_SCHEMATU="${ADRES_BAZY#*://}"
POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
PO_MALPIE="${BEZ_SCHEMATU#*@}"
PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
PG_BAZA="${PO_MALPIE#*/}"
PG_BAZA="${PG_BAZA%%\?*}"

baza__pytanie() {
  docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" -tAc "$1" 2> /dev/null \
    | tr -d '\r' | head -n1 || true
}

STARE="$(cat "$STAN_STARE" 2> /dev/null || printf '0')"
[[ "$STARE" =~ ^[0-9]+$ ]] || STARE=0

W_POSTGRESIE="$(baza__pytanie "SELECT count(*) FROM links;")"
[[ "$W_POSTGRESIE" =~ ^[0-9]+$ ]] || W_POSTGRESIE=0

if ((STARE > 0)); then
  if ((W_POSTGRESIE >= STARE)); then
    lab_ok "w Postgresie jest co najmniej tyle linków, ile było we wczorajszej bazie (${W_POSTGRESIE} z ${STARE})"
  else
    lab_blad "w Postgresie jest co najmniej tyle linków, ile było we wczorajszej bazie (jest ${W_POSTGRESIE} z ${STARE})"
  fi
else
  if ((W_POSTGRESIE > 0)); then
    lab_ok "w Postgresie są dane (${W_POSTGRESIE} linków)"
  else
    lab_blad "w Postgresie są dane (tabela links jest pusta)"
  fi
  lab_wskazowka "Nie znalazłem wczorajszej bazy SQLite w wolumenach, więc porównuję tylko z zerem — omówimy to na obronie."
fi

LINKI_JSON="$(curl -s --max-time 3 http://127.0.0.1:8000/api/links 2> /dev/null || true)"
if [[ -n "$LINKI_JSON" ]]; then
  Z_API="$(grep -o '"code"' <<< "$LINKI_JSON" | wc -l | tr -d ' ')"
  if [[ "$Z_API" == "$W_POSTGRESIE" ]]; then
    lab_ok "API pokazuje tyle samo linków, co baza (${Z_API}) — aplikacja czyta z tej samej bazy"
  else
    lab_blad "API pokazuje tyle samo linków, co baza (API: ${Z_API}, baza: ${W_POSTGRESIE})"
  fi
else
  lab_blad "/api/links odpowiada (bez tego nie porównam API z bazą)"
fi

SEKWENCJA="$(baza__pytanie "SELECT pg_get_serial_sequence('public.links','id');")"
if [[ -n "$SEKWENCJA" ]]; then
  OSTATNIA="$(baza__pytanie "SELECT last_value FROM ${SEKWENCJA};")"
  NAJWIEKSZE_ID="$(baza__pytanie "SELECT COALESCE(MAX(id), 0) FROM links;")"
  if [[ "$OSTATNIA" =~ ^[0-9]+$ && "$NAJWIEKSZE_ID" =~ ^[0-9]+$ ]] && ((OSTATNIA >= NAJWIEKSZE_ID)); then
    lab_ok "licznik id nadąża za danymi (${OSTATNIA} ≥ ${NAJWIEKSZE_ID}) — kolejny link się zapisze"
  else
    lab_blad "licznik id nadąża za danymi (licznik: ${OSTATNIA:-?}, największe id: ${NAJWIEKSZE_ID:-?} — kolejny link skończy się błędem o duplikacie)"
  fi
else
  lab_blad "kolumna id ma sekwencję (bez niej nie sprawdzę, czy licznik nadąża za danymi)"
fi

lab_jest_katalog "$LAB_DOM/staz/narzedzia" "katalog narzedzia/ istnieje w repozytorium"

if compgen -G "$LAB_DOM/staz/narzedzia/*" > /dev/null 2>&1; then
  lab_ok "w katalogu narzedzia/ leży to, czym przenosiłeś dane"
else
  lab_blad "w katalogu narzedzia/ leży to, czym przenosiłeś dane (katalog jest pusty)"
fi

lab_wskazowka "Jeśli licznik id nie nadąża: SELECT setval(pg_get_serial_sequence('public.links','id'), (SELECT MAX(id) FROM links)); — ale najpierw zrozum, dlaczego to działa."
lab_zakoncz
