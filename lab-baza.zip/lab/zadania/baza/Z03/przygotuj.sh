#!/bin/bash
set -Eeuo pipefail
printf 'Z03 nie wymaga przygotowania — healthcheck i depends_on dopisujesz sam.\n'
