#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"

if [[ -z "$KONFIG" ]]; then
  lab_blad "docker compose config składa się bez błędu (bez tego nie sprawdzę healthchecka)"
  lab_zakoncz
fi

BLOK_DB="$(awk '
  /^  db:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

if grep -Eq '^ {4}healthcheck:' <<< "$BLOK_DB"; then
  lab_ok "usługa db ma zdefiniowany healthcheck"
else
  lab_blad "usługa db ma zdefiniowany healthcheck"
fi

DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -n "$DB_KONTENER" ]]; then
  STAN_ZDROWIA="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{end}}' \
    "$DB_KONTENER" 2> /dev/null || true)"
  case "$STAN_ZDROWIA" in
    healthy)
      lab_ok "kontener bazy jest w stanie healthy — healthcheck naprawdę przechodzi"
      ;;
    starting)
      lab_blad "kontener bazy jest healthy (jest: starting — poczekaj kilkanaście sekund i sprawdź ponownie)"
      ;;
    "")
      lab_blad "kontener bazy jest healthy (ten kontener w ogóle nie ma healthchecka — podnieś stos od nowa po zmianie w compose.yaml)"
      ;;
    *)
      lab_blad "kontener bazy jest healthy (jest: ${STAN_ZDROWIA})"
      ;;
  esac
else
  lab_blad "kontener usługi db działa (bez niego nie sprawdzę stanu healthy)"
fi

ZALEZNOSC_DB="$(awk '
  /^ {4}depends_on:/ { w=1; next }
  w && /^ {4}[a-zA-Z]/ { exit }
  w { print }
' <<< "$BLOK_API")"

if grep -q 'db:' <<< "$ZALEZNOSC_DB"; then
  lab_ok "usługa api ma zależność depends_on od db"
  if grep -Eq 'condition: *service_healthy' <<< "$ZALEZNOSC_DB"; then
    lab_ok "zależność api → db ma warunek service_healthy (api czeka na gotową bazę)"
  else
    lab_blad "zależność api → db ma warunek service_healthy (jest zależność, ale bez warunku)"
  fi
else
  lab_blad "usługa api ma zależność depends_on od db"
fi

lab_wskazowka "docker compose ps pokazuje '(healthy)' dopiero po przejściu healthchecka. Zanim to nastąpi, przez czas z start_period widnieje 'starting' — i to nie jest błąd."
lab_zakoncz
