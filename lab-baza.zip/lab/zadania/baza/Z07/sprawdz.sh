#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"
DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -z "$ADRES_BAZY" || -z "$DB_KONTENER" ]]; then
  lab_blad "działający kontener db i DATABASE_URL wskazujący Postgresa (bez tego nie zajrzę do bazy)"
  lab_zakoncz
fi

BEZ_SCHEMATU="${ADRES_BAZY#*://}"
POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
PO_MALPIE="${BEZ_SCHEMATU#*@}"
PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
PG_BAZA="${PO_MALPIE#*/}"
PG_BAZA="${PG_BAZA%%\?*}"

baza__pytanie() {
  docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" -tAc "$1" 2> /dev/null \
    | tr -d '\r' || true
}

KOLUMNY="$(baza__pytanie "SELECT column_name FROM information_schema.columns WHERE table_name = 'links' ORDER BY column_name;")"

BRAKI=()
for kolumna in clicks code created_at id url; do
  grep -qx -- "$kolumna" <<< "$KOLUMNY" || BRAKI+=("$kolumna")
done

if ((${#BRAKI[@]} == 0)); then
  lab_ok "tabela links ma komplet kolumn z app/models.py (id, code, url, clicks, created_at)"
else
  lab_blad "tabela links ma komplet kolumn z app/models.py (brakuje: ${BRAKI[*]})"
fi

UNIKALNY_CODE="$(baza__pytanie "SELECT count(*) FROM pg_index i JOIN pg_class c ON c.oid = i.indrelid JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum = ANY(i.indkey) WHERE c.relname = 'links' AND a.attname = 'code' AND i.indisunique;" | head -n1)"

if [[ "${UNIKALNY_CODE:-0}" -gt 0 ]] 2> /dev/null; then
  lab_ok "kolumna code ma ograniczenie unikalności — migracja odtworzyła pełną strukturę"
else
  lab_blad "kolumna code ma ograniczenie unikalności — migracja odtworzyła pełną strukturę"
fi

lab_wskazowka "To ograniczenie zobaczysz w działaniu w następnym module: przy powtórnym przeniesieniu tych samych danych baza odmówi zapisu i będzie miała rację."
lab_zakoncz
