#!/bin/bash
set -Eeuo pipefail
printf 'Z07 nie wymaga przygotowania — porównujesz struktury dwóch baz.\n'
