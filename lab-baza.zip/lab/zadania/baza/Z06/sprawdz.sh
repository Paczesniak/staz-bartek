#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"
DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -z "$ADRES_BAZY" || -z "$DB_KONTENER" ]]; then
  lab_blad "działający kontener db i DATABASE_URL wskazujący Postgresa (bez tego nie zajrzę do bazy)"
  lab_wskazowka "Ten moduł zakłada zamknięty moduł sterownik — stos ma stać i gadać z Postgresem."
  lab_zakoncz
fi

BEZ_SCHEMATU="${ADRES_BAZY#*://}"
POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
PO_MALPIE="${BEZ_SCHEMATU#*@}"
PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
PG_BAZA="${PO_MALPIE#*/}"
PG_BAZA="${PG_BAZA%%\?*}"

baza__pytanie() {
  docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" -tAc "$1" 2> /dev/null \
    | tr -d '\r' | head -n1 || true
}

CZY_LINKS="$(baza__pytanie "SELECT to_regclass('public.links') IS NOT NULL;")"
if [[ "$CZY_LINKS" == "t" ]]; then
  lab_ok "tabela links istnieje w bazie PostgreSQL"
else
  lab_blad "tabela links istnieje w bazie PostgreSQL"
fi

CZY_WERSJE="$(baza__pytanie "SELECT to_regclass('public.alembic_version') IS NOT NULL;")"
if [[ "$CZY_WERSJE" == "t" ]]; then
  lab_ok "tabela alembic_version istnieje — strukturę utworzyła migracja, nie ręczny SQL"
else
  lab_blad "tabela alembic_version istnieje — strukturę utworzyła migracja, nie ręczny SQL"
fi

WERSJA="$(baza__pytanie "SELECT version_num FROM alembic_version;")"
if [[ -n "$WERSJA" ]]; then
  lab_ok "alembic_version wskazuje konkretną wersję migracji (${WERSJA})"
else
  lab_blad "alembic_version wskazuje konkretną wersję migracji (tabela jest pusta)"
fi

lab_wskazowka "'docker compose exec api alembic current' pyta Alembica o to samo, tylko jego językiem — porównaj oba wyniki."
lab_zakoncz
