#!/bin/bash
set -Eeuo pipefail
printf 'Z06 nie wymaga przygotowania — zaglądasz do bazy, która już stoi.\n'
