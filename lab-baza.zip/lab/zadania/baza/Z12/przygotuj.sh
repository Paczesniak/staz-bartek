#!/bin/bash
set -Eeuo pipefail
printf 'Z12 nie wymaga przygotowania — porządkujesz notatki i commitujesz to, co masz.\n'
