#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

REPO="${LAB_DOM}/staz"
NOTATKI="${REPO}/notatki/baza.md"
PLIK_ENV="${REPO}/aplikacja/.env"

if [[ -f "$NOTATKI" ]] && grep -Eq '.{20,}' "$NOTATKI" 2> /dev/null; then
  lab_ok "notatki/baza.md istnieją i mają treść"
else
  lab_blad "notatki/baza.md istnieją i mają treść"
fi

lab_jest_katalog "$REPO/.git" "katalog ~/staz jest repozytorium git"

if [[ -f "$PLIK_ENV" ]]; then
  if git -C "$REPO" check-ignore -q aplikacja/.env 2> /dev/null; then
    lab_ok "plik aplikacja/.env z hasłem jest ignorowany przez git"
  else
    lab_blad "plik aplikacja/.env z hasłem jest ignorowany przez git (dopisz '.env' do .gitignore)"
  fi

  HASLO="$(grep -E '^[[:space:]]*POSTGRES_PASSWORD=' "$PLIK_ENV" 2> /dev/null \
    | head -n1 | cut -d= -f2- | tr -d '"'"'"'[:space:]' || true)"

  if [[ -n "$HASLO" ]]; then
    if git -C "$REPO" grep -qF -- "$HASLO" HEAD 2> /dev/null; then
      lab_blad "hasło do bazy NIE występuje w żadnym ze śledzonych plików (znalazłem je — zatrzymaj się i napisz do mentora PRZED kolejnym commitem)"
    else
      lab_ok "hasło do bazy nie występuje w żadnym ze śledzonych plików"
    fi
  else
    lab_blad "w aplikacja/.env stoi POSTGRES_PASSWORD z wartością hasła"
  fi
else
  lab_blad "plik aplikacja/.env istnieje (hasło ma być tam, a nie w compose.yaml)"
fi

if git -C "$REPO" check-ignore -q kopie 2> /dev/null; then
  lab_ok "katalog kopie/ ze zrzutami bazy jest ignorowany przez git"
else
  lab_blad "katalog kopie/ ze zrzutami bazy jest ignorowany przez git"
fi

CZYSTO=0
ZSYNCHRONIZOWANE=0

if [[ -d "$REPO/.git" ]]; then
  if [[ -z "$(git -C "$REPO" status --porcelain 2> /dev/null)" ]]; then
    CZYSTO=1
  fi
  LOCAL_HEAD="$(git -C "$REPO" rev-parse HEAD 2> /dev/null || true)"
  UPSTREAM_HEAD="$(git -C "$REPO" rev-parse '@{u}' 2> /dev/null || true)"
  if [[ -n "$LOCAL_HEAD" && "$LOCAL_HEAD" == "$UPSTREAM_HEAD" ]]; then
    ZSYNCHRONIZOWANE=1
  fi
fi

if ((CZYSTO == 1)); then
  lab_ok "git status jest czysty — wszystko dodane i zacommitowane"
else
  lab_blad "git status jest czysty (są niezacommitowane albo nieśledzone zmiany)"
fi

if ((ZSYNCHRONIZOWANE == 1)); then
  lab_ok "lokalna gałąź jest zsynchronizowana ze zdalną (wypchnięta)"
else
  lab_blad "lokalna gałąź jest zsynchronizowana ze zdalną (commit może nie być wypchnięty)"
fi

lab_wskazowka "git status ma być czysty razem z nowymi plikami dnia: compose.yaml z usługą db, narzedzia/ i .gitignore. Plik .env i katalog kopie/ mają w nim NIE występować — jeśli je widzisz, nie są ignorowane."
lab_zakoncz
