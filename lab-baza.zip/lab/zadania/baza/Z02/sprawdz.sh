#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"

if ! docker compose --project-directory "$APKA" config > /dev/null 2>&1; then
  lab_blad "docker compose config składa się bez błędu (bez tego nie sprawdzę usługi db)"
  lab_wskazowka "Zacznij od 'docker compose config' — wypisze, w której linii pliku jest problem."
  lab_zakoncz
fi

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"

BLOK_DB="$(awk '
  /^  db:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

if [[ -z "$BLOK_DB" ]]; then
  lab_blad "w złożonej konfiguracji jest usługa o nazwie db"
  lab_wskazowka "Usługa ma się nazywać dokładnie 'db' — pod tą nazwą kontener api będzie ją widział w sieci."
  lab_zakoncz
fi

lab_ok "w złożonej konfiguracji jest usługa db"

OBRAZ_DB="$(grep -E '^ {4}image:' <<< "$BLOK_DB" | head -n1 | awk '{print $2}' | tr -d '"' || true)"
if [[ "$OBRAZ_DB" == *:* && "$OBRAZ_DB" != *:latest ]]; then
  lab_ok "usługa db stoi na obrazie z konkretnym tagiem wersji (${OBRAZ_DB})"
else
  lab_blad "usługa db ma obraz z konkretnym tagiem wersji (jest: ${OBRAZ_DB:-brak image:})"
fi

TYP_MONTOWANIA="$(awk '
  /^[[:space:]]*-[[:space:]]*type:/ { typ = $3; next }
  /^[[:space:]]*target:[[:space:]]*\/var\/lib\/postgresql\/data[[:space:]]*$/ { print typ; exit }
' <<< "$BLOK_DB")"

if [[ -n "$TYP_MONTOWANIA" ]]; then
  lab_ok "dane bazy są montowane pod /var/lib/postgresql/data"
  if [[ "$TYP_MONTOWANIA" == "volume" ]]; then
    lab_ok "dane bazy leżą w nazwanym wolumenie (nie w warstwie zapisywalnej kontenera)"
  else
    lab_blad "dane bazy leżą w nazwanym wolumenie (jest montowanie typu ${TYP_MONTOWANIA}, nie wolumen)"
  fi
else
  lab_blad "usługa db montuje dane pod /var/lib/postgresql/data"
fi

RESTART_DB="$(grep -E '^ {4}restart:' <<< "$BLOK_DB" | head -n1 | awk '{print $2}' | tr -d '"' || true)"
if [[ -n "$RESTART_DB" && "$RESTART_DB" != "no" ]]; then
  lab_ok "usługa db ma ustawioną politykę restartu"
else
  lab_blad "usługa db ma ustawioną politykę restartu (jest: ${RESTART_DB:-brak})"
fi

if grep -Eq '^ {6,}published:' <<< "$BLOK_DB"; then
  lab_blad "usługa db NIE publikuje żadnego portu na maszynie (znalazłem ports: — usuń je)"
else
  lab_ok "usługa db nie publikuje portu na maszynie — baza jest widoczna tylko wewnątrz stosu"
fi

DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -n "$DB_KONTENER" ]]; then
  lab_ok "kontener usługi db działa"
else
  lab_blad "kontener usługi db działa (nie znalazłem uruchomionego)"
fi

lab_wskazowka "Po każdej zmianie w compose.yaml stos trzeba podnieść od nowa: docker compose up -d"
lab_zakoncz
