#!/bin/bash
set -Eeuo pipefail
printf 'Z02 nie wymaga przygotowania — usługę db dopisujesz sam do compose.yaml.\n'
