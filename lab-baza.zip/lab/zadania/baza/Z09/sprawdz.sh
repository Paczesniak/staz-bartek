#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

KOPIE="$LAB_DOM/staz/kopie"
REPO="$LAB_DOM/staz"

lab_jest_katalog "$KOPIE" "katalog kopie/ istnieje w ~/staz"

ZRZUT=""
if [[ -d "$KOPIE" ]]; then
  ZRZUT="$(find "$KOPIE" -maxdepth 1 -type f -name '*.sql' -printf '%T@ %p\n' 2> /dev/null \
    | sort -rn | head -n1 | cut -d' ' -f2- || true)"
fi

if [[ -n "$ZRZUT" ]]; then
  lab_ok "w kopie/ jest plik zrzutu z rozszerzeniem .sql"
else
  lab_blad "w kopie/ jest plik zrzutu z rozszerzeniem .sql"
  lab_wskazowka "Zrzut robi się poleceniem pg_dump uruchomionym w kontenerze bazy, a jego wyjście przekierowuje do pliku na maszynie. Przy przekierowaniu do pliku przydaje się 'docker compose exec -T'."
  lab_zakoncz
fi

if grep -q 'PostgreSQL database dump' "$ZRZUT" 2> /dev/null; then
  lab_ok "plik jest zrzutem zrobionym przez pg_dump"
else
  lab_blad "plik jest zrzutem zrobionym przez pg_dump (nie znalazłem jego nagłówka)"
fi

if grep -Eq 'COPY public\.links|INSERT INTO public\.links|COPY links|INSERT INTO links' "$ZRZUT" 2> /dev/null; then
  lab_ok "zrzut zawiera dane tabeli links, nie samą jej strukturę"
else
  lab_blad "zrzut zawiera dane tabeli links, nie samą jej strukturę"
fi

if grep -Eq '^DROP TABLE IF EXISTS|^DROP TABLE' "$ZRZUT" 2> /dev/null; then
  lab_ok "zrzut wykonano z --clean — da się go wczytać na bazę z istniejącymi tabelami"
else
  lab_blad "zrzut wykonano z --clean --if-exists (bez tego wczytanie na niepustą bazę sypie błędami)"
fi

ROZMIAR="$(stat -c '%s' "$ZRZUT" 2> /dev/null || printf '0')"
if ((ROZMIAR > 500)); then
  lab_ok "plik zrzutu ma sensowną wielkość (${ROZMIAR} bajtów)"
else
  lab_blad "plik zrzutu ma sensowną wielkość (ma ${ROZMIAR} bajtów — to za mało nawet na samą strukturę)"
fi

if git -C "$REPO" check-ignore -q kopie 2> /dev/null \
  || git -C "$REPO" check-ignore -q "kopie/$(basename -- "$ZRZUT")" 2> /dev/null; then
  lab_ok "katalog kopie/ jest ignorowany przez git"
else
  lab_blad "katalog kopie/ jest ignorowany przez git (dopisz 'kopie/' do .gitignore)"
fi

lab_wskazowka "Zrzut, którego nikt nigdy nie wczytał, nie jest kopią zapasową — w następnym module sprawdzisz swój w warunkach bojowych."
lab_zakoncz
