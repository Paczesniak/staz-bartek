#!/bin/bash
set -Eeuo pipefail
printf 'Z09 nie wymaga przygotowania — kopię robisz sam, walidator sprawdzi plik.\n'
