#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"
REQ="$LAB_DOM/staz/aplikacja/api/requirements.txt"

if [[ -f "$REQ" ]] && grep -Eiq '^[[:space:]]*psycopg' "$REQ"; then
  lab_ok "requirements.txt zawiera sterownik PostgreSQL (psycopg)"
  if grep -Eiq '^[[:space:]]*psycopg[^=]*==[0-9]' "$REQ"; then
    lab_ok "wersja sterownika jest przypięta znakiem == (tak jak pozostałe zależności)"
  else
    lab_blad "wersja sterownika jest przypięta znakiem == (jest bez wersji)"
  fi
else
  lab_blad "requirements.txt zawiera sterownik PostgreSQL (psycopg)"
fi

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"

if [[ -n "$ADRES_BAZY" ]]; then
  lab_ok "DATABASE_URL usługi api wskazuje bazę PostgreSQL"

  BEZ_SCHEMATU="${ADRES_BAZY#*://}"
  PO_MALPIE="${BEZ_SCHEMATU#*@}"
  HOSTPORT="${PO_MALPIE%%/*}"
  HOST_BAZY="${HOSTPORT%%:*}"

  case "$HOST_BAZY" in
    localhost | 127.0.0.1 | ::1 | "")
      lab_blad "host bazy w DATABASE_URL to nazwa usługi bazy ze stosu (jest: ${HOST_BAZY:-pusty})"
      ;;
    *)
      lab_ok "host bazy w DATABASE_URL (${HOST_BAZY}) nie jest adresem lokalnym kontenera api"
      ;;
  esac
else
  lab_blad "DATABASE_URL usługi api wskazuje bazę PostgreSQL"
fi

API_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=api' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -n "$API_KONTENER" ]]; then
  lab_ok "kontener usługi api działa"
  if docker exec "$API_KONTENER" python -c 'import psycopg2' > /dev/null 2>&1 \
    || docker exec "$API_KONTENER" python -c 'import psycopg' > /dev/null 2>&1; then
    lab_ok "sterownik jest w obrazie — obraz został zbudowany po zmianie requirements.txt"
  else
    lab_blad "sterownik jest w obrazie (jest w pliku, ale nie w kontenerze — zbuduj obraz od nowa)"
  fi
else
  lab_blad "kontener usługi api działa (bez niego nie sprawdzę, czy sterownik trafił do obrazu)"
fi

ZDROWIE="$(curl -s --max-time 3 http://127.0.0.1:8000/health 2> /dev/null || true)"
if grep -q '"database"[[:space:]]*:[[:space:]]*"ok"' <<< "$ZDROWIE"; then
  lab_ok "/health odpowiada database: ok — aplikacja rozmawia z bazą"
else
  lab_blad "/health odpowiada database: ok (dostałem: ${ZDROWIE:-brak odpowiedzi})"
fi

lab_wskazowka "Pierwsze linie 'docker compose logs api' wypisują adres bazy, z którym aplikacja wystartowała — z ukrytym hasłem. To jest najszybszy sposób sprawdzenia, czy zmiana w ogóle weszła w życie."
lab_zakoncz
