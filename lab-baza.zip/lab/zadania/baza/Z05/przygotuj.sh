#!/bin/bash
set -Eeuo pipefail
printf 'Z05 nie wymaga przygotowania — sterownik dopisujesz sam i sam przebudowujesz obraz.\n'
