#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"
STAN_PRZED="${LAB_STAN_DIR}/baza-Z10-linki-przed"

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"
DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -z "$ADRES_BAZY" || -z "$DB_KONTENER" ]]; then
  lab_blad "działający kontener db i DATABASE_URL wskazujący Postgresa (bez tego nie zajrzę do bazy)"
  lab_zakoncz
fi

BEZ_SCHEMATU="${ADRES_BAZY#*://}"
POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
PO_MALPIE="${BEZ_SCHEMATU#*@}"
PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
PG_BAZA="${PO_MALPIE#*/}"
PG_BAZA="${PG_BAZA%%\?*}"

baza__pytanie() {
  docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" -tAc "$1" 2> /dev/null \
    | tr -d '\r' | head -n1 || true
}

PRZED="$(cat "$STAN_PRZED" 2> /dev/null || printf '0')"
[[ "$PRZED" =~ ^[0-9]+$ ]] || PRZED=0

TERAZ="$(baza__pytanie "SELECT count(*) FROM links;")"
[[ "$TERAZ" =~ ^[0-9]+$ ]] || TERAZ=0

if ((PRZED > 0)); then
  if ((TERAZ >= PRZED)); then
    lab_ok "dane wróciły do tabeli links (${TERAZ} z ${PRZED} skasowanych)"
  else
    lab_blad "dane wróciły do tabeli links (jest ${TERAZ} z ${PRZED} skasowanych)"
  fi
else
  if ((TERAZ > 0)); then
    lab_ok "w tabeli links są dane (${TERAZ})"
  else
    lab_blad "w tabeli links są dane (tabela jest pusta)"
  fi
fi

ZDROWIE="$(curl -s --max-time 3 http://127.0.0.1:8000/health 2> /dev/null || true)"
if grep -q '"database"[[:space:]]*:[[:space:]]*"ok"' <<< "$ZDROWIE"; then
  lab_ok "/health odpowiada database: ok — aplikacja przeżyła odtworzenie"
else
  lab_blad "/health odpowiada database: ok (dostałem: ${ZDROWIE:-brak odpowiedzi})"
fi

LINKI_JSON="$(curl -s --max-time 3 http://127.0.0.1:8000/api/links 2> /dev/null || true)"
if [[ -n "$LINKI_JSON" ]]; then
  Z_API="$(grep -o '"code"' <<< "$LINKI_JSON" | wc -l | tr -d ' ')"
  if [[ "$Z_API" == "$TERAZ" ]]; then
    lab_ok "API pokazuje tyle samo linków, co baza (${Z_API})"
  else
    lab_blad "API pokazuje tyle samo linków, co baza (API: ${Z_API}, baza: ${TERAZ})"
  fi
else
  lab_blad "/api/links odpowiada (bez tego nie porównam API z bazą)"
fi

SEKWENCJA="$(baza__pytanie "SELECT pg_get_serial_sequence('public.links','id');")"
if [[ -n "$SEKWENCJA" ]]; then
  OSTATNIA="$(baza__pytanie "SELECT last_value FROM ${SEKWENCJA};")"
  NAJWIEKSZE_ID="$(baza__pytanie "SELECT COALESCE(MAX(id), 0) FROM links;")"
  if [[ "$OSTATNIA" =~ ^[0-9]+$ && "$NAJWIEKSZE_ID" =~ ^[0-9]+$ ]] && ((OSTATNIA >= NAJWIEKSZE_ID)); then
    lab_ok "licznik id nadąża za odtworzonymi danymi — kolejny link się zapisze"
  else
    lab_blad "licznik id nadąża za odtworzonymi danymi (licznik: ${OSTATNIA:-?}, największe id: ${NAJWIEKSZE_ID:-?})"
  fi
fi

lab_wskazowka "Odtworzenie potwierdza się z trzech stron: liczbą wierszy w bazie, odpowiedzią API i listą w przeglądarce. Dwie pierwsze sprawdziłem — trzecią zobacz sam."
lab_zakoncz
