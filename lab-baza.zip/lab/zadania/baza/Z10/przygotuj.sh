#!/bin/bash
set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly APKA="${LAB_DOM}/staz/aplikacja"
readonly KOPIE="${LAB_DOM}/staz/kopie"
readonly STAN_PRZED="${LAB_STAN_DIR}/baza-Z10-linki-przed"

if [[ -f "$STAN_PRZED" ]]; then
  printf 'Z10 już przygotowane wcześniej — nie kasuję danych drugi raz.\n'
  exit 0
fi

ZRZUT=""
if [[ -d "$KOPIE" ]]; then
  while IFS= read -r plik; do
    if grep -Eq 'COPY public\.links|INSERT INTO public\.links|COPY links|INSERT INTO links' "$plik" 2> /dev/null; then
      ZRZUT="$plik"
      break
    fi
  done < <(find "$KOPIE" -maxdepth 1 -type f -name '*.sql' 2> /dev/null)
fi

if [[ -z "$ZRZUT" ]]; then
  lab_dziennik_mentora "Z10: nie kasowałem danych — w ${KOPIE} nie ma zrzutu z danymi tabeli links (moduł kopia jeszcze niezaliczony?)."
  printf 'Nie zaczynam tego zadania: w ~/staz/kopie nie ma jeszcze zrzutu z danymi.\n'
  printf 'To zadanie polega na odtworzeniu bazy z TWOJEJ kopii — zrób najpierw moduł\n'
  printf 'kopia, a potem wróć tutaj poleceniem: lab start odtworzenie\n'
  exit 0
fi

KONFIG="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"
BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG")"

ADRES_BAZY="$(grep -oE 'postgresql(\+[a-z0-9]+)?://[^"'"'"'[:space:]]+' <<< "$BLOK_API" | head -n1 || true)"
DB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=db' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -z "$ADRES_BAZY" || -z "$DB_KONTENER" ]]; then
  lab_dziennik_mentora "Z10: nie kasowałem danych — brak działającego kontenera db albo adresu bazy w konfiguracji."
  printf 'Nie zaczynam tego zadania: nie widzę działającej bazy w twoim stosie.\n'
  printf 'Podnieś stos (docker compose up -d), sprawdź /health i wróć tutaj.\n'
  exit 0
fi

BEZ_SCHEMATU="${ADRES_BAZY#*://}"
POSWIADCZENIA="${BEZ_SCHEMATU%%@*}"
PO_MALPIE="${BEZ_SCHEMATU#*@}"
PG_UZYTKOWNIK="${POSWIADCZENIA%%:*}"
PG_BAZA="${PO_MALPIE#*/}"
PG_BAZA="${PG_BAZA%%\?*}"

baza__pytanie() {
  docker exec "$DB_KONTENER" psql -U "$PG_UZYTKOWNIK" -d "$PG_BAZA" -tAc "$1" 2> /dev/null \
    | tr -d '\r' | head -n1 || true
}

PRZED="$(baza__pytanie "SELECT count(*) FROM links;")"
[[ "$PRZED" =~ ^[0-9]+$ ]] || PRZED=0

if ((PRZED == 0)); then
  lab_dziennik_mentora "Z10: tabela links była już pusta przed przygotowaniem — nie miałem czego kasować."
  printf 'Nie zaczynam tego zadania: tabela z linkami jest już pusta.\n'
  printf 'Najpierw dokończ przeprowadzkę danych z modułu dane.\n'
  exit 0
fi

printf '%s\n' "$PRZED" > "$STAN_PRZED"
chmod 644 -- "$STAN_PRZED"

baza__pytanie "TRUNCATE links;" > /dev/null

PO="$(baza__pytanie "SELECT count(*) FROM links;")"
lab_dziennik_mentora "Z10: skasowano zawartość tabeli links (było ${PRZED} wierszy, jest ${PO:-?}). Struktura, alembic_version i wolumen nietknięte. Zrzut do odtworzenia: ${ZRZUT}."

printf 'Przygotowano Z10. Coś się stało z twoimi danymi — sprawdź, co dokładnie.\n'
