#!/bin/bash
# Poprawka labu: walidatory treści notatek przestają rozróżniać wielkość liter,
# a trzy wzorce dopuszczają polskie znaki i synonimy.
#
# Uruchomienie z maszyny mentora, bez kopiowania plików:
#   ssh bartek@192.168.56.10 'sudo bash -s' < poprawka-wzorce.sh
#
# Idempotentna — ponowne uruchomienie niczego nie zepsuje.
set -Eeuo pipefail

LAB=/opt/lab
zmienione=0

popraw() {
  local plik="$1" stare="$2" nowe="$3" opis="$4"
  if [[ ! -f "$plik" ]]; then
    printf '  POMINIĘTO  %s — nie ma takiego pliku\n' "$opis"
    return 0
  fi
  if grep -qF -- "$nowe" "$plik"; then
    printf '  już jest    %s\n' "$opis"
    return 0
  fi
  if ! grep -qF -- "$stare" "$plik"; then
    printf '  UWAGA       %s — nie znalazłem tekstu do podmiany, sprawdź ręcznie\n' "$opis"
    return 0
  fi
  # Podmiana literalna: wzorce zawierają [ ] | ( ), więc sed dostaje je
  # przez zmienne, a nie w wyrażeniu regularnym.
  python3 - "$plik" "$stare" "$nowe" <<'PY'
import io, sys
plik, stare, nowe = sys.argv[1], sys.argv[2], sys.argv[3]
tresc = io.open(plik, encoding='utf-8').read()
io.open(plik, 'w', encoding='utf-8', newline='\n').write(tresc.replace(stare, nowe))
PY
  printf '  poprawiono  %s\n' "$opis"
  zmienione=$((zmienione + 1))
}

printf '\n== Poprawka wzorców walidatorów ==\n\n'

popraw "$LAB/lib/common.sh" \
  'grep -Eq -- "$wzorzec"' 'grep -Eiq -- "$wzorzec"' \
  'lab_plik_zawiera / lab_plik_nie_zawiera — bez rozróżniania wielkości liter'

popraw "$LAB/zadania/F1/Z11/sprawdz.sh" \
  "'spacj'" "'spacj|odst[eę]p|bia[łl]y znak'" \
  'Z11 — dopuszcza „odstęp" i „biały znak"'

popraw "$LAB/zadania/F1/Z16/sprawdz.sh" \
  "'skrot'" "'skr[oó]t'" \
  'Z16 — dopuszcza pisownię „skrót"'

popraw "$LAB/zadania/F1/Z09/sprawdz.sh" \
  "'smieci'" "'[sś]mieci'" \
  'Z09 — dopuszcza pisownię „śmieci"'

printf '\nZmienionych plików: %s\n' "$zmienione"

# Kontrola: czy skrypty nadal są poprawne składniowo
blad=0
for plik in "$LAB/lib/common.sh" "$LAB"/zadania/F1/Z{09,11,16}/sprawdz.sh; do
  if ! bash -n "$plik" 2>/dev/null; then
    printf 'BŁĄD SKŁADNI: %s\n' "$plik" >&2
    blad=1
  fi
done

if [[ "$blad" -eq 0 ]]; then
  printf 'Składnia wszystkich zmienionych plików w porządku.\n\n'
else
  printf '\nSą błędy składni — przywróć lab z repozytorium mentora.\n\n' >&2
  exit 1
fi
