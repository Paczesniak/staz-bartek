#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z01 nie wymaga przygotowania — Docker masz już zainstalowany, rozglądasz się po tym, co jest.\n'
