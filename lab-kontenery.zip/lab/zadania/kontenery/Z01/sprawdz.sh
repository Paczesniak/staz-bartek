#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

lab__jako_stazysta() {
  if [[ "$(id -un)" == "$LAB_UZYTKOWNIK" ]]; then
    "$@"
  else
    sudo -n -u "$LAB_UZYTKOWNIK" -- "$@"
  fi
}

if lab__jako_stazysta docker info > /dev/null 2>&1; then
  lab_ok "docker info działa jako $LAB_UZYTKOWNIK bez sudo (grupa docker zadziałała)"
else
  lab_blad "docker info NIE działa jako $LAB_UZYTKOWNIK bez sudo"
fi

lab_wynik_zawiera "systemctl is-active docker" '^active$' "usługa docker (dockerd) jest active"

if lab__jako_stazysta docker compose version > /dev/null 2>&1; then
  lab_ok "docker compose version działa"
else
  lab_blad "docker compose version NIE działa — brakuje wtyczki compose"
fi

lab_wskazowka "docker version pokazuje dwie części: klienta i serwer. Serwer to proces w tle — sprawdź go tym samym poleceniem, którym wczoraj sprawdzałeś linkbox."
lab_zakoncz
