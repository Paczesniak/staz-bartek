#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z08 nie wymaga przygotowania — compose.yaml piszesz sam w aplikacja/.\n'
