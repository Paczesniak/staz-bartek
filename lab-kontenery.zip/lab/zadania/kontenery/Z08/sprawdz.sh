#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"

lab_jest_plik "$APKA/compose.yaml" "plik compose.yaml istnieje w aplikacja/"

if docker compose --project-directory "$APKA" config > /dev/null 2>&1; then
  lab_ok "docker compose config składa się bez błędu"
else
  lab_blad "docker compose config kończy się błędem"
fi

KONFIG_ZLOZONA="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"

BLOK_API="$(awk '
  /^  api:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG_ZLOZONA")"

if grep -Eq '^ {4}build:' <<< "$BLOK_API"; then
  lab_ok "usługa api jest budowana przez build: (nie pobierana gotowa)"
else
  lab_blad "usługa api NIE ma build: w złożonej konfiguracji"
fi

RESTART_API="$(grep -E '^ {4}restart:' <<< "$BLOK_API" | awk '{print $2}' || true)"
RESTART_API="${RESTART_API%\"}"
RESTART_API="${RESTART_API#\"}"
if [[ -n "$RESTART_API" && "$RESTART_API" != "no" ]]; then
  lab_ok "usługa api ma ustawioną politykę restartu"
else
  lab_blad "usługa api nie ma ustawionej polityki restartu (albo jest 'no')"
fi

API_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=api' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -n "$API_KONTENER" ]]; then
  lab_ok "stos compose działa — kontener usługi api jest uruchomiony"
else
  lab_blad "nie znalazłem uruchomionego kontenera usługi api ze stosu compose"
fi

LINKS_TMP="$(mktemp)"
trap 'rm -f -- "$LINKS_TMP"' EXIT
KOD_LINKS="$(curl -s --max-time 3 -o "$LINKS_TMP" -w '%{http_code}' http://127.0.0.1:8000/api/links 2> /dev/null || true)"

if [[ "$KOD_LINKS" == "200" ]]; then
  lab_ok "/api/links odpowiada kodem 200"
else
  lab_blad "/api/links NIE odpowiada kodem 200 (dostałem: ${KOD_LINKS:-brak połączenia})"
fi

LICZBA_API=""
if [[ "$KOD_LINKS" == "200" ]]; then
  LICZBA_API="$(python3 -c '
import json, sys

with open(sys.argv[1], encoding="utf-8") as f:
    print(len(json.load(f)))
' "$LINKS_TMP" 2> /dev/null || true)"
fi

LICZBA_WOLUMEN=""
if [[ -n "$API_KONTENER" ]]; then
  ENV_KONTENERA="$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$API_KONTENER" 2> /dev/null || true)"
  DB_URL="$(grep -F 'DATABASE_URL=' <<< "$ENV_KONTENERA" | tail -n1 | cut -d= -f2- || true)"
  if [[ "$DB_URL" == sqlite:///* ]]; then
    SCIEZKA_BAZY="${DB_URL#sqlite:///}"
    if [[ "$SCIEZKA_BAZY" != /* ]]; then
      WORKDIR_API="$(docker inspect --format '{{.Config.WorkingDir}}' "$API_KONTENER" 2> /dev/null || true)"
      : "${WORKDIR_API:=/}"
      SCIEZKA_BAZY="${WORKDIR_API%/}/${SCIEZKA_BAZY}"
    fi
    LICZBA_WOLUMEN="$(docker exec -i "$API_KONTENER" python3 - "$SCIEZKA_BAZY" << 'PYEOF' 2> /dev/null || true
import sqlite3
import sys

try:
    polaczenie = sqlite3.connect(sys.argv[1])
    print(polaczenie.execute("SELECT COUNT(*) FROM links").fetchone()[0])
except sqlite3.Error:
    print(-1)
PYEOF
    )"
  fi
fi

if [[ "$LICZBA_API" =~ ^[0-9]+$ && "$LICZBA_WOLUMEN" =~ ^[0-9]+$ \
  && "$LICZBA_API" == "$LICZBA_WOLUMEN" && "$LICZBA_API" -gt 0 ]]; then
  lab_ok "liczba linków z /api/links zgadza się z bazą w wolumenie i jest większa od zera"
else
  lab_blad "liczba linków z /api/links NIE zgadza się z bazą w wolumenie (albo jest zerowa) — dane mogły nie przeżyć przejścia na compose"
fi

lab_wskazowka "docker volume ls pokaże, czy compose podłączył się do TEGO SAMEGO wolumenu z Z7, czy stworzył sobie nowy, pusty, z przedrostkiem nazwy projektu."
lab_zakoncz
