#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z05 nie wymaga przygotowania — uruchamiasz kontenery sam, walidator sprawdzi efekt.\n'
