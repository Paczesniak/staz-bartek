#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

WEB="$LAB_DOM/staz/aplikacja/web"

lab__wyglada_jak_losowa_nazwa() {
  [[ "$1" =~ ^[a-z0-9]+_[a-z0-9]+$ ]]
}

ADRES_API="$(grep -oE 'API_BASE_URL[[:space:]]*:[[:space:]]*"https?://[^/"]+:8000"' "$WEB/config.js" 2> /dev/null \
  | grep -oE 'https?://[^/"]+:8000' | head -n1 || true)"
HOST_API=""
if [[ -n "$ADRES_API" ]]; then
  HOST_API="${ADRES_API#*://}"
  HOST_API="${HOST_API%%:*}"
fi

KONTENER_Z05=""
while IFS= read -r kid; do
  [[ -z "$kid" ]] && continue
  nazwa="$(docker inspect --format '{{.Name}}' "$kid" 2> /dev/null || true)"
  nazwa="${nazwa#/}"
  [[ -z "$nazwa" ]] && continue
  lab__wyglada_jak_losowa_nazwa "$nazwa" && continue
  KONTENER_Z05="$kid"
  break
done < <(docker ps -q --filter 'ancestor=linkbox:1.0' --filter 'status=running' 2> /dev/null || true)

if [[ -n "$KONTENER_Z05" ]]; then
  lab_ok "działa w tle kontener linkbox:1.0 z własną (nie wylosowaną) nazwą"
else
  lab_blad "nie znalazłem działającego w tle kontenera linkbox:1.0 z własną nazwą"
fi

if [[ -n "$KONTENER_Z05" && -n "$HOST_API" ]]; then
  ORIGIN_FRONTU="http://${HOST_API}:3000"
  ENV_KONTENERA="$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$KONTENER_Z05" 2> /dev/null || true)"
  if grep -F 'CORS_ORIGINS=' <<< "$ENV_KONTENERA" | grep -Fq "$ORIGIN_FRONTU"; then
    lab_ok "CORS_ORIGINS kontenera zawiera origin frontu wyprowadzony z config.js"
  else
    lab_blad "CORS_ORIGINS kontenera NIE zawiera origin frontu wyprowadzonego z config.js"
  fi
else
  lab_blad "nie mogę sprawdzić CORS_ORIGINS — brak działającego kontenera albo adresu w config.js"
fi

if [[ -n "$KONTENER_Z05" ]]; then
  PORT_HOSTA="$(docker port "$KONTENER_Z05" 2> /dev/null | head -n1 | grep -oE ':[0-9]+$' | tr -d ':' || true)"
else
  PORT_HOSTA=""
fi

if [[ -n "$PORT_HOSTA" ]]; then
  KOD_HEALTH="$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "http://127.0.0.1:${PORT_HOSTA}/health" 2> /dev/null || true)"
  if [[ "$KOD_HEALTH" == "200" ]]; then
    lab_ok "/health kontenera odpowiada kodem 200"
  else
    lab_blad "/health kontenera NIE odpowiada kodem 200 (dostałem: ${KOD_HEALTH:-brak połączenia})"
  fi
else
  lab_blad "nie mogę sprawdzić /health — kontener nie publikuje żadnego portu maszyny"
fi

LICZBA_OBRAZOW_LINKBOX="$(docker images --format '{{.Repository}}' 2> /dev/null | grep -cE '(^|/)linkbox$' || true)"
if [[ "$LICZBA_OBRAZOW_LINKBOX" -eq 1 ]]; then
  lab_ok "istnieje dokładnie jeden obraz linkbox"
else
  lab_blad "liczba obrazów o repozytorium 'linkbox' to ${LICZBA_OBRAZOW_LINKBOX:-0}, oczekiwano dokładnie jednego"
fi

lab_wskazowka "Kontener, który się nie uruchomił (np. po błędnym LOG_LEVEL), nadal jest na liście docker ps -a i nadal ma log — to nie to samo, co usunięty."
lab_zakoncz
