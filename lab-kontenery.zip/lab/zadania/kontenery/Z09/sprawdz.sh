#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"
WEB="$APKA/web"

lab__systemd_nie_wroci() {
  local jednostka="$1" stan
  stan="$(systemctl is-enabled "$jednostka" 2> /dev/null || true)"
  [[ "$stan" != "enabled" && "$stan" != "enabled-runtime" \
    && "$stan" != "linked" && "$stan" != "linked-runtime" ]]
}

KONFIG_ZLOZONA="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"

BLOK_WEB="$(awk '
  /^  web:/ { w=1; print; next }
  w && /^  [a-zA-Z]/ { exit }
  w { print }
' <<< "$KONFIG_ZLOZONA")"

if [[ -n "$BLOK_WEB" ]]; then
  lab_ok "w złożonej konfiguracji jest usługa web"
else
  lab_blad "w złożonej konfiguracji nie ma usługi web"
fi

OBRAZ_WEB="$(grep -E '^ {4}image:' <<< "$BLOK_WEB" | head -n1 | sed -E 's/^[[:space:]]*image:[[:space:]]*//; s/^"//; s/"$//' || true)"
if [[ -n "$OBRAZ_WEB" && "$OBRAZ_WEB" == *:* && "${OBRAZ_WEB##*:}" != "latest" ]]; then
  lab_ok "usługa web ma obraz z konkretnym tagiem (nie latest, nie brak tagu)"
else
  lab_blad "usługa web nie ma obrazu z konkretnym tagiem (latest, brak tagu, albo brak image:)"
fi

BLOK_WEB_VOLUMES="$(awk '
  /^ {4}volumes:/ { w=1; next }
  w && /^ {4}[a-zA-Z]/ { exit }
  w { print }
' <<< "$BLOK_WEB")"

if grep -Fq "source: ${WEB}" <<< "$BLOK_WEB_VOLUMES" && grep -Eq 'read_only: true' <<< "$BLOK_WEB_VOLUMES"; then
  lab_ok "usługa web montuje katalog web/ w trybie tylko do odczytu"
else
  lab_blad "usługa web NIE montuje katalogu web/ w trybie tylko do odczytu"
fi

RESTART_WEB="$(grep -E '^ {4}restart:' <<< "$BLOK_WEB" | awk '{print $2}' || true)"
RESTART_WEB="${RESTART_WEB%\"}"
RESTART_WEB="${RESTART_WEB#\"}"
if [[ -n "$RESTART_WEB" && "$RESTART_WEB" != "no" ]]; then
  lab_ok "usługa web ma ustawioną politykę restartu"
else
  lab_blad "usługa web nie ma ustawionej polityki restartu (albo jest 'no')"
fi

WEB_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=web' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -n "$WEB_KONTENER" ]] && docker port "$WEB_KONTENER" 2> /dev/null | grep -Eq '^80/tcp -> .*:3000$'; then
  lab_ok "port 3000 maszyny jest przekierowany do kontenera usługi web"
else
  lab_blad "port 3000 maszyny NIE jest przekierowany do działającego kontenera usługi web"
fi

KOD_CONFIGJS="$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/config.js 2> /dev/null || true)"
if [[ "$KOD_CONFIGJS" == "200" ]]; then
  lab_ok "http://127.0.0.1:3000/config.js odpowiada kodem 200"
else
  lab_blad "http://127.0.0.1:3000/config.js NIE odpowiada kodem 200 (dostałem: ${KOD_CONFIGJS:-brak połączenia})"
fi

if lab__systemd_nie_wroci linkbox; then
  lab_ok "usługa systemd linkbox nie wstanie sama po restarcie maszyny"
else
  lab_blad "usługa systemd linkbox jest nadal enabled — wstałaby po restarcie i zderzyła się z kontenerem"
fi

if lab__systemd_nie_wroci linkbox-staging; then
  lab_ok "usługa systemd linkbox-staging nie wstanie sama po restarcie maszyny"
else
  lab_blad "usługa systemd linkbox-staging jest nadal enabled — wstałaby po restarcie"
fi

lab_wskazowka "Dwie rzeczy razem wstawiają dziś kontenery same po restarcie: polityka restartu w compose.yaml oraz to, że sama usługa docker jest w systemd włączona do autostartu."
lab_zakoncz
