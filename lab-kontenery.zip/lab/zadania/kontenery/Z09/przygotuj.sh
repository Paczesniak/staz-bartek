#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z09 nie wymaga przygotowania — usługę web dopisujesz sam do compose.yaml.\n'
