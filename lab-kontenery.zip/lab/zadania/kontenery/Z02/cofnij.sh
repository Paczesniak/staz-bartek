#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z02 nie zostawia artefaktów do posprzątania — Dockerfile, .dockerignore i obraz linkbox:1.0 zostają.\n'
