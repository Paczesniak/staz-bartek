#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z02 nie wymaga przygotowania — Dockerfile i .dockerignore piszesz sam w aplikacja/api.\n'
