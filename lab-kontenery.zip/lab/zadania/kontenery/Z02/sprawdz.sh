#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"

lab_jest_plik "$API/Dockerfile" "Dockerfile istnieje w aplikacja/api"
lab_jest_plik "$API/.dockerignore" ".dockerignore istnieje w aplikacja/api"

lab_plik_zawiera "$API/.dockerignore" '\.venv' ".dockerignore wyklucza środowisko wirtualne (.venv)"
lab_plik_zawiera "$API/.dockerignore" '\.db' ".dockerignore wyklucza pliki bazy (*.db)"
lab_plik_zawiera "$API/.dockerignore" '\.env' ".dockerignore wyklucza lokalną konfigurację (.env)"

FROM_ISTNIEJE=0
FROM_OK=1
if [[ -f "$API/Dockerfile" ]]; then
  while IFS= read -r linia; do
    FROM_ISTNIEJE=1
    obraz_bazowy="$(awk '{print $2}' <<< "$linia")"
    if [[ "$obraz_bazowy" != *:* || "${obraz_bazowy##*:}" == "latest" ]]; then
      FROM_OK=0
    fi
  done < <(grep -Ei '^[[:space:]]*FROM[[:space:]]+' "$API/Dockerfile" 2> /dev/null || true)
fi

if [[ "$FROM_ISTNIEJE" -eq 1 && "$FROM_OK" -eq 1 ]]; then
  lab_ok "obraz bazowy w Dockerfile ma konkretny tag wersji (nie latest, nie brak tagu)"
else
  lab_blad "obraz bazowy w Dockerfile nie ma konkretnego tagu wersji (latest albo brak tagu)"
fi

if docker image inspect linkbox:1.0 > /dev/null 2>&1; then
  lab_ok "obraz linkbox:1.0 istnieje"

  WHOAMI_WYNIK="$(docker run --rm linkbox:1.0 whoami 2> /dev/null || true)"
  if [[ -n "$WHOAMI_WYNIK" && "$WHOAMI_WYNIK" != "root" ]]; then
    lab_ok "proces w obrazie działa jako użytkownik inny niż root"
  else
    lab_blad "proces w obrazie działa jako root (albo whoami się nie wykonał)"
  fi

  if docker run --rm linkbox:1.0 sh -c 'test -d .venv' > /dev/null 2>&1; then
    lab_blad "w obrazie jest katalog .venv w katalogu roboczym — .dockerignore go nie wykluczył"
  else
    lab_ok "w obrazie nie ma katalogu .venv w katalogu roboczym"
  fi
else
  lab_blad "obraz linkbox:1.0 nie istnieje"
  lab_blad "nie mogę sprawdzić użytkownika procesu — obraz linkbox:1.0 nie istnieje"
  lab_blad "nie mogę sprawdzić zawartości obrazu — linkbox:1.0 nie istnieje"
fi

lab_wskazowka "Migracja bazy (alembic upgrade head) ma wystartować RAZEM z aplikacją, przy starcie kontenera — nie podczas budowania obrazu."
lab_zakoncz
