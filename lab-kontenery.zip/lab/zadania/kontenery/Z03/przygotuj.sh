#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z03 nie wymaga przygotowania — porównujesz cache na własnym Dockerfile i jego kopii.\n'
