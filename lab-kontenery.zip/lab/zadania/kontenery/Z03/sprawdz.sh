#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

API="$LAB_DOM/staz/aplikacja/api"

lab_nie_ma "$API/Dockerfile.zle" "tymczasowy Dockerfile.zle został posprzątany"

if docker image inspect linkbox:zle > /dev/null 2>&1; then
  lab_blad "tymczasowy obraz linkbox:zle nadal istnieje — nie został posprzątany"
else
  lab_ok "tymczasowy obraz linkbox:zle nie istnieje"
fi

if [[ -f "$API/Dockerfile" ]]; then
  LINIA_REQ="$(grep -nE '^[[:space:]]*COPY[[:space:]]+.*requirements\.txt' "$API/Dockerfile" 2> /dev/null | head -n1 | cut -d: -f1 || true)"
  LINIA_KOD="$(grep -nE '^[[:space:]]*COPY[[:space:]]+\.([[:space:]]|$)' "$API/Dockerfile" 2> /dev/null | head -n1 | cut -d: -f1 || true)"
else
  LINIA_REQ=""
  LINIA_KOD=""
fi

if [[ -n "$LINIA_REQ" && -n "$LINIA_KOD" && "$LINIA_REQ" -lt "$LINIA_KOD" ]]; then
  lab_ok "w Dockerfile requirements.txt kopiuje się przed resztą kodu"
else
  lab_blad "w Dockerfile requirements.txt NIE kopiuje się przed resztą kodu (albo nie znalazłem obu kroków)"
fi

lab_wskazowka "Porównaj czas budowania bez zmian, po literówce w komentarzu i po przestawieniu kolejności w Dockerfile.zle — trzy różne liczby z tego samego zadania."
lab_zakoncz
