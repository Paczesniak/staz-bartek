#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

APKA="$LAB_DOM/staz/aplikacja"
WEB="$APKA/web"
NAKLADKA="$APKA/compose.override.yaml"

if [[ ! -f "$NAKLADKA" ]]; then
  lab_ok "compose.override.yaml z podłożonymi wadami już nie obowiązuje pod tą nazwą"
elif grep -Eq 'APP_HOST:[[:space:]]*"?127\.0\.0\.1"?' "$NAKLADKA" 2> /dev/null \
  || grep -Eq 'DATABASE_URL:.*/tmp/' "$NAKLADKA" 2> /dev/null; then
  lab_blad "compose.override.yaml nadal ustawia jedną z podłożonych wartości"
else
  lab_ok "compose.override.yaml (jeśli istnieje) nie ustawia już podłożonych wartości"
fi

KONFIG_ZLOZONA="$(docker compose --project-directory "$APKA" config 2> /dev/null || true)"

if ! grep -Eq 'APP_HOST:[[:space:]]*"?127\.0\.0\.1"?' <<< "$KONFIG_ZLOZONA"; then
  lab_ok "złożona konfiguracja nie ma APP_HOST ustawionego na 127.0.0.1"
else
  lab_blad "złożona konfiguracja nadal ma APP_HOST ustawiony na 127.0.0.1"
fi

if ! grep -Eq 'DATABASE_URL:.*/tmp/' <<< "$KONFIG_ZLOZONA"; then
  lab_ok "złożona konfiguracja nie ma DATABASE_URL wskazującego poza wolumen"
else
  lab_blad "złożona konfiguracja nadal ma DATABASE_URL wskazujący poza wolumen (/tmp)"
fi

API_KONTENER="$(docker ps -q \
  --filter "label=com.docker.compose.project.working_dir=${APKA}" \
  --filter 'label=com.docker.compose.service=api' \
  --filter 'status=running' 2> /dev/null | head -n1 || true)"

if [[ -n "$API_KONTENER" ]] && docker port "$API_KONTENER" 2> /dev/null | grep -Eq '^8000/tcp -> .*:8000$'; then
  lab_ok "port 8000 maszyny jest przekierowany do kontenera usługi api"
else
  lab_blad "port 8000 maszyny NIE jest przekierowany do działającego kontenera usługi api"
fi

HEALTH_BODY="$(curl -fsS --max-time 3 http://127.0.0.1:8000/health 2> /dev/null || true)"
if grep -Eq '"database"[[:space:]]*:[[:space:]]*"ok"' <<< "$HEALTH_BODY"; then
  lab_ok "/health odpowiada z database: ok"
else
  lab_blad "/health NIE odpowiada z database: ok"
fi

LINKS_TMP="$(mktemp)"
trap 'rm -f -- "$LINKS_TMP"' EXIT
KOD_LINKS="$(curl -s --max-time 3 -o "$LINKS_TMP" -w '%{http_code}' http://127.0.0.1:8000/api/links 2> /dev/null || true)"

LICZBA_API=""
if [[ "$KOD_LINKS" == "200" ]]; then
  LICZBA_API="$(python3 -c '
import json, sys

with open(sys.argv[1], encoding="utf-8") as f:
    print(len(json.load(f)))
' "$LINKS_TMP" 2> /dev/null || true)"
fi

LICZBA_WOLUMEN=""
if [[ -n "$API_KONTENER" ]]; then
  ENV_KONTENERA="$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$API_KONTENER" 2> /dev/null || true)"
  DB_URL="$(grep -F 'DATABASE_URL=' <<< "$ENV_KONTENERA" | tail -n1 | cut -d= -f2- || true)"
  if [[ "$DB_URL" == sqlite:///* ]]; then
    SCIEZKA_BAZY="${DB_URL#sqlite:///}"
    if [[ "$SCIEZKA_BAZY" != /* ]]; then
      WORKDIR_API="$(docker inspect --format '{{.Config.WorkingDir}}' "$API_KONTENER" 2> /dev/null || true)"
      : "${WORKDIR_API:=/}"
      SCIEZKA_BAZY="${WORKDIR_API%/}/${SCIEZKA_BAZY}"
    fi
    LICZBA_WOLUMEN="$(docker exec -i "$API_KONTENER" python3 - "$SCIEZKA_BAZY" << 'PYEOF' 2> /dev/null || true
import sqlite3
import sys

try:
    polaczenie = sqlite3.connect(sys.argv[1])
    print(polaczenie.execute("SELECT COUNT(*) FROM links").fetchone()[0])
except sqlite3.Error:
    print(-1)
PYEOF
    )"
  fi
fi

if [[ "$LICZBA_API" =~ ^[0-9]+$ && "$LICZBA_WOLUMEN" =~ ^[0-9]+$ \
  && "$LICZBA_API" == "$LICZBA_WOLUMEN" && "$LICZBA_API" -gt 0 ]]; then
  lab_ok "liczba linków z /api/links zgadza się z bazą w wolumenie i jest większa od zera (dane przetrwały)"
else
  lab_blad "liczba linków z /api/links NIE zgadza się z bazą w wolumenie albo jest zerowa — pusta lista nie jest stanem docelowym"
fi

lab_plik_zawiera "$WEB/config.js" 'API_BASE_URL[^"]*"https?://[^"]+:8000"' "config.js frontu nadal wskazuje port 8000"

lab_wskazowka "docker compose logs api pokazuje w pierwszych liniach efektywną konfigurację, z którą aplikacja wystartowała — czytaj log od góry, nie od dołu."
lab_zakoncz
