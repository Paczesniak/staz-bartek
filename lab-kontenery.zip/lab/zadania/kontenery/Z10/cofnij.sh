#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly APKA="${LAB_DOM}/staz/aplikacja"
readonly NAKLADKA="${APKA}/compose.override.yaml"

if [[ -f "$NAKLADKA" ]]; then
  rm -f -- "$NAKLADKA"
  if [[ -f "${APKA}/compose.yaml" ]]; then
    docker compose --project-directory "$APKA" up -d > /dev/null 2>&1 || true
  fi
fi

printf 'Cofnięto Z10: usunięto compose.override.yaml, stos wrócił do Twojej własnej konfiguracji. compose.yaml i wolumen z danymi nie zostały ruszone.\n'
