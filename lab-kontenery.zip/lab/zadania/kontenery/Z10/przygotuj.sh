#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

readonly APKA="${LAB_DOM}/staz/aplikacja"
readonly NAKLADKA="${APKA}/compose.override.yaml"

if [[ -f "$NAKLADKA" ]]; then
  printf 'Z10 już przygotowane wcześniej — nie dotykam istniejącego stanu.\n'
  exit 0
fi

if [[ ! -f "${APKA}/compose.yaml" ]]; then
  lab_dziennik_mentora "Z10: nie mogę przygotować — brak ${APKA}/compose.yaml (moduł compose jeszcze niezaliczony?)."
  printf 'Nie mam jeszcze czego zepsuć: w ~/staz/aplikacja nie ma pliku compose.yaml.\n'
  printf 'To zadanie startuje od stosu zbudowanego w module compose — zrób najpierw\n'
  printf 'tamten moduł, a potem wróć tutaj poleceniem: lab start awaria\n'
  exit 0
fi

docker compose --project-directory "$APKA" up -d > /dev/null 2>&1 || true

lab__czekaj_na_zdrowie() {
  local _proba
  for _proba in $(seq 1 10); do
    curl -fsS --max-time 2 -o /dev/null http://127.0.0.1:8000/health 2> /dev/null && return 0
    sleep 1
  done
  return 1
}

if lab__czekaj_na_zdrowie; then
  LICZBA_PRZED="$(curl -fsS --max-time 3 http://127.0.0.1:8000/api/links 2> /dev/null \
    | python3 -c 'import json, sys

try:
    print(len(json.load(sys.stdin)))
except Exception:
    print(0)' 2> /dev/null || printf '0')"

  if [[ "$LICZBA_PRZED" == "0" ]]; then
    for i in 1 2 3; do
      curl -fsS --max-time 3 -X POST http://127.0.0.1:8000/api/links \
        -H 'Content-Type: application/json' \
        -d "{\"url\": \"https://przyklad.test/lab-seed-${i}\"}" > /dev/null 2>&1 || true
    done
  fi
else
  lab_dziennik_mentora "Z10: /health nie odpowiedziało w 10 s przed podłożeniem nakładki — stos mógł nie być gotowy; nie dosiałem danych zapasowych."
fi

cat > "$NAKLADKA" << 'YAML'
services:
  api:
    environment:
      APP_HOST: "127.0.0.1"
      DATABASE_URL: "sqlite:////tmp/links.db"
YAML

chown -- "${LAB_UZYTKOWNIK}:${LAB_GRUPA}" "$NAKLADKA"
chmod 644 -- "$NAKLADKA"

if ! docker compose --project-directory "$APKA" up -d > /dev/null 2>&1; then
  lab_dziennik_mentora "Z10: 'docker compose up -d' po podłożeniu nakładki zakończyło się błędem — sprawdź stan stosu ręcznie."
fi

lab_dziennik_mentora "Z10: podłożono ${NAKLADKA} z dwiema wadami naraz w environment usługi api: APP_HOST=127.0.0.1 (front/przeglądarka nie dobiją się do API — to jest objaw z modułu uruchomienie) oraz DATABASE_URL=sqlite:////tmp/links.db (poza wolumenem — świeża, pusta baza w warstwie zapisywalnej — to jest objaw z modułu dane). Stos podniesiony od razu jako root."
printf 'Przygotowano Z10. Stos czeka w ~/staz/aplikacja.\n'
