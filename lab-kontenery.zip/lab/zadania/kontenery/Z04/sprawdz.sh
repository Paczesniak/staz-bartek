#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

STATUS_LINKBOX="$(systemctl is-active linkbox 2> /dev/null || true)"
if [[ "$STATUS_LINKBOX" != "active" ]]; then
  lab_ok "usługa systemd linkbox nie jest active (port 8000 zwolniony)"
else
  lab_blad "usługa systemd linkbox nadal jest active — trzyma port 8000"
fi

KONTENER_Z04=""
while IFS= read -r kid; do
  [[ -z "$kid" ]] && continue
  if docker port "$kid" 2> /dev/null | grep -Eq '^8000/tcp -> .*:8000$'; then
    KONTENER_Z04="$kid"
    break
  fi
done < <(docker ps -q --filter 'ancestor=linkbox:1.0' --filter 'status=running' 2> /dev/null || true)

if [[ -n "$KONTENER_Z04" ]]; then
  lab_ok "działa kontener z obrazu linkbox:1.0 z portem 8000 maszyny przekierowanym na port 8000 w kontenerze"
else
  lab_blad "nie znalazłem działającego kontenera linkbox:1.0 publikującego port 8000 maszyny na port 8000"
fi

KOD_HEALTH="$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:8000/health 2> /dev/null || true)"
if [[ "$KOD_HEALTH" == "200" ]]; then
  lab_ok "http://127.0.0.1:8000/health odpowiada kodem 200"
else
  lab_blad "http://127.0.0.1:8000/health NIE odpowiada kodem 200 (dostałem: ${KOD_HEALTH:-brak połączenia})"
fi

if [[ -n "$KONTENER_Z04" ]]; then
  ENV_KONTENERA="$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$KONTENER_Z04" 2> /dev/null || true)"
  if grep -qx 'APP_HOST=0.0.0.0' <<< "$ENV_KONTENERA"; then
    lab_ok "efektywny APP_HOST kontenera to 0.0.0.0"
  else
    lab_blad "efektywny APP_HOST kontenera NIE jest ustawiony na 0.0.0.0"
  fi
else
  lab_blad "nie mogę sprawdzić APP_HOST — nie znalazłem działającego kontenera na porcie 8000"
fi

lab_wskazowka "Przeczytaj log kontenera od pierwszej linii — ta sama linia co wczoraj, ale 'ta sama maszyna' znaczy dziś coś innego."
lab_zakoncz
