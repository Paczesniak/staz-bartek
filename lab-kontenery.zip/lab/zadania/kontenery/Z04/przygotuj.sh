#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z04 nie wymaga przygotowania — uruchamiasz kontener sam, walidator sprawdzi efekt.\n'
