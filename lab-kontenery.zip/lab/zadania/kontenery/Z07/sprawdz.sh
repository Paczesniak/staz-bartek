#!/bin/bash
set -Eeuo pipefail
source /opt/lab/lib/common.sh

lab__sciezka_bazy_kontenera() {
  local kid="$1" env_kontenera url workdir sciezka
  env_kontenera="$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' "$kid" 2> /dev/null || true)"
  url="$(grep -F 'DATABASE_URL=' <<< "$env_kontenera" | tail -n1 | cut -d= -f2- || true)"
  [[ "$url" == sqlite:///* ]] || return 1
  sciezka="${url#sqlite:///}"
  if [[ "$sciezka" == /* ]]; then
    printf '%s' "$sciezka"
  else
    workdir="$(docker inspect --format '{{.Config.WorkingDir}}' "$kid" 2> /dev/null || true)"
    : "${workdir:=/}"
    printf '%s/%s' "${workdir%/}" "$sciezka"
  fi
}

lab__wiersze_links_w_kontenerze() {
  docker exec -i "$1" python3 - "$2" << 'PYEOF' 2> /dev/null
import sqlite3
import sys

try:
    polaczenie = sqlite3.connect(sys.argv[1])
    print(polaczenie.execute("SELECT COUNT(*) FROM links").fetchone()[0])
except sqlite3.Error:
    print(-1)
PYEOF
}

lab__tabele_bazy_kontenera() {
  docker exec -i "$1" python3 - "$2" << 'PYEOF' 2> /dev/null
import sqlite3
import sys

try:
    polaczenie = sqlite3.connect(sys.argv[1])
    tabele = {wiersz[0] for wiersz in polaczenie.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table'"
    )}
    print(int("links" in tabele), int("alembic_version" in tabele))
except sqlite3.Error:
    print("0 0")
PYEOF
}

KONTENER_Z07="" SCIEZKA_BAZY=""
while IFS= read -r kid; do
  [[ -z "$kid" ]] && continue
  sciezka="$(lab__sciezka_bazy_kontenera "$kid" || true)"
  [[ -n "$sciezka" ]] || continue

  while IFS=$'\t' read -r typ _nazwa cel; do
    [[ "$typ" == "volume" ]] || continue
    case "$sciezka" in
      "$cel" | "$cel"/*)
        KONTENER_Z07="$kid"
        SCIEZKA_BAZY="$sciezka"
        ;;
    esac
  done < <(docker inspect --format '{{range .Mounts}}{{.Type}}{{"\t"}}{{.Name}}{{"\t"}}{{.Destination}}{{"\n"}}{{end}}' "$kid" 2> /dev/null || true)

  [[ -n "$KONTENER_Z07" ]] && break
done < <(docker ps -q --filter 'ancestor=linkbox:1.0' --filter 'status=running' 2> /dev/null || true)

if [[ -n "$KONTENER_Z07" ]]; then
  lab_ok "działający kontener linkbox ma podmontowany nazwany wolumen pod ścieżką z DATABASE_URL"
else
  lab_blad "nie znalazłem działającego kontenera linkbox z nazwanym wolumenem podmontowanym pod ścieżką z DATABASE_URL"
fi

if [[ -n "$KONTENER_Z07" ]] && docker exec "$KONTENER_Z07" test -s "$SCIEZKA_BAZY" > /dev/null 2>&1; then
  lab_ok "plik bazy pod ścieżką z DATABASE_URL istnieje i ma rozmiar większy od zera"
else
  lab_blad "plik bazy pod ścieżką z DATABASE_URL nie istnieje albo jest pusty"
fi

if [[ -n "$KONTENER_Z07" ]]; then
  read -r MA_LINKS MA_ALEMBIC <<< "$(lab__tabele_bazy_kontenera "$KONTENER_Z07" "$SCIEZKA_BAZY" || printf '0 0')"
else
  MA_LINKS=0
  MA_ALEMBIC=0
fi

if [[ "$MA_LINKS" == "1" && "$MA_ALEMBIC" == "1" ]]; then
  lab_ok "baza w wolumenie ma tabele links i alembic_version"
else
  lab_blad "baza w wolumenie nie ma obu wymaganych tabel (links, alembic_version)"
fi

if [[ -n "$KONTENER_Z07" ]]; then
  LICZBA_LINKOW="$(lab__wiersze_links_w_kontenerze "$KONTENER_Z07" "$SCIEZKA_BAZY" || true)"
else
  LICZBA_LINKOW=""
fi

if [[ "$LICZBA_LINKOW" =~ ^[0-9]+$ && "$LICZBA_LINKOW" -ge 1 ]]; then
  lab_ok "w tabeli links w wolumenie jest co najmniej jeden wiersz"
else
  lab_blad "w tabeli links w wolumenie nie ma żadnego wiersza"
fi

if docker image inspect linkbox:1.0 > /dev/null 2>&1; then
  WHOAMI_WYNIK="$(docker run --rm linkbox:1.0 whoami 2> /dev/null || true)"
  if [[ -n "$WHOAMI_WYNIK" && "$WHOAMI_WYNIK" != "root" ]]; then
    lab_ok "proces w obrazie nadal działa jako użytkownik inny niż root"
  else
    lab_blad "proces w obrazie działa jako root"
  fi
else
  lab_blad "nie mogę sprawdzić użytkownika procesu — obraz linkbox:1.0 nie istnieje"
fi

lab_wskazowka "docker volume inspect pokaże ci ścieżkę na maszynie, pod którą Docker trzyma dane tego wolumenu."
lab_zakoncz
