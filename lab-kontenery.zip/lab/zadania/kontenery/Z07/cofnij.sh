#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z07 nie zostawia artefaktów do posprzątania — wolumen z danymi zostaje, potrzebny do końca dnia.\n'
