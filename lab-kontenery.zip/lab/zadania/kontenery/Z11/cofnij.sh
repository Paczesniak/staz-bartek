#!/bin/bash

set -Eeuo pipefail

# shellcheck source=../../../lib/common.sh
source /opt/lab/lib/common.sh

printf 'Z11 nie zostawia artefaktów do posprzątania — notatki i repozytorium stażysty pozostają nietknięte.\n'
